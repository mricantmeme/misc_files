package com.dicv.cwp.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.TripStopLocations;

@Repository
public interface TripStopLocationsRepo extends CrudRepository<TripStopLocations, Integer> {

	@Query("Select t from TripStopLocations t where t.trip.tripId=:tripId and t.isStopped=1")
	public List<TripStopLocations> fetchLastStoppedTrip(@Param("tripId") Long tripId);

	@Query("Select t from TripStopLocations t where t.trip.tripId=:tripId and t.isStopped=1 and t.stopTime is null")
	public List<TripStopLocations> fetchLastStoppedTripByTime(@Param("tripId") Long tripId);

	@Query("Select count(t.tripStopLocationId) from TripStopLocations t where t.trip.vehicleId=:vehicleId and "
			+ " t.startTime>=:startTime and t.stopTime<=:stopTime  and t.duration>=120000")
	public Long getStopCount(@Param("vehicleId") Long vehicleId, @Param("startTime") Date startTime,
			@Param("stopTime") Date stopTime);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("delete TripStopLocations t where t.trip.tripId=:tripId")
	public void deleteTripStopLocations(@Param("tripId") Long tripId);

}
