package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.BatteryHealth;

@Repository
public interface BatteryHealthRepo extends JpaRepository<BatteryHealth, Long> {

}
