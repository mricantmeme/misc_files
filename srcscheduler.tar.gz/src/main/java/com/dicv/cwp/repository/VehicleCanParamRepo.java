package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleCanParam;

@Repository
public interface VehicleCanParamRepo extends CrudRepository<VehicleCanParam, Long> {

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleCanParam v set v.vehicleEngineRpm=:vehicleEngineRpm,v.vehicleEngineCoolantTemp =:vehicleEngineCoolantTemp,"
			+ "v.fuelTankLevel =:fuelTankLevel,v.batteryHealth=:batteryHealth,v.lastEngineOnTime =:lastEngineOnTime,v.vehicleLastUpdateON =:vehicleLastUpdateON  "
			+ ",v.updatedDateTime =:updatedDateTime,v.adblueLevel=:adblueLevel where v.vehicleId =:vehicleId")
	public void updateVehicleParam(@Param("vehicleEngineRpm") Long vehicleEngineRpm,
			@Param("vehicleEngineCoolantTemp") Double vehicleEngineCoolantTemp,
			@Param("fuelTankLevel") Integer fuelTankLevel, @Param("batteryHealth") Integer batteryHealth,
			@Param("lastEngineOnTime") Timestamp lastEngineOnTime,
			@Param("vehicleLastUpdateON") Timestamp vehicleLastUpdateON,
			@Param("updatedDateTime") Timestamp updatedDateTime, @Param("adblueLevel") Double adblueLevel,
			@Param("vehicleId") Long vehicleId);

	@Query("Select v from VehicleCanParam v where v.vehicleId=:vehicleId ")
	public List<VehicleCanParam> getvehicleCanParam(@Param("vehicleId") Long vehicleId);

}
