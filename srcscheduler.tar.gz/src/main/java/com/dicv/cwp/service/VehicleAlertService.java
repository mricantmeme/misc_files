package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleAlertHistory;
import com.dicv.cwp.repository.VehicleAlertHistoryRepo;
import com.dicv.cwp.utils.DicvUtil;

@Service
public class VehicleAlertService {

	@Autowired
	private VehicleAlertHistoryRepo vehicleAlertRepo;

	@Transactional
	public VehicleAlertHistory getVehicleAlertHistory(Long vehicleId, Long imei) {
		VehicleAlertHistory vehicleAlertHistory = new VehicleAlertHistory();
		List<VehicleAlertHistory> list = vehicleAlertRepo.getVehicleAlertHistory(vehicleId);
		if (list == null || list.isEmpty()) {
			vehicleAlertHistory.setVehicleId(vehicleId);
			vehicleAlertHistory.setLastSpeedAlertSent(DicvUtil.getTimestamp());
			vehicleAlertHistory.setLowBatteryDetected(0);
			vehicleAlertHistory.setIdleTimeProcess(DicvUtil.getTimestamp());
			vehicleAlertRepo.save(vehicleAlertHistory);
		} else {
			vehicleAlertHistory = list.get(0);
		}
		if (vehicleAlertHistory.getLastSpeedAlertSent() == null) {
			vehicleAlertHistory.setLastSpeedAlertSent(DicvUtil.getTimestamp());
			updateVehicleOverSpeedTime(DicvUtil.getTimestamp(), vehicleAlertHistory.getVehicleId());
		}
		return vehicleAlertHistory;
	}

	public void updateVehicleOverSpeedTime(Timestamp lastSpeedAlertSent, Long vehicleId) {
		vehicleAlertRepo.updateLastSpeedAlertSent(lastSpeedAlertSent, vehicleId);
	}

	public void updateOverSpeedProcessedTime(Timestamp speedGpsProcessTime, Long vehicleId) {
		vehicleAlertRepo.updateOverSpeedProcessedTime(speedGpsProcessTime, vehicleId);
	}

}
