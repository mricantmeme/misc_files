package com.dicv.cwp.dto;

import java.util.Date;

public class GpsVehParameterDto {

	/**
	 * 
	 */
	private Long gpsVehicleParamId;

	private Long canEngineSpeed;

	private Double gpsSpkm;

	private Date gpsTime;

	private Integer engineON;

	private Double gpsLatitude;

	private Double gpsLongitude;

	private Integer harshAcceleration;

	private Integer harshBraking;

	private Integer harshCornering;

	private Long gpsImei;

	public GpsVehParameterDto(Long gpsVehicleParamId, Double gpsSpkm, Date gpsTime, Double gpsLatitude,
			Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsSpkm = gpsSpkm;
		this.gpsTime = gpsTime;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParameterDto(Long gpsVehicleParamId, Date gpsTime) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsTime = gpsTime;
	}

	public GpsVehParameterDto(Long gpsVehicleParamId, Long canEngineSpeed, Double gpsSpkm, Date gpsTime,
			Integer engineON, Double gpsLatitude, Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.canEngineSpeed = canEngineSpeed;
		this.gpsSpkm = gpsSpkm;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParameterDto(Long gpsVehicleParamId, Double gpsSpkm, Date gpsTime, Integer engineON,
			Double gpsLatitude, Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsSpkm = gpsSpkm;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParameterDto(Long gpsVehicleParamId, Long gpsImei, Long canEngineSpeed, Double gpsSpkm, Date gpsTime,
			Integer engineON, Double gpsLatitude, Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsImei = gpsImei;
		this.canEngineSpeed = canEngineSpeed;
		this.gpsSpkm = gpsSpkm;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParameterDto(Long gpsVehicleParamId, Long canEngineSpeed, Double gpsSpkm, Date gpsTime,
			Integer engineON, Double gpsLatitude, Double gpsLongitude, Integer harshAcceleration, Integer harshBraking,
			Integer harshCornering) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.canEngineSpeed = canEngineSpeed;
		this.gpsSpkm = gpsSpkm;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
		this.harshAcceleration = harshAcceleration;
		this.harshBraking = harshBraking;
		this.harshCornering = harshCornering;
	}

	public Long getGpsVehicleParamId() {
		return gpsVehicleParamId;
	}

	public void setGpsVehicleParamId(Long gpsVehicleParamId) {
		this.gpsVehicleParamId = gpsVehicleParamId;
	}

	public Date getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(Date gpsTime) {
		this.gpsTime = gpsTime;
	}

	public Integer getEngineON() {
		return engineON;
	}

	public void setEngineON(Integer engineON) {
		this.engineON = engineON;
	}

	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	@Override
	public String toString() {
		return "GpsVehicleUtilizationDto [gpsVehicleParamId=" + gpsVehicleParamId + ", gpsSpkm=" + gpsSpkm
				+ ", gpsTime=" + gpsTime + ", engineON=" + engineON + ", gpsLatitude=" + gpsLatitude + ", gpsLongitude="
				+ gpsLongitude + "]";
	}

	public Integer getHarshAcceleration() {
		return harshAcceleration;
	}

	public void setHarshAcceleration(Integer harshAcceleration) {
		this.harshAcceleration = harshAcceleration;
	}

	public Integer getHarshBraking() {
		return harshBraking;
	}

	public void setHarshBraking(Integer harshBraking) {
		this.harshBraking = harshBraking;
	}

	public Integer getHarshCornering() {
		return harshCornering;
	}

	public void setHarshCornering(Integer harshCornering) {
		this.harshCornering = harshCornering;
	}

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public Long getCanEngineSpeed() {
		return canEngineSpeed;
	}

	public void setCanEngineSpeed(Long canEngineSpeed) {
		this.canEngineSpeed = canEngineSpeed;
	}

	public Double getGpsSpkm() {
		return gpsSpkm;
	}

	public void setGpsSpkm(Double gpsSpkm) {
		this.gpsSpkm = gpsSpkm;
	}

}
