package com.dicv.cwp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.AlertType;

@Repository
public interface AlertTypeRepo extends CrudRepository<AlertType, Integer> {

	@Query("Select a from AlertType a where a.alertType=:type and a.isDeleted=0")
	public List<AlertType> getAlertTypeByType(@Param("type") String type);

}
