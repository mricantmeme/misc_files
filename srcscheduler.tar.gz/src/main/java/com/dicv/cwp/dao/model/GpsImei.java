package com.dicv.cwp.dao.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the GPS_IMEI database table.
 * 
 */
@Entity
@Table(name = "GPS_IMEI")
public class GpsImei implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GPS_IMEI_GPSIMEIID_GENERATOR", sequenceName = "GPS_IMEI_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GPS_IMEI_GPSIMEIID_GENERATOR")
	@Column(name = "GPS_IMEI_ID")
	private Integer gpsImeiId;

	@Column(name = "GPS_IMEI")
	private Long gpsImei;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "VEHICLE_ID")
	private Vehicle vehicle;

	public GpsImei() {
	}

	public Integer getGpsImeiId() {
		return this.gpsImeiId;
	}

	public void setGpsImeiId(Integer gpsImeiId) {
		this.gpsImeiId = gpsImeiId;
	}

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

}