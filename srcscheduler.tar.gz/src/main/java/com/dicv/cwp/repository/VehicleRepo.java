package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.VehicleListDto;

@Repository
public interface VehicleRepo extends CrudRepository<Vehicle, Long> {

	@Query("Select v from Vehicle v where v.isDeleted=0")
	public List<Vehicle> getAllVehicle();

	@Query("Select new com.dicv.cwp.dto.VehicleListDto(v.vehicleId,v.gpsImei.gpsImei,v.registrationId,v.userId) FROM Vehicle v where v.isDeleted=0")
	public List<VehicleListDto> loadAllVehicles();

	@Query("Select new com.dicv.cwp.dto.VehicleListDto(v.vehicleId,v.gpsImei.gpsImei,v.registrationId,v.userId) FROM "
			+ "Vehicle v where v.vehicleId=:vehicleId AND " + "v.isDeleted=0")
	public List<VehicleListDto> loadAllVehicles(@Param("vehicleId") Long vehicleId);

	@Query("Select new com.dicv.cwp.dto.VehicleListDto(v.vehicleId,v.gpsImei.gpsImei) FROM Vehicle v where v.isDeleted=0")
	public List<VehicleListDto> loadAllVehiclesAndImei();

	@Query("Select v FROM Vehicle v where v.vehicleId=:vehicleId and v.isDeleted=0")
	public Vehicle getVehicle(@Param("vehicleId") Long vehicleId);

	@Query("Select v FROM Vehicle v  where v.isDeleted=0 and v.runningStatus IN :runningStatus")
	public List<Vehicle> getRunningVehicleList(@Param("runningStatus") List<String> runningStatus);

	@Query("Select v FROM Vehicle v where v.gpsImei.gpsImei=:gpsImei and v.isDeleted=0")
	public Vehicle getVehicleByImei(@Param("gpsImei") Long gpsImei);

	@Query("Select v FROM Vehicle v  where v.isDeleted=0 and v.vehicleUpdateTime <=:timeDiff and v.runningStatus IN :runningStatus")
	public List<Vehicle> getUnReachedVehicle(@Param("runningStatus") List<String> runningStatus,
			@Param("timeDiff") Date timeDiff);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Vehicle g set g.lastProcessedGpsTime =:lastProcessedGpsTime where g.vehicleId =:vehicleId")
	public void updateLastUpdatedTime(@Param("lastProcessedGpsTime") Timestamp lastProcessedGpsTime,
			@Param("vehicleId") Long vehicleId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Vehicle v set v.runningStatus=:runningStatus,v.currentLat =:currentLat,v.currentLong =:currentLong,"
			+ "v.currentVehicleSpeed=:currentVehicleSpeed,v.gpsCog =:gpsCog,v.gpsHdop =:gpsHdop  "
			+ ",v.vehicleUpdateTime =:vehicleUpdateTime where v.vehicleId =:vehicleId")
	public void updateVehicleStatus(@Param("runningStatus") String runningStatus,
			@Param("currentLat") Double currentLat, @Param("currentLong") Double currentLong,
			@Param("currentVehicleSpeed") Integer currentVehicleSpeed, @Param("gpsCog") Integer gpsCog,
			@Param("gpsHdop") Double gpsHdop, @Param("vehicleUpdateTime") Timestamp vehicleUpdateTime,
			@Param("vehicleId") Long vehicleId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Vehicle v set v.runningStatus=:runningStatus where v.vehicleId =:vehicleId")
	public void updateVehicleStatus(@Param("runningStatus") String runningStatus, @Param("vehicleId") Long vehicleId);

	@Query("Select v from Vehicle v where v.isDeleted=0 order by v.lastProcessedGpsTime asc")
	public List<Vehicle> getAllVehicleByTripTime(Pageable pageable);

	@Query("Select v from Vehicle v where v.isDeleted=0 and v.defaultDriverUserId=:userId")
	public List<Vehicle> getVehicleListByDriver(@Param("userId") Integer userId);

}
