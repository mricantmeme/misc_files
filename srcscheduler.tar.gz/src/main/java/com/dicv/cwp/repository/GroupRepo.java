package com.dicv.cwp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.DicvGroup;

@Repository
public interface GroupRepo extends CrudRepository<DicvGroup, Integer> {

	@Query("Select v from DicvGroup v where v.isDeleted=0")
	public List<DicvGroup> getDicvGroup();

}
