package com.dicv.cwp.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.AlertSettings;
import com.dicv.cwp.dao.model.BatteryHealth;
import com.dicv.cwp.dao.model.BatteryHealthProcess;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.dto.GpsVehParamDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.AlertSettingsRepo;
import com.dicv.cwp.repository.BatteryHealthProcessRepo;
import com.dicv.cwp.repository.BatteryHealthRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class BatteryHealthService {

	@Autowired
	private BatteryHealthProcessRepo batteryProcessRepo;

	@Autowired
	private GpsParamService gpsParamService;

	@Autowired
	private AlertSettingsRepo alertSettingRepo;

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private BatteryHealthRepo batteryHealthRepo;

	@Autowired
	private GoogleAPIService addressUtil;

	@Value("${battery_health}")
	private String batteryHealth;

	private static final Logger LOGGER = Logger.getLogger(BatteryHealthService.class);

	@Scheduled(fixedDelay = 10000, initialDelay = 30000)
	public void schedulerProcess() {
		if (batteryHealth != null && batteryHealth.equals("Yes")) {
			LOGGER.info("Low Battery Health  Started");
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			startVehicleBatteryHealth();
			stopWatch.stop();
			LOGGER.info("Low Battery Health Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
		}

	}

	@Transactional
	public void startVehicleBatteryHealth() {
		AlertSettings alertSetings = alertSettingRepo.getAlertSetings();
		List<VehicleListDto> allVehicleList = vehicleService.getVehicleNoAndIMEI();
		if (allVehicleList != null && allVehicleList.size() > 0) {
			for (VehicleListDto veh : allVehicleList) {
				try {
					processVehicleBatteryAlert(alertSetings, veh);
				} catch (Exception ex) {
					LOGGER.error("Exception Low BatteryHealth Vehicle :: " + veh.getRegistrationId(), ex);
					continue;
				}
			}
		}
	}

	public void processVehicleBatteryAlert(AlertSettings alertSetings, VehicleListDto veh) {
		try {
			if (veh.getGpsImei() != null) {
				BatteryHealthProcess batteryProcess = batteryProcessRepo.getBatteryHealthProcess(veh.getVehicleId());
				if (batteryProcess == null) {
					batteryProcess = addToBatteryProcess(veh);
				} else {
					if (batteryProcess.getLowBatteryDetected() == 0) {
						checkForLowBattery(alertSetings, veh, batteryProcess);
					} else if (batteryProcess.getLowBatteryDetected() == 1) {
						checkForHighBattery(alertSetings, veh, batteryProcess);
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId(), ex);
		}
	}

	private BatteryHealthProcess addToBatteryProcess(VehicleListDto veh) {
		BatteryHealthProcess batteryProcess;
		batteryProcess = new BatteryHealthProcess();
		batteryProcess.setLowBatteryDetected(0);
		batteryProcess.setProcessTime(DicvUtil.getCurrentTimeStamp());
		batteryProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		batteryProcess.setVehicleId(veh.getVehicleId());
		batteryProcessRepo.save(batteryProcess);
		return batteryProcess;
	}

	private void checkForLowBattery(AlertSettings alertSetings, VehicleListDto veh,
			BatteryHealthProcess batteryProcess) {
		GpsVehParamDto gpsParamData = gpsParamService.collectGpsDataForLowBatteryHealth(veh.getGpsImei(),
				batteryProcess.getProcessTime(), alertSetings.getBatteryHealth());
		if (gpsParamData != null) {
			batteryProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsParamData.getGpsTime()));
			batteryProcess.setLowBatteryDetected(1);
			updateBatteryProcessTime(batteryProcess);
			addBatteryHealth(veh, gpsParamData);
		} else {
			updateMaximumGpsDataTimestamp(veh, batteryProcess);
		}
	}

	private void updateMaximumGpsDataTimestamp(VehicleListDto veh, BatteryHealthProcess batteryProcess) {
		GpsParameterDto gpsVehParamDto = gpsParamService.getMaxofGpsParameterForAlert(veh.getGpsImei());
		if (gpsVehParamDto != null) {
			batteryProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsVehParamDto.getGpsTime()));
			updateBatteryProcessTime(batteryProcess);
		}
	}

	private void checkForHighBattery(AlertSettings alertSetings, VehicleListDto veh,
			BatteryHealthProcess batteryProcess) {
		GpsVehParamDto gpsParamData = gpsParamService.collectGpsDataForHighBatteryHealth(veh.getGpsImei(),
				batteryProcess.getProcessTime(), alertSetings.getBatteryHealth());
		if (gpsParamData != null) {
			batteryProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsParamData.getGpsTime()));
			batteryProcess.setLowBatteryDetected(0);
			updateBatteryProcessTime(batteryProcess);
		} else {
			updateMaximumGpsDataTimestamp(veh, batteryProcess);
		}
	}

	private void updateBatteryProcessTime(BatteryHealthProcess batteryProcess) {
		batteryProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		batteryProcessRepo.save(batteryProcess);
	}

	private void addBatteryHealth(VehicleListDto veh, GpsVehParamDto gpsParamData) {
		BatteryHealth health = new BatteryHealth();
		health.setBatteryLevel(gpsParamData.getBatteryHealth());
		health.setGpsTime(DicvUtil.getTimeStampFromDate(gpsParamData.getGpsTime()));
		health.setCreatedAt(DicvUtil.getCurrentTimeStamp());
		health.setLatitude(gpsParamData.getGpsLatitude());
		health.setLongitude(gpsParamData.getGpsLongitude());
		Address address = addressUtil.getAddress(gpsParamData.getGpsLatitude(), gpsParamData.getGpsLongitude());
		if (address.getResponse()) {
			health.setLocation(address.getAddress());
			health.setGeoResponse(2);
		} else {
			health.setGeoResponse(0);
		}
		health.setVehicleId(veh.getVehicleId());
		health.setEmailSent(0);
		batteryHealthRepo.save(health);
	}

}
