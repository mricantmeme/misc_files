package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Where;

/**
 * The persistent class for the SCHEDULED_TRIP_LEG database table.
 * 
 */
@Entity
@Table(name = "SCHEDULED_TRIP_LEG")
@NamedQueries({
		@NamedQuery(query = "Select v.vehicleId from ScheduledTripLeg s join s.vehicle v", name = "findAllVehicleIdFromScheduledTripLeg"),
		@NamedQuery(query = "Select st.tripStatus from ScheduledTripLeg s join s.scheduledTrip st join s.dicvUser u where u.userId=:userId ", name = "findScheduledTripStatusForDriver"),
		@NamedQuery(query = "Select st.tripStatus from ScheduledTripLeg s join s.scheduledTrip st join s.vehicle u where u.vehicleId=:vehicleId ", name = "findScheduledTripStatusForVehicle"),
		@NamedQuery(name = "ScheduledTripLeg.findAll", query = "SELECT s FROM ScheduledTripLeg s") })
public class ScheduledTripLeg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SCHEDULED_TRIP_LEG_SCHEDULEDTRIPLEGID_GENERATOR", sequenceName = "SCHEDULEDTRIPLEG_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SCHEDULED_TRIP_LEG_SCHEDULEDTRIPLEGID_GENERATOR")
	@Column(name = "SCHEDULED_TRIP_LEG_ID")
	private Integer scheduledTripLegId;

	@Column(name = "END_POINT_LAT")
	private Double endPointLat;

	@Column(name = "END_POINT_LONG")
	private Double endPointLong;

	@Column(name = "MODIFIED_DATE_TIME")
	private Timestamp modifiedDateTime;

	@Column(name = "START_POINT_LAT")
	private Double startPointLat;

	@Column(name = "START_POINT_LONG")
	private Double startPointLong;

	@Column(name = "IS_DELETED")
	private int isDeleted;

	@Column(name = "CREATED_DATE")
	private Timestamp createdDate;

	// bi-directional many-to-one association to ScheduledDispatch
	@OneToMany(mappedBy = "scheduledTripLeg", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Fetch(value = FetchMode.SUBSELECT)
	@Where(clause = "IS_DELETED=0")
	private List<ScheduledDispatch> scheduledDispatch;

	// bi-directional many-to-one association to DicvUser
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "USER_ID")
	private DicvUser dicvUser;

	// bi-directional many-to-one association to ScheduledTrip
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "SCHEDULED_TRIP_ID")
	private ScheduledTrip scheduledTrip;

	// bi-directional many-to-one association to Vehicle
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "VEHICLE_ID")
	private Vehicle vehicle;

	// bi-directional many-to-one association to DicvUser for column updated by
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "UPDATED_BY")
	private DicvUser dicvUserUpdatedBy;

	public ScheduledTripLeg() {
	}

	public Integer getScheduledTripLegId() {
		return this.scheduledTripLegId;
	}

	public void setScheduledTripLegId(Integer scheduledTripLegId) {
		this.scheduledTripLegId = scheduledTripLegId;
	}

	public Double getEndPointLat() {
		return this.endPointLat;
	}

	public void setEndPointLat(Double endPointLat) {
		this.endPointLat = endPointLat;
	}

	public Double getEndPointLong() {
		return this.endPointLong;
	}

	public void setEndPointLong(Double endPointLong) {
		this.endPointLong = endPointLong;
	}

	public Timestamp getModifiedDateTime() {
		return this.modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public Double getStartPointLat() {
		return this.startPointLat;
	}

	public void setStartPointLat(Double startPointLat) {
		this.startPointLat = startPointLat;
	}

	public Double getStartPointLong() {
		return this.startPointLong;
	}

	public void setStartPointLong(Double startPointLong) {
		this.startPointLong = startPointLong;
	}

	public List<ScheduledDispatch> getScheduledDispatch() {
		return this.scheduledDispatch;
	}

	public void setScheduledDispatch(List<ScheduledDispatch> scheduledDispatches) {
		this.scheduledDispatch = scheduledDispatches;
	}

	public ScheduledDispatch addScheduledDispatch(
			ScheduledDispatch scheduledDispatch) {
		getScheduledDispatch().add(scheduledDispatch);
		scheduledDispatch.setScheduledTripLeg(this);

		return scheduledDispatch;
	}

	public ScheduledDispatch removeScheduledDispatch(
			ScheduledDispatch scheduledDispatch) {
		getScheduledDispatch().remove(scheduledDispatch);
		scheduledDispatch.setScheduledTripLeg(null);

		return scheduledDispatch;
	}

	public DicvUser getDicvUser() {
		return this.dicvUser;
	}

	public void setDicvUser(DicvUser dicvUser) {
		this.dicvUser = dicvUser;
	}

	public ScheduledTrip getScheduledTrip() {
		return this.scheduledTrip;
	}

	public void setScheduledTrip(ScheduledTrip scheduledTrip) {
		this.scheduledTrip = scheduledTrip;
	}

	public Vehicle getVehicle() {
		return this.vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public DicvUser getDicvUserUpdatedBy() {
		return dicvUserUpdatedBy;
	}

	public void setDicvUserUpdatedBy(DicvUser dicvUserUpdatedBy) {
		this.dicvUserUpdatedBy = dicvUserUpdatedBy;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	@Override
	public String toString() {
		return "ScheduledTripLeg [scheduledTripLegId=" + scheduledTripLegId + ", endPointLat=" + endPointLat
				+ ", endPointLong=" + endPointLong + ", modifiedDateTime=" + modifiedDateTime + ", startPointLat="
				+ startPointLat + ", startPointLong=" + startPointLong + ", isDeleted=" + isDeleted + ", createdDate="
				+ createdDate + ", scheduledDispatch=" + scheduledDispatch + ", dicvUser=" + dicvUser
				+ ", scheduledTrip=" + scheduledTrip + ", vehicle=" + vehicle + ", dicvUserUpdatedBy="
				+ dicvUserUpdatedBy + "]";
	}

}