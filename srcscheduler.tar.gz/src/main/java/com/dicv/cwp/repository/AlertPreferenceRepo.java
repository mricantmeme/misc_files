package com.dicv.cwp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.AlertPreference;

@Repository
public interface AlertPreferenceRepo extends CrudRepository<AlertPreference, Integer> {

	@Query("Select v from AlertPreference v where v.dicvUser.userId=:userId and v.isDeleted=0")
	public List<AlertPreference> getAlertPreference(@Param("userId") Integer userId);

}
