package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.KPIScalingFactor;
import com.dicv.cwp.dao.model.Trip;
import com.dicv.cwp.dao.model.TripSpeedingLocations;
import com.dicv.cwp.dao.model.TripStopLocations;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.GpsParamRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.KPIRepo;
import com.dicv.cwp.repository.TripRepo;
import com.dicv.cwp.repository.TripSeedingLocationsRepo;
import com.dicv.cwp.repository.TripStopLocationsRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvUtil;
import com.dicv.cwp.utils.DistanceCalculation;

@Service
public class TripAnalysis {

	private static final Logger LOGGER = LoggerFactory.getLogger(TripAnalysis.class);

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Autowired
	private GpsParamRepo gpsRepo;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private TripRepo tripRepo;

	@Autowired
	private TripStopLocationsRepo tripStopRepo;

	@Autowired
	private TripSeedingLocationsRepo tripSpeedRepo;

	@Autowired
	private KPIRepo kpiRepo;

	@Value("${trip_analysis}")
	private String tripAnalysisProcess;

	@Value("${map_url_api}")
	private String mapUrlAPI;

	@Scheduled(fixedDelay = 1000)
	public void startTripAnalysis() {
		if (tripAnalysisProcess.equals("Yes"))
			process();
	}

	public void process() {

		List<Trip> tripList = tripRepo.getTripListByStatus("COMPLETED", 2, new PageRequest(0, 50));
		if (tripList != null && tripList.size() > 0) {
			StopWatch watch = new StopWatch();
			watch.start();
			KPIScalingFactor kpi = kpiRepo.findAll().get(0);
			processingTripAnalysis(tripList, kpi);
			watch.stop();
		}
	}

	public void processingTripAnalysis(List<Trip> tripList, KPIScalingFactor kpi) {

		for (Trip tripDetails : tripList) {
			setProcessStatus(tripDetails, 10);
			Vehicle veh = vehicleRepo.getVehicle(tripDetails.getVehicleId());
			try {
				if (veh != null && veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null) {
					processTripAnalysis(kpi, tripDetails, veh);
				}
			} catch (Exception ex) {
				LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId() + ex.getMessage());
				setProcessStatus(tripDetails, 5);
				continue;
			}
		}

	}

	@Transactional
	private void setProcessStatus(Trip tripDetails, Integer processStatus) {
		tripDetails.setProcessStatus(processStatus);
		tripRepo.save(tripDetails);
	}

	public void processTripAnalysis(Long tripId) {
		Trip tripDetails = tripRepo.findOne(tripId);
		Vehicle veh = vehicleRepo.getVehicle(tripDetails.getVehicleId());
		try {
			if (veh != null && veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null) {
				KPIScalingFactor kpi = kpiRepo.findAll().get(0);
				processTripAnalysis(kpi, tripDetails, veh);
			} else {
				setProcessStatus(tripDetails, 6);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId() + ex.getMessage());
		}
	}

	@Transactional
	private void processTripAnalysis(KPIScalingFactor kpi, Trip tripDetails, Vehicle veh) {
		Long vehicleTotalIdleTime = 0l;
		Integer vehNoOfStops = 0;
		Long gpsImei = veh.getGpsImei().getGpsImei();
		Double vehMaxSpeed = 0d;
		Double vehMaxSpeedLat = null;
		Double vehMaxSpeedLong = null;
		Double vehicleDistance = 0d;
		Double vehicleInvalidSpeed = 0d;
		Long greenBandTime = 0l;
		Double greenBandDistance = 0d;
		Long redBandTime = 0l;
		Long speedViolationTime = 0l;
		Long timeIn0To20km = 0l;
		Long timeIn21To40km = 0l;
		Long timeIn41To60km = 0l;
		Long timeIn61To80km = 0l;
		Long timeInOver80km = 0l;
		Long yellowBandTime = 0l;
		Long economyBandTime = 0l;
		Double economyBandDistance = 0d;
		Double economicDriving = 0d;
		Double vehicleDistanceSum = 0d;
		Long elapsedTime = null;
		Long engineOnTime = 0l;
		Long totalDriveTime = 0l;
		Double avgSpeed = 0d;
		Long gpsParamId = tripDetails.getStartGpsParamId();
		Double speedAdherence = 100d;
		Double idling = 100d;
		Double harshBrakingDbl = 100d;
		Double harshAccelerationDbl = 100d;
		Double harshCorneringDbl = 100d;
		if (veh.getVehicleMaxSpeed() == null)
			veh.setVehicleMaxSpeed(80);
		tripSpeedRepo.deleteTripSpeedingLocations(tripDetails.getTripId());
		tripStopRepo.deleteTripStopLocations(tripDetails.getTripId());

		if (tripDetails.getStartGpsParamId() == null) {

			List<Long> startId = gpsVehicleRepo.getGpsParamId(gpsImei, tripDetails.getTripStartTime(),
					new PageRequest(0, 1));
			if (startId != null && startId.size() > 0) {
				tripDetails.setStartGpsParamId(startId.get(0));
				gpsParamId = tripDetails.getStartGpsParamId();
			}
		}
		if (tripDetails.getStopGpsParamId() == null) {
			List<Long> stopId = gpsVehicleRepo.getGpsParamId(gpsImei, tripDetails.getTripEndTime(),
					new PageRequest(0, 1));
			if (stopId != null && stopId.size() > 0)
				tripDetails.setStopGpsParamId(stopId.get(0));
		}

		if (tripDetails.getStartGpsParamId() != null && tripDetails.getStopGpsParamId() != null) {
			Long totalCount = gpsVehicleRepo.fetchCountGpsDataForTripAnalysis(gpsImei, tripDetails.getStartGpsParamId(),
					tripDetails.getStopGpsParamId());
			if (totalCount > 0) {
				Integer iterCount = totalCount.intValue() <= 1000 ? 1 : totalCount.intValue() / 1000;
				if ((totalCount.intValue() % 1000) > 0)
					iterCount = iterCount + 1;
				for (int i = 1; i <= iterCount; i++) {

					List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.fetchGpsDataForTripAnalysis(gpsImei,
							gpsParamId, tripDetails.getStopGpsParamId(), new PageRequest(i - 1, 1000));
					if (gpsParamData != null && gpsParamData.size() > 1) {

						Integer totalRecords = gpsParamData.size();
						Integer gpsRecordCount = 0;
						for (GpsVehParameterDto gpsVehicleParam : gpsParamData) {

							gpsRecordCount = gpsRecordCount + 1;

							if (gpsRecordCount >= totalRecords) {
								gpsParamId = gpsVehicleParam.getGpsVehicleParamId();
								break;
							}
							GpsVehParameterDto gpsVehicleParamNext = gpsParamData.get(gpsRecordCount);
							if (!checkGpsNullValue(gpsVehicleParam, gpsVehicleParamNext))
								continue;

							Long vehicleDiffInSeconds = (gpsVehicleParamNext.getGpsTime().getTime()
									- gpsVehicleParam.getGpsTime().getTime()) / 1000;
							if (vehicleDiffInSeconds <= 0) {
								continue;
							}
							vehicleDistance = DistanceCalculation.distance(gpsVehicleParam.getGpsLatitude(),
									gpsVehicleParam.getGpsLongitude(), gpsVehicleParamNext.getGpsLatitude(),
									gpsVehicleParamNext.getGpsLongitude());
							vehicleInvalidSpeed = 0d;

							if (vehicleDistance > 0 && vehicleDiffInSeconds > 0) {
								vehicleInvalidSpeed = ((vehicleDistance / vehicleDiffInSeconds) * 3600);
							}
							if (vehicleDiffInSeconds > 900) {
								continue;
							}
							// 15 Mins Validation for gps data if
							if (vehicleInvalidSpeed > 130 || vehicleDiffInSeconds > 900) {
								continue;
							}
							// Total Distance
							vehicleDistanceSum = vehicleDistanceSum + vehicleDistance;
							vehicleDistanceSum = roundOffDecimal(vehicleDistanceSum);
							// Engine On Time
							if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParamNext.getEngineON() == 1) {
								engineOnTime = engineOnTime + vehicleDiffInSeconds;
								// Engine Idle Time
								if (gpsVehicleParam.getGpsSpkm() == 0 && gpsVehicleParamNext.getGpsSpkm() == 0) {
									vehicleTotalIdleTime = vehicleTotalIdleTime + vehicleDiffInSeconds;
								}
								// Engine Run Time
								if (gpsVehicleParam.getGpsSpkm() > 0 && gpsVehicleParamNext.getGpsSpkm() > 0) {
									totalDriveTime = totalDriveTime + vehicleDiffInSeconds;
								}

								// Maximum Speed
								if (veh.getVehicleMaxSpeed() < gpsVehicleParamNext.getGpsSpkm()) {
									vehMaxSpeed = gpsVehicleParamNext.getGpsSpkm().doubleValue();
									vehMaxSpeedLat = gpsVehicleParamNext.getGpsLatitude();
									vehMaxSpeedLong = gpsVehicleParamNext.getGpsLongitude();
									vehMaxSpeed = roundOffDecimal(vehMaxSpeed);
									saveTripSpeedingLoc(tripDetails, gpsVehicleParam);
								}

								// Speed Violation Time
								if (gpsVehicleParam.getGpsSpkm() > veh.getVehicleMaxSpeed()
										&& gpsVehicleParamNext.getGpsSpkm() > veh.getVehicleMaxSpeed()) {
									speedViolationTime = speedViolationTime + vehicleDiffInSeconds;
								}

								// Speed Band Calculations
								if (gpsVehicleParam.getGpsSpkm() >= 0 && gpsVehicleParam.getGpsSpkm() <= 20) {
									timeIn0To20km = timeIn0To20km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 21 && gpsVehicleParam.getGpsSpkm() <= 40) {
									timeIn21To40km = timeIn21To40km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 41 && gpsVehicleParam.getGpsSpkm() <= 60) {
									timeIn41To60km = timeIn41To60km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 61 && gpsVehicleParam.getGpsSpkm() <= 80) {
									timeIn61To80km = timeIn61To80km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 81) {
									timeInOver80km = timeInOver80km + vehicleDiffInSeconds;
								}

								// Economy Band Calculations

								if (gpsVehicleParam.getCanEngineSpeed() != null) {

									if (tripDetails.getIsCanParam() == null || tripDetails.getIsCanParam() != 1) {
										tripDetails.setIsCanParam(1);
									}

									if (veh.getVariant() != null) {
										if ("MDT".equals(veh.getVariant())) {
											if (gpsVehicleParam.getCanEngineSpeed() >= 1200
													&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
												greenBandDistance = greenBandDistance + vehicleDistance;
												greenBandTime = greenBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 2200
													&& gpsVehicleParam.getCanEngineSpeed() <= 3000) {
												yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 3001) {
												redBandTime = redBandTime + vehicleDiffInSeconds;
											}
											if (gpsVehicleParam.getCanEngineSpeed() >= 1200
													&& gpsVehicleParam.getCanEngineSpeed() <= 2200) {
												economyBandDistance = economyBandDistance + vehicleDistance;
												economyBandTime = economyBandTime + vehicleDiffInSeconds;
											}
										} else if ("HDT".equals(veh.getVariant())) {
											if (gpsVehicleParam.getCanEngineSpeed() >= 1200
													&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
												greenBandDistance = greenBandDistance + vehicleDistance;
												greenBandTime = greenBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 2100
													&& gpsVehicleParam.getCanEngineSpeed() <= 2700) {
												yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 2701) {
												redBandTime = redBandTime + vehicleDiffInSeconds;
											}
											if (gpsVehicleParam.getCanEngineSpeed() >= 1000
													&& gpsVehicleParam.getCanEngineSpeed() <= 2000) {
												economyBandDistance = economyBandDistance + vehicleDistance;
												economyBandTime = economyBandTime + vehicleDiffInSeconds;
											}
										} else if ("THUNDERBOLT".equals(veh.getVariant())) {
											if (gpsVehicleParam.getCanEngineSpeed() >= 900
													&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
												greenBandDistance = greenBandDistance + vehicleDistance;
												greenBandTime = greenBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 1700
													&& gpsVehicleParam.getCanEngineSpeed() <= 2500) {
												yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
											} else if (gpsVehicleParam.getCanEngineSpeed() >= 2501) {
												redBandTime = redBandTime + vehicleDiffInSeconds;
											}
											if (gpsVehicleParam.getCanEngineSpeed() >= 900
													&& gpsVehicleParam.getCanEngineSpeed() <= 1700) {
												economyBandDistance = economyBandDistance + vehicleDistance;
												economyBandTime = economyBandTime + vehicleDiffInSeconds;
											}
										}
									}

								}
							}

						} // Gps For Loop Ending

					}
				}

				// Economic Driving

				Integer harshAcceleration = gpsRepo.countofHarshEvents(tripDetails.getTripStartTime(),
						tripDetails.getTripEndTime(), veh.getGpsImei().getGpsImei(), "harshAcceleration");
				Integer harshBraking = gpsRepo.countofHarshEvents(tripDetails.getTripStartTime(),
						tripDetails.getTripEndTime(), veh.getGpsImei().getGpsImei(), "harshBraking");
				Integer harshCornering = gpsRepo.countofHarshEvents(tripDetails.getTripStartTime(),
						tripDetails.getTripEndTime(), veh.getGpsImei().getGpsImei(), "harshCornering");

				harshAccelerationDbl = calculateHarshEvents(kpi.getHarshAcceleration(), totalDriveTime,
						harshAcceleration);
				harshBrakingDbl = calculateHarshEvents(kpi.getHarshBraking(), totalDriveTime, harshBraking);
				harshCorneringDbl = calculateHarshEvents(kpi.getHarshCornering(), totalDriveTime, harshCornering);

				economicDriving = economicDrivingCalculation(harshBrakingDbl, harshAccelerationDbl, harshCorneringDbl);

				processTripStopppings(veh, tripDetails);

				speedAdherence = speedingCalculation(kpi.getSpeeding(), speedViolationTime, totalDriveTime);

				idling = idlingCalculation(kpi.getIdling(), engineOnTime, vehicleTotalIdleTime);

				avgSpeed = avgSpeedCalc(vehicleDistanceSum, totalDriveTime);

				if ((tripDetails.getTripEndTime() != null && tripDetails.getTripStartTime() != null)) {
					elapsedTime = (tripDetails.getTripEndTime().getTime() - tripDetails.getTripStartTime().getTime())
							/ 1000;
				}
			}
			updateTripAnalysis(tripDetails, vehicleTotalIdleTime, vehNoOfStops, vehMaxSpeed, vehMaxSpeedLat,
					vehMaxSpeedLong, greenBandTime, greenBandDistance, redBandTime, speedViolationTime, timeIn0To20km,
					timeIn21To40km, timeIn41To60km, timeIn61To80km, timeInOver80km, yellowBandTime, economyBandTime,
					economyBandDistance, economicDriving, vehicleDistanceSum, elapsedTime, engineOnTime, totalDriveTime,
					avgSpeed, vehicleTotalIdleTime, speedAdherence, idling);
		} else {
			LOGGER.info("Trip Analysis Not Performed " + tripDetails.getTripId());
			tripDetails.setProcessStatus(4);
			tripDetails.setModifiedDate(DicvUtil.getTimestamp());
			tripRepo.save(tripDetails);
		}

	}

	private void saveTripSpeedingLoc(Trip tripDetails, GpsVehParameterDto gpsVehicleParam) {
		TripSpeedingLocations tripSpeed = new TripSpeedingLocations(null, tripDetails.getTripId(),
				gpsVehicleParam.getGpsSpkm(), gpsVehicleParam.getGpsLatitude(), gpsVehicleParam.getGpsLongitude(),
				gpsVehicleParam.getGpsTime());
		tripSpeedRepo.save(tripSpeed);
	}

	private void processTripStopppings(Vehicle vehicle, Trip tripDetails) {
		Date processedTime = new Date(tripDetails.getTripStartTime().getTime());
		while (true) {
			GpsVehParameterDto stopLocation = gpsRepo.getGpsStopLocation(vehicle.getGpsImei().getGpsImei(),
					tripDetails.getTripStartTime(), processedTime, tripDetails.getTripEndTime(), false);
			if (stopLocation != null) {
				GpsVehParameterDto startLocationTime = gpsRepo.getGpsStopLocation(vehicle.getGpsImei().getGpsImei(),
						tripDetails.getTripStartTime(), stopLocation.getGpsTime(), tripDetails.getTripEndTime(), true);
				if (startLocationTime != null) {
					processedTime = new Date(startLocationTime.getGpsTime().getTime());
					if (((startLocationTime.getGpsTime().getTime() - stopLocation.getGpsTime().getTime())
							/ 1000) < 120) {
						continue;
					}
					TripStopLocations tripStopLocations = new TripStopLocations();
					tripStopLocations.setDuration(
							(startLocationTime.getGpsTime().getTime() - stopLocation.getGpsTime().getTime()));
					tripStopLocations.setTrip(tripDetails);
					tripStopLocations.setStopLatitude(stopLocation.getGpsLatitude());
					tripStopLocations.setStopLongitude(stopLocation.getGpsLongitude());
					tripStopLocations.setStartTime(new Timestamp(stopLocation.getGpsTime().getTime()));
					tripStopLocations.setStopTime(new Timestamp(startLocationTime.getGpsTime().getTime()));
					tripStopLocations.setIsStopped(1);
					tripStopRepo.save(tripStopLocations);
				} else {
					break;
				}
			} else {
				break;
			}
		}
	}

	private Double avgSpeedCalc(Double vehicleDistanceSum, Long totalDriveTime) {
		if (vehicleDistanceSum == 0 || totalDriveTime == 0)
			return 0d;
		Double avgSpeed = 0d;
		avgSpeed = (vehicleDistanceSum.doubleValue() / (totalDriveTime.doubleValue() / 3600d));
		avgSpeed = roundOffDecimal(avgSpeed);
		return avgSpeed;
	}

	private boolean checkGpsNullValue(GpsVehParameterDto gpsVehicleParam, GpsVehParameterDto gpsVehicleParamNext) {
		if (gpsVehicleParam.getGpsLatitude() == null || gpsVehicleParam.getGpsLongitude() == null
				|| gpsVehicleParam.getGpsSpkm() == null || gpsVehicleParam.getGpsTime() == null
				|| gpsVehicleParam.getEngineON() == null || gpsVehicleParamNext.getGpsLatitude() == null
				|| gpsVehicleParamNext.getGpsLongitude() == null || gpsVehicleParamNext.getGpsSpkm() == null
				|| gpsVehicleParamNext.getGpsTime() == null || gpsVehicleParamNext.getEngineON() == null) {
			return false;
		}
		return true;
	}

	private Double calculateHarshEvents(Integer kpi, Long totalDriveTime, Integer harshTotal) {
		Double harshEvent = 100d;
		if (totalDriveTime > 0 && harshTotal > 0) {
			harshEvent = 100d - (double) ((harshTotal * kpi) / (totalDriveTime.doubleValue() / 3600d));
			harshEvent = roundOffDecimal(harshEvent);
		}
		return harshEvent;
	}

	private Double roundOffDecimal(Double driverScore) {
		if (driverScore > 0)
			driverScore = Math.round(driverScore * 100D) / 100D;
		return driverScore;
	}

	private Double economicDrivingCalculation(Double harshBrakingDbl, Double harshAccelerationDbl,
			Double harshCorneringDbl) {
		Double economicDriving = 100d;
		economicDriving = (harshAccelerationDbl + harshBrakingDbl + harshCorneringDbl) / 3;
		economicDriving = roundOffDecimal(economicDriving);
		if (economicDriving > 100)
			economicDriving = 100d;
		if (economicDriving < 0)
			economicDriving = 0d;
		return economicDriving;
	}

	private Double idlingCalculation(Integer kpi, Long engineRunTime, Long engineIdleTime) {
		Double idling = 100d;
		if (engineIdleTime != null && engineRunTime != null && engineRunTime != 0) {
			idling = (double) (100 - ((engineIdleTime.doubleValue() / engineRunTime.doubleValue()) * kpi * 100));
			idling = roundOffDecimal(idling);
			if (idling > 100)
				idling = 100d;
			if (idling < 0)
				idling = 0d;
		}
		return idling;
	}

	private Double speedingCalculation(Integer kpi, Long speedViolationTime, Long totalDriveTime) {
		Double speeding = 100d;
		if (speedViolationTime > 0 && totalDriveTime > 0) {
			speeding = (double) (100 - ((speedViolationTime.doubleValue() / totalDriveTime.doubleValue()) * kpi * 100));
			speeding = roundOffDecimal(speeding);
			if (speeding > 100)
				speeding = 100d;
			if (speeding < 0)
				speeding = 0d;

		}
		return speeding;
	}

	private void updateTripAnalysis(Trip tripDetails, Long vehicleTotalIdleTime, Integer vehNoOfStops,
			Double vehMaxSpeed, Double vehMaxSpeedLat, Double vehMaxSpeedLong, Long greenBandTime,
			Double greenBandDistance, Long redBandTime, Long speedViolationTime, Long timeIn0To20km,
			Long timeIn21To40km, Long timeIn41To60km, Long timeIn61To80km, Long timeInOver80km, Long yellowBandTime,
			Long economyBandTime, Double economyBandDistance, Double economicDriving, Double vehicleDistanceSum,
			Long elapsedTime, Long engineOnTime, Long totalDriveTime, Double avgSpeed, Long vehicleIdleTime,
			Double speedAdherence, Double idling) {
		tripDetails.setElapsedTime(elapsedTime);
		tripDetails.setTripDistance(vehicleDistanceSum);
		tripDetails.setAverageVehicleSpeed(avgSpeed);
		tripDetails.setDrivingTime(totalDriveTime);
		tripDetails.setVehicleIdleTime(vehicleTotalIdleTime);
		tripDetails.setEconomicDriving(economicDriving);
		tripDetails.setEconomyBandDistance(economyBandDistance);
		tripDetails.setEconomyBandTime(economyBandTime);
		tripDetails.setEngineIdleTimeRpm(vehicleTotalIdleTime);
		tripDetails.setMaxSpeedLat(vehMaxSpeedLat);
		tripDetails.setMaxSpeedLong(vehMaxSpeedLong);
		tripDetails.setEngineRunHours(engineOnTime);
		tripDetails.setGreenBandDistance(greenBandDistance);
		tripDetails.setGreenBandTime(greenBandTime);
		tripDetails.setMaximumSpeed(vehMaxSpeed.intValue());
		tripDetails.setModifiedDate(DicvUtil.getTimestamp());
		tripDetails.setNosOfStop(vehNoOfStops);
		tripDetails.setProcessStatus(3);
		tripDetails.setRedBandTime(redBandTime);
		tripDetails.setTimeIn0To20km(timeIn0To20km);
		tripDetails.setTimeIn21To40km(timeIn21To40km);
		tripDetails.setTimeIn41To60km(timeIn41To60km);
		tripDetails.setTimeIn61To80km(timeIn61To80km);
		tripDetails.setTimeInOver80km(timeInOver80km);
		tripDetails.setSpeedViolationTime(speedViolationTime);
		tripDetails.setVehicleIdleTime(vehicleIdleTime);
		tripDetails.setEconomicDriving(economicDriving);
		tripDetails.setYellowBandTime(yellowBandTime);
		tripDetails.setIdling(idling);
		tripDetails.setSpeeding(speedAdherence);
		tripRepo.save(tripDetails);

	}

}