package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.DeviceHealth;
import com.dicv.cwp.dao.model.DicvGroup;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.GpsVehParamDto;
import com.dicv.cwp.repository.DeviceHealthRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.GroupRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class DeviceHealthReport {

	@Autowired
	private GpsVehicleRepo gpsVehicleParamRepo;

	@Value("${device_health_report}")
	private String deviceHealthSchedular;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private DeviceHealthRepo deviceHealthRepo;

	@Autowired
	private GroupRepo groupRepo;

	private static final Logger LOGGER = LoggerFactory.getLogger(DeviceHealthReport.class);

	@Scheduled(fixedDelay = 300000, initialDelay = 300000)
	public void schedulerProcess() {
		try {
			if (deviceHealthSchedular != null && deviceHealthSchedular.equals("Yes")) {
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				List<Vehicle> vehicleList = vehicleRepo.getAllVehicle();
				Map<Integer, String> map = new HashMap<Integer, String>();
				getGroupMap(map);
				if (vehicleList != null && vehicleList.size() > 0) {
					String name = null;
					for (Vehicle veh : vehicleList) {
						name = null;
						if (veh.getRootAdminGroupId() != null)
							name = map.get(veh.getRootAdminGroupId());
						updateDeviceHealthData(veh, name);
					}
				}
				stopWatch.stop();
				LOGGER.info(
						"Device Health Report Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Updating Device Health Report " + ex);
		}

	}

	@Transactional
	private void updateDeviceHealthData(Vehicle veh, String groupName) {
		try {

			DeviceHealth deviceHealth = deviceHealthRepo.getDeviceHealth(veh.getVehicleId());

			if (deviceHealth == null) {
				deviceHealth = saveNewDeviceReport(veh, groupName);
			}
			if (veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null) {
				deviceHealth.setGpsImei(veh.getGpsImei().getGpsImei());
				List<GpsVehParamDto> gpsVehParamDto = gpsVehicleParamRepo
						.getGpsParamDataforDeviceReport(veh.getGpsImei().getGpsImei(), new PageRequest(0, 1));
				if (gpsVehParamDto != null && gpsVehParamDto.size() > 0) {
					if (gpsVehParamDto.get(0).getVehicleLastUpdateON() != null) {
						deviceHealth
								.setCanVehicleUpdateTime(getTimestamp(gpsVehParamDto.get(0).getVehicleLastUpdateON()));
					} else {
						deviceHealth.setCanVehicleUpdateTime(
								gpsVehicleParamRepo.getLatestVehicleUpdatedTimestamp(veh.getGpsImei().getGpsImei()));
					}
					deviceHealth.setDeviceBatery(gpsVehParamDto.get(0).getDeviceBattery());
					deviceHealth.setGpsTime(getTimestamp(gpsVehParamDto.get(0).getGpsTime()));
					deviceHealth.setGpsVolt(gpsVehParamDto.get(0).getGpsVolt());
					deviceHealth.setSignalStrength(gpsVehParamDto.get(0).getSignalStrength());
				}
			}
			deviceHealth.setGroupName(groupName);
			deviceHealth.setRegistrationId(veh.getRegistrationId());
			deviceHealth.setUpdateTime(DicvUtil.getTimestamp());
			deviceHealthRepo.save(deviceHealth);

		} catch (Exception ex) {
			LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId(), ex);
		}
	}

	private DeviceHealth saveNewDeviceReport(Vehicle veh, String groupName) {
		DeviceHealth deviceHealth = new DeviceHealth();
		deviceHealth.setVehicle(veh);
		deviceHealth.setGroupName(groupName);
		deviceHealth.setRegistrationId(veh.getRegistrationId());
		deviceHealth.setGpsImei(null);
		if (veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null)
			deviceHealth.setGpsImei(veh.getGpsImei().getGpsImei());
		deviceHealth = deviceHealthRepo.save(deviceHealth);
		return deviceHealth;
	}

	private void getGroupMap(Map<Integer, String> map) {
		List<DicvGroup> groupLiist = groupRepo.getDicvGroup();
		if (groupLiist != null) {
			for (DicvGroup id : groupLiist) {
				map.put(id.getGroupId(), id.getGroupName());
			}
		}
	}

	private Timestamp getTimestamp(Date date) {
		if (date == null)
			return null;
		return new java.sql.Timestamp(date.getTime());
	}

}