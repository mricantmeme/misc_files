package com.dicv.cwp.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.Trip;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.repository.TripRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class TripAddressUpdate {

	private static Logger LOGGER = Logger.getLogger(TripAddressUpdate.class);

	@Autowired
	private TripRepo tripRepo;

	@Autowired
	private GoogleAPIService addressUtil;

	@Value("${map_url_api}")
	private String mapUrlAPI;

	@Value("${trip_address_update}")
	private String tripFromAddress;

	@Scheduled(fixedDelay = 10000)
	public void getTripAddress() {
		if (tripFromAddress.equals("Yes")) {
			List<Long> tripList = tripRepo.getTripListForAddressUpdate(new PageRequest(0, 100));
			if (tripList != null && tripList.size() > 0) {
				for (Long trip : tripList) {
					try {
						updateTripAddress(trip);
					} catch (Exception ex) {
						LOGGER.debug("Exception for Address Update ", ex);
					}
				}
			}
		}
	}

	@Transactional
	private void updateTripAddress(Long tripId) {
		Trip trip = tripRepo.findOne(tripId);
		trip.setGeoResponse(2);
		Address address = addressUtil.getAddress(trip.getStartLocationLat(), trip.getStartLocationLong());
		if (address.getResponse()) {
			trip.setFromCity(address.getCity() + address.getState());
			trip.setFromAddress(address.getAddress());
		} else {
			trip.setGeoResponse(3);
		}
		address = addressUtil.getAddress(trip.getStopLocationLat(), trip.getStopLocationLong());
		if (address.getResponse()) {
			trip.setToCity(address.getCity() + address.getState());
			trip.setToAddress(address.getAddress());
		} else {
			trip.setGeoResponse(4);
		}
		trip.setModifiedDate(DicvUtil.getTimestamp());
		tripRepo.save(trip);
	}

}
