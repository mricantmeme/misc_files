package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "FUEL_DROP_PROCESS")
public class FuelDropProcessTime {

	@Id
	@SequenceGenerator(name = "FUEL_DROP_PROCESS_ID_GENERATOR", sequenceName = "FUEL_DROP_PROCESS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FUEL_DROP_PROCESS_ID_GENERATOR")
	@Column(name = "FUEL_DROP_PROCESS_ID")
	private Long fuelDropProcessId;

	@Column(name = "PROCESS_TIME")
	private Timestamp processTime;
	
	@Column(name = "UPDATED_AT")
	private Timestamp updatedAt;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;



	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Long getFuelDropProcessId() {
		return fuelDropProcessId;
	}

	public void setFuelDropProcessId(Long fuelDropProcessId) {
		this.fuelDropProcessId = fuelDropProcessId;
	}

	public Timestamp getProcessTime() {
		return processTime;
	}

	public void setProcessTime(Timestamp processTime) {
		this.processTime = processTime;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	

}
