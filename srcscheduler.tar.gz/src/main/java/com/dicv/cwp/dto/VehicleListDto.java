package com.dicv.cwp.dto;

import java.io.Serializable;

public class VehicleListDto implements Serializable {

	@Override
	public String toString() {
		return "VehicleListDto [vehicleId=" + vehicleId + ", gpsImei=" + gpsImei + ", registrationId=" + registrationId
				+ ", groupName=" + groupName + ", userId=" + userId + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -2078075196304496312L;

	private Long vehicleId;

	private Long gpsImei;

	private String registrationId;

	private String groupName;

	private Integer userId;

	public VehicleListDto(Long vehicleId, String registrationId, Long gpsImei, String groupName) {
		super();
		this.vehicleId = vehicleId;
		this.gpsImei = gpsImei;
		this.registrationId = registrationId;
		this.groupName = groupName;
	}

	public VehicleListDto(Long vehicleId, String registrationId, Long gpsImei) {
		super();
		this.vehicleId = vehicleId;
		this.gpsImei = gpsImei;
		this.registrationId = registrationId;
	}

	public VehicleListDto(Long vehicleId, String registrationId) {
		super();
		this.vehicleId = vehicleId;
		this.registrationId = registrationId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public VehicleListDto(Long vehicleId, Long gpsImei, String registrationId, Integer userId) {
		super();
		this.vehicleId = vehicleId;
		this.gpsImei = gpsImei;
		this.registrationId = registrationId;
		this.userId = userId;
	}

	public VehicleListDto(Long vehicleId, Long gpsImei) {
		super();
		this.vehicleId = vehicleId;
		this.gpsImei = gpsImei;
	}

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}
