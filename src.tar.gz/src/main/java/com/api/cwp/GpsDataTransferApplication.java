package com.api.cwp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpsDataTransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpsDataTransferApplication.class, args);
	}
}
