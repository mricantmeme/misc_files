package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleToGeoFence;
import com.dicv.cwp.dto.VehicleListDto;

@Repository
public interface VehicleToGeoFenceRepo extends CrudRepository<VehicleToGeoFence, Integer> {

	@Query("Select v FROM VehicleToGeoFence v where v.vehicle.vehicleId=:vehicleId and v.vehicle.isDeleted=0 and v.isDeleted=0 and"
			+ " v.geoFenceInfo.validTo>=:validTo ")
	public List<VehicleToGeoFence> getVehicleGeoFenceInfo(@Param("vehicleId") Long vehicleId,
			@Param("validTo") Date validTo);

	@Query("Select v FROM VehicleToGeoFence v where  v.vehicle.isDeleted=0 and v.isDeleted=0 and"
			+ " v.geoFenceInfo.validTo>=:validTo ")
	public List<VehicleToGeoFence> getVehicleGeoFenceInfo(@Param("validTo") Date validTo);
	
	
	@Query("Select v FROM VehicleToGeoFence v where v.vehGeoFenceId IN (Select max(v.vehGeoFenceId) FROM VehicleToGeoFence v "
			+ " where v.vehicle.isDeleted=0 and v.isDeleted=0 and "
			+ " v.geoFenceInfo.validTo>=:validTo group by v.vehicle.vehicleId,v.geoFenceInfo.geoFenceId)")
	public List<VehicleToGeoFence> getVehicleGeoFenceInfoList(@Param("validTo") Date validTo);
	
	@Query("Select v FROM VehicleToGeoFence v where v.vehGeoFenceId IN (Select max(v.vehGeoFenceId) FROM VehicleToGeoFence v "
			+ " where v.vehicle.isDeleted=0 and v.isDeleted=0 and "
			+ " v.geoFenceInfo.validTo>=:validTo and v.vehicle.vehicleId=:vehicleId group by v.geoFenceInfo.geoFenceId)")
	public List<VehicleToGeoFence> getVehicleGeoFenceInfoList(@Param("vehicleId") Long vehicleId,@Param("validTo") Date validTo);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleToGeoFence v set v.isVehicleInside =:isVehicleInside,v.lastUpdatedOn=:lastUpdatedOn  where "
			+ "v.vehGeoFenceId=:vehGeoFenceId and v.vehicle.vehicleId=:vehicleId ")
	public void updateVehicleToGeoFence(@Param("vehicleId") Long vehicleId,
			@Param("vehGeoFenceId") Integer vehGeoFenceId, @Param("isVehicleInside") Integer isVehicleInside,
			@Param("lastUpdatedOn") Timestamp lastUpdatedOn);

	@Query("Select new com.dicv.cwp.dto.VehicleListDto(v.vehicle.vehicleId,v.vehicle.gpsImei.gpsImei,v.vehicle.registrationId,v.vehicle.userId) "
			+ "FROM VehicleToGeoFence v where  v.isDeleted=0 and v.vehicle.isDeleted=0 and v.geoFenceInfo.validTo>=:validTo ")
	public List<VehicleListDto> getVehicleListGeoFence(@Param("validTo") Date validTo);

}
