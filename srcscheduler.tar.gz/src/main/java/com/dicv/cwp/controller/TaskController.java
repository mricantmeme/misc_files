package com.dicv.cwp.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dicv.cwp.service.DriverAnalysis;
import com.dicv.cwp.service.NightDrivingReport;
import com.dicv.cwp.service.TruckAnalysis;
import com.dicv.cwp.service.VehicleInactiveReport;

@RestController
@RequestMapping("/dicv/process")
public class TaskController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaskController.class);

	@Autowired
	private DriverAnalysis driverAnalysis;

	@Autowired
	private TruckAnalysis vehicleUtilizationReport;

	@Autowired
	private VehicleInactiveReport vehicleInactiveReport;

	@Autowired
	private NightDrivingReport nightDrivingReport;

	@RequestMapping(value = "/driverAnalysis", method = RequestMethod.GET)
	@ResponseBody
	private String driverAnalysisSeperate(@RequestParam("fromDate") Date fromDate,
			@RequestParam("driverId") Integer driverId) {
		try {
			driverAnalysis.fromController(fromDate, driverId);
		} catch (Exception ex) {
			LOGGER.info("Exception" + ex);
		}
		return "Driver Analysis API is Started for  " + fromDate + " at " + new Date();
	}

	@RequestMapping(value = "/vehicleUtilization", method = RequestMethod.GET)
	public @ResponseBody String testVehicleUtilization(@RequestParam("vehicleId") Long vehicleId,
			@RequestParam("fromDate") Date fromDate, @RequestParam("toDate") Date toDate) {

		try {
			vehicleUtilizationReport.runUtilizationProcess(vehicleId, fromDate, toDate);
			return "Vehicle Utilization Process is Started for  " + fromDate + " at " + new Date();
		} catch (Exception e) {
			LOGGER.info("Exception " + e);
		}

		return "SUCCESS";
	}

	@RequestMapping(value = "/nightDrivingReport", method = RequestMethod.GET)
	public @ResponseBody String nightDrivingReport(@RequestParam("vehicleId") Long vehicleId,
			@RequestParam("fromDate") Date fromDate, @RequestParam("toDate") Date toDate) {
		try {
			nightDrivingReport.runUtilizationProcess(vehicleId, fromDate, toDate);
			return "Night Driving Process is Started for  " + fromDate + " at " + new Date();
		} catch (Exception e) {
			LOGGER.info("Exception " + e);
		}

		return "Night Driving  Report Called";
	}

	@RequestMapping(value = "/vehicleInactiveReport", method = RequestMethod.GET)
	@ResponseBody
	private String inactiveReport(@RequestParam("fromDate") Date fromDate) {

		try {
			vehicleInactiveReport.fromController(fromDate);
			return "Vehicle Inactive Report Process is Started for  " + fromDate + " at " + new Date();
		} catch (Exception e) {
			LOGGER.info("Exception " + e);
		}

		return "Vehicle Inactive Report Called";
	}

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseBody
	private String test() {
		LOGGER.info("Application API is working " + new Date());
		return "Application API is working " + new Date();
	}
}
