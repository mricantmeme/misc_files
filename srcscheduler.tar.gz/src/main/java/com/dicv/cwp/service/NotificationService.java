package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.AlertPreference;
import com.dicv.cwp.dao.model.AlertType;
import com.dicv.cwp.dao.model.Notification;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.AlertSettingDto;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.AlertPreferenceRepo;
import com.dicv.cwp.repository.AlertTypeRepo;
import com.dicv.cwp.repository.NotificationRepo;
import com.dicv.cwp.utils.DicvUtil;
import com.dicv.cwp.utils.EnumALertType;

@Service
public class NotificationService {

	@Autowired
	private NotificationRepo notificationRepo;

	@Autowired
	private AlertPreferenceRepo alertPreferenceRepo;

	@Autowired
	private AlertTypeRepo alertTypeRepo;

	@Autowired
	private SendMailService sendMailService;

	@Value("#{'${support_mail}'.split(',')}")
	private String[] supportMail;

	@Autowired
	private GoogleAPIService addressUtil;

	
	public void sendGeoFenceAlert(Integer vehicleId, Integer userId, Date gpsTime, List<AlertType> typeList, String msg,
			Double gpsLatitude, Double gpsLongitude) {
		List<AlertPreference> alertPerf = alertPreferenceRepo.getAlertPreference(userId);
		Notification not = new Notification();
		not.setAlertType(typeList.get(0).getAlertTypeId());
		not.setEmailAlert(alertPerf.get(0).getPickupEmailAlert());
		not.setEventGpsTime(new Timestamp(gpsTime.getTime()));
		not.setGeoLatitude(gpsLatitude);
		not.setGeoLongitute(gpsLongitude);
		Address address = addressUtil.getAddress(gpsLatitude, gpsLongitude);
		if (address.getResponse())
			not.setLocation(address.getAddress());
		not.setMessage(msg);
		not.setNotificationType("Info");
		not.setReceivedDateTime(new Timestamp(gpsTime.getTime()));
		not.setReadDateTime(DicvUtil.getTimestamp());
		not.setSmsAlert(alertPerf.get(0).getPickupSmsAlert());
		not.setEmailAlert(2);
		not.setStatus("SENT");
		not.setUserId(userId);
		not.setVehicleId(vehicleId);
		not.setWebAlert(alertPerf.get(0).getPickupWebAlert());
		notificationRepo.save(not);
	}

	@Transactional
	public void saveOverSpeedAlert(Vehicle vehicle, GpsVehParameterDto gpsVehParameterDto) {
		List<AlertType> typeList = alertTypeRepo.getAlertTypeByType(EnumALertType.OVER_SPEED.getAlertType());
		List<AlertPreference> alertPerf = alertPreferenceRepo.getAlertPreference(vehicle.getUserId());
		if (alertPerf != null && alertPerf.size() > 0) {
			Notification not = new Notification();
			not.setAlertType(typeList.get(0).getAlertTypeId());
			not.setEmailAlert(alertPerf.get(0).getOverSpeedEmailAlert());
			not.setEventGpsTime(new Timestamp(gpsVehParameterDto.getGpsTime().getTime()));
			not.setGeoLatitude(gpsVehParameterDto.getGpsLatitude());
			not.setGeoLongitute(gpsVehParameterDto.getGpsLongitude());
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh:mm a");
			Date resultdate = new Date(gpsVehParameterDto.getGpsTime().getTime());
			String message = (sdf.format(resultdate)).toString() + " " + vehicle.getRegistrationId() + " "
					+ typeList.get(0).getDescription();
			not.setMessage(message);
			not.setNotificationType("Info");
			not.setGeoLatitude(gpsVehParameterDto.getGpsLatitude());
			not.setGeoLongitute(gpsVehParameterDto.getGpsLongitude());
			Address address = addressUtil.getAddress(gpsVehParameterDto.getGpsLatitude(),
					gpsVehParameterDto.getGpsLongitude());
			if (address.getResponse())
				not.setLocation(address.getAddress());
			not.setReceivedValue(gpsVehParameterDto.getGpsSpkm().intValue());
			not.setReceivedDateTime(DicvUtil.getTimestamp());
			not.setSmsAlert(alertPerf.get(0).getOverSpeedSmsAlert());
			not.setStatus("NEW");
			not.setEmailAlert(alertPerf.get(0).getOverSpeedEmailAlert());
			not.setUserId(vehicle.getUserId());
			not.setVehicleId(vehicle.getVehicleId().intValue());
			not.setWebAlert(alertPerf.get(0).getOverSpeedWebAlert());
			notificationRepo.save(not);

		}
	}

}
