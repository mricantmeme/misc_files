package com.dicv.cwp.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.DriverAnalysisList;

@Repository
public interface DriverAnalysisRepo extends CrudRepository<DriverAnalysisList, Long> {

	@Query("Select t from DriverAnalysisList t where t.driverId=:driverId and t.reportDate=:reportDate")
	public DriverAnalysisList getDriverAnalysis(@Param("driverId") Integer driverId,
			@Param("reportDate") Date reportDate);

	@Query("Select t from DriverAnalysisList t where  t.reportDate=:reportDate")
	public List<DriverAnalysisList> getDriverAnalysisList(@Param("reportDate") Date reportDate);

}
