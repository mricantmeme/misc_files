package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import com.dicv.cwp.dao.model.FuelDropProcessTime;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.dto.GpsVehParamDto;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.GpsVehicleRepo;

@Component
public class GpsParamService {

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	public List<GpsVehParamDto> collectGpsData(VehicleListDto veh, FuelDropProcessTime fuelProcessTime) {
		List<GpsVehParamDto> gpsParamData = gpsVehicleRepo.getFuelTankGpsParam(veh.getGpsImei(),
				fuelProcessTime.getProcessTime(), new PageRequest(0, 1000));
		return gpsParamData;
	}

	public List<GpsVehParamDto> collectGpsDataForFuelDropRetry(Long imei, Timestamp gpsTime, Integer fuelDropRetry) {
		List<GpsVehParamDto> gpsParamData = gpsVehicleRepo.getFuelTankGpsParam(imei, gpsTime,
				new PageRequest(0, fuelDropRetry));
		return gpsParamData;
	}

	public GpsVehParamDto collectGpsDataForLowBatteryHealth(Long imei, Timestamp gpsTime, Integer batteryLevel) {
		List<GpsVehParamDto> gpsParamData = gpsVehicleRepo.getLowBatteryHealth(imei, gpsTime, batteryLevel,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public GpsParameterDto getMaxofGpsParameterForAlert(Long imei) {
		List<GpsParameterDto> gpsParamData = gpsVehicleRepo.getMaxofGpsParameterForAlert(imei, new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public GpsVehParamDto collectGpsDataForHighBatteryHealth(Long imei, Timestamp gpsTime, Integer batteryHealth) {
		List<GpsVehParamDto> gpsParamData = gpsVehicleRepo.getHighBatteryHealth(imei, gpsTime, batteryHealth,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public Long countofGpsParamEvents(Long gpsImei, Date fromDate, Date toDate) {
		return gpsVehicleRepo.countofGpsParamEvents(gpsImei, fromDate, toDate);
	}

	public GpsVehParameterDto getBatteryDisconnect(Long gpsImei, Timestamp gpsTime) {
		List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.getBatteryDisconnect(gpsImei, gpsTime,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public GpsVehParameterDto getVehicleIdleTimeStarting(Long gpsImei, Timestamp gpsTime) {
		List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.getVehicleIdleTimeStarting(gpsImei, gpsTime,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public GpsVehParameterDto engineRunningOrOff(Long gpsImei, Timestamp gpsTime) {
		List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.engineRunningOrOff(gpsImei, gpsTime,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0)
			return gpsParamData.get(0);
		return null;
	}

	public List<GpsVehParameterDto> getGpsDataForIdling(Long gpsImei, Timestamp idleStartTime, Date idleStopTime) {
		List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.getGpsDataForIdling(gpsImei, idleStartTime,
				idleStopTime);
		return gpsParamData;
	}

}
