package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "BATTERY_HEALTH_PROCESS")
public class BatteryHealthProcess implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7171193274135790838L;

	@Id
	@SequenceGenerator(name = "BATTERY_HEALTH_PROCESS_SEQ", sequenceName = "BATTERY_HEALTH_PROCESS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BATTERY_HEALTH_PROCESS_SEQ")
	@Column(name = "BATTERY_HEALTH_PROCESS_ID")
	private Long bhProcessId;

	@Column(name = "PROCESS_TIME")
	private Timestamp processTime;
	
	@Column(name = "UPDATED_AT")
	private Timestamp updatedAt;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;
	
	@Column(name = "LOW_BATTERY_DETECTED")
	private Integer lowBatteryDetected;

	public Long getBhProcessId() {
		return bhProcessId;
	}

	public void setBhProcessId(Long bhProcessId) {
		this.bhProcessId = bhProcessId;
	}

	public Timestamp getProcessTime() {
		return processTime;
	}

	public void setProcessTime(Timestamp processTime) {
		this.processTime = processTime;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Integer getLowBatteryDetected() {
		return lowBatteryDetected;
	}

	public void setLowBatteryDetected(Integer lowBatteryDetected) {
		this.lowBatteryDetected = lowBatteryDetected;
	}
	
	
}
