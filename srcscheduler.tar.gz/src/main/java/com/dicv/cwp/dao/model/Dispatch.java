package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * This class is responsible to copy scheduled dispatch table data and persist
 * to dispatch table.
 * 
 * @author aut7kor
 * 
 */
@Entity
@Table(name = "DISPATCH")
@NamedQueries({
		@NamedQuery(name = "Dispatch.findAll", query = "SELECT d FROM Dispatch d"),
		@NamedQuery(name = "Dispatch.findDispatchListForNull", query = "SELECT D FROM Dispatch D WHERE D.toAddress IS NULL OR D.fromAddress IS NULL") })
public class Dispatch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DISPATCH_DISPATCHID_GENERATOR", sequenceName = "DISPATCH_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DISPATCH_DISPATCHID_GENERATOR")
	@Column(name = "DISPATCH_ID")
	private Integer dispatchId;

	@Column(name = "DATE_TIME")
	private Timestamp dateTime;

	@Column(name = "DISPATCH_STATUS")
	private String dispatchStatus;

	@Column(name = "DISPATCH_TYPE")
	private String dispatchType;

	@Column(name = "FROM_ADDRESS")
	private String fromAddress;

	@Column(name = "GOODS_WEIGHT")
	private Double goodsWeight;

	private Double latitude;

	private Double longitude;

	@Column(name = "TO_ADDRESS")
	private String toAddress;

	@Column(name = "IS_DELETED")
	private int isDeleted;

	@Column(name = "MODIFIED_DATE")
	private Timestamp modifiedDateTime;

	// bi-directional many-to-one association to ScheduledDispatch
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "SCHEDULED_DISPATCH_ID")
	private ScheduledDispatch scheduledDispatch;

	// bi-directional many-to-one association to DicvUser for column created by
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "CREATED_BY")
	private DicvUser dicvUserCreatedBy;

	// bi-directional many-to-one association to DicvUser for column updated by
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "UPDATED_BY")
	private DicvUser dicvUserUpdatedBy;

	public Dispatch() {
	}

	public Integer getDispatchId() {
		return this.dispatchId;
	}

	public void setDispatchId(Integer dispatchId) {
		this.dispatchId = dispatchId;
	}

	public Timestamp getDateTime() {
		return this.dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getDispatchStatus() {
		return this.dispatchStatus;
	}

	public void setDispatchStatus(String dispatchStatus) {
		this.dispatchStatus = dispatchStatus;
	}

	public String getDispatchType() {
		return this.dispatchType;
	}

	public void setDispatchType(String dispatchType) {
		this.dispatchType = dispatchType;
	}

	public String getFromAddress() {
		return this.fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public Double getGoodsWeight() {
		return this.goodsWeight;
	}

	public void setGoodsWeight(Double goodsWeight) {
		this.goodsWeight = goodsWeight;
	}

	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getToAddress() {
		return this.toAddress;
	}

	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}

	public ScheduledDispatch getScheduledDispatch() {
		return this.scheduledDispatch;
	}

	public void setScheduledDispatch(ScheduledDispatch scheduledDispatch) {
		this.scheduledDispatch = scheduledDispatch;
	}


	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public DicvUser getDicvUserCreatedBy() {
		return dicvUserCreatedBy;
	}

	public void setDicvUserCreatedBy(DicvUser dicvUserCreatedBy) {
		this.dicvUserCreatedBy = dicvUserCreatedBy;
	}

	public DicvUser getDicvUserUpdatedBy() {
		return dicvUserUpdatedBy;
	}

	public void setDicvUserUpdatedBy(DicvUser dicvUserUpdatedBy) {
		this.dicvUserUpdatedBy = dicvUserUpdatedBy;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

}