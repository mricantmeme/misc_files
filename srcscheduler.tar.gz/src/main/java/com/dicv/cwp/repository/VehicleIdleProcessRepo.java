package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.VehicleIdleTimeProcess;

@Repository
public interface VehicleIdleProcessRepo extends JpaRepository<VehicleIdleTimeProcess, Long> {


	@Query("select f from VehicleIdleTimeProcess f where f.vehicleId=:veicleId ")
	public VehicleIdleTimeProcess getVehicleIdleTimeProcess(@Param("veicleId") Long vehicleId);


}
