package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the GEO_FENCE_CIRCLE database table.
 * 
 */
@Entity
@Table(name = "GEO_FENCE_CIRCLE")
public class GeoFenceCircle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GEO_FENCE_CIRCLE_FENCECIRCLEID_GENERATOR", allocationSize = 1, sequenceName = "GEO_FENCE_CIRCLE_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GEO_FENCE_CIRCLE_FENCECIRCLEID_GENERATOR")
	@Column(name = "FENCE_CIRCLE_ID")
	private Integer fenceCircleId;

	@Column(name = "CREATED_BY")
	private Integer createdBy;

	@Column(name = "CREATED_DATE")
	private Timestamp createdDate;

	@Column(name = "GEO_LATITUDE")
	private Double geoLatitude;

	@Column(name = "GEO_LONGITUDE")
	private Double geoLongitude;

	@Column(name = "GEO_RADIUS_IN_METERS")
	private Double geoRadiusInMeters;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name = "UPDATED_BY")
	private Integer updatedBy;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "GEO_FENCE_ID")
	private GeoFenceInfo geoFence;

	public Integer getFenceCircleId() {
		return fenceCircleId;
	}

	public void setFenceCircleId(Integer fenceCircleId) {
		this.fenceCircleId = fenceCircleId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Double getGeoLatitude() {
		return geoLatitude;
	}

	public void setGeoLatitude(Double geoLatitude) {
		this.geoLatitude = geoLatitude;
	}

	public Double getGeoLongitude() {
		return geoLongitude;
	}

	public void setGeoLongitude(Double geoLongitude) {
		this.geoLongitude = geoLongitude;
	}

	public Double getGeoRadiusInMeters() {
		return geoRadiusInMeters;
	}

	public void setGeoRadiusInMeters(Double geoRadiusInMeters) {
		this.geoRadiusInMeters = geoRadiusInMeters;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public GeoFenceInfo getGeoFence() {
		return geoFence;
	}

	public void setGeoFence(GeoFenceInfo geoFence) {
		this.geoFence = geoFence;
	}

}