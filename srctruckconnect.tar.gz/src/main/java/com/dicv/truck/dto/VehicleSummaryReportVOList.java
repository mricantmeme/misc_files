package com.dicv.truck.dto;

import java.util.List;

public class VehicleSummaryReportVOList {
	
	
	private List<VehicleSummaryReportVO> vehicleSummaryReportVO;

	public List<VehicleSummaryReportVO> getVehicleSummaryReportVO() {
		return vehicleSummaryReportVO;
	}

	public void setVehicleSummaryReportVO(List<VehicleSummaryReportVO> vehicleSummaryReportVO) {
		this.vehicleSummaryReportVO = vehicleSummaryReportVO;
	}
	
	

}
