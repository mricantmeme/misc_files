package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.DeviceHealth;
@Repository
public interface DeviceHealthRepo extends CrudRepository<DeviceHealth, Long> {

	@Query("Select v from DeviceHealth v where v.vehicle.vehicleId=:vehicleId")
	public DeviceHealth getDeviceHealth(@Param("vehicleId") Long vehicleId);

}
