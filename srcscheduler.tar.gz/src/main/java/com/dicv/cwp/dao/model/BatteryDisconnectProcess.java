package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "BATTERY_DISCONNECT_PROCESS")
public class BatteryDisconnectProcess implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7171193274135790838L;

	@Id
	@SequenceGenerator(name = "BATTERY_DISC_PROCESS_SEQ", sequenceName = "BATTERY_DISC_PROCESS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BATTERY_DISC_PROCESS_SEQ")
	@Column(name = "BATTERY_DISC_PROCESS_ID")
	private Long bhDiscProcessId;

	@Column(name = "PROCESS_TIME")
	private Timestamp processTime;

	@Column(name = "UPDATED_AT")
	private Timestamp updatedAt;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;
	
	@Column(name = "MAIN_BATTERY_DETECTED")
	private Timestamp mainBatteryDetected;


	public Timestamp getProcessTime() {
		return processTime;
	}

	public void setProcessTime(Timestamp processTime) {
		this.processTime = processTime;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Long getBhDiscProcessId() {
		return bhDiscProcessId;
	}

	public void setBhDiscProcessId(Long bhDiscProcessId) {
		this.bhDiscProcessId = bhDiscProcessId;
	}

	public Timestamp getMainBatteryDetected() {
		return mainBatteryDetected;
	}

	public void setMainBatteryDetected(Timestamp mainBatteryDetected) {
		this.mainBatteryDetected = mainBatteryDetected;
	}

}
