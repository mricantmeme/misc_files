package com.dicv.cwp.dto;

import java.util.Date;

public class GpsParameterDto {

	public GpsParameterDto() {
		super();
	}

	private Long gpsImei;
	private Long gpsParamId;
	private Date gpsTime;
	private Double gpsSpkm;
	private Integer engineON;
	private Double latitude;
	private Double longitude;
	private Integer gpsCog;
	private Double gpsHdop;
	private Long canEngineSpeed;
	private Double canCoolantTemp;
	private Long canVehicleSpeed;
	private Integer fuelTankLevel;
	private Integer batteryHealth;
	private Date vehicleLastUpdateON;
	private Integer harshAcceleration;
	private Integer harshBraking;
	private Integer harshCornering;
	private Double adblueLevel;

	public GpsParameterDto(Long gpsParamId, Long gpsImei, Long canEngineSpeed, Double gpsSpkm, Date gpsTime,
			Integer engineON, Double latitude, Double longitude, Double gpsHdop, Integer gpsCog, Double canCoolantTemp,
			Long canVehicleSpeed, Integer batteryHealth, Integer fuelTankLevel, Date vehicleLastUpdateON) {
		super();
		this.gpsParamId = gpsParamId;
		this.gpsImei = gpsImei;
		this.canEngineSpeed = canEngineSpeed;
		this.gpsTime = gpsTime;
		this.gpsSpkm = gpsSpkm;
		this.engineON = engineON;
		this.latitude = latitude;
		this.gpsCog = gpsCog;
		this.gpsHdop = gpsHdop;
		this.longitude = longitude;
		this.canCoolantTemp = canCoolantTemp;
		this.canVehicleSpeed = canVehicleSpeed;
		this.batteryHealth = batteryHealth;
		this.fuelTankLevel = fuelTankLevel;
		this.vehicleLastUpdateON = vehicleLastUpdateON;

	}

	public GpsParameterDto(Long gpsParamId, Long gpsImei, Long canEngineSpeed, Double gpsSpkm,
			Date gpsTime, Integer engineON, Double latitude, Double longitude, Double gpsHdop, Integer gpsCog,
			Double canCoolantTemp, Long canVehicleSpeed, Integer batteryHealth, Integer fuelTankLevel,
			Date vehicleLastUpdateON, Double adblueLevel) {
		super();
		this.gpsParamId = gpsParamId;
		this.gpsImei = gpsImei;
		this.canEngineSpeed = canEngineSpeed;
		this.gpsTime = gpsTime;
		this.gpsSpkm = gpsSpkm;
		this.engineON = engineON;
		this.latitude = latitude;
		this.gpsCog = gpsCog;
		this.gpsHdop = gpsHdop;
		this.longitude = longitude;
		this.canCoolantTemp = canCoolantTemp;
		this.canVehicleSpeed = canVehicleSpeed;
		this.batteryHealth = batteryHealth;
		this.fuelTankLevel = fuelTankLevel;
		this.vehicleLastUpdateON = vehicleLastUpdateON;
		this.adblueLevel = adblueLevel;

	}

	public GpsParameterDto(Long gpsParamId, Long gpsImei, Date gpsTime, Double gpsSpkm, Integer engineON,
			Double latitude, Double longitude, Long canEngineSpeed, Integer harshAcceleration, Integer harshBraking,
			Integer harshCornering) {
		super();
		this.gpsParamId = gpsParamId;
		this.gpsImei = gpsImei;
		this.gpsTime = gpsTime;
		this.gpsSpkm = gpsSpkm;
		this.engineON = engineON;
		this.latitude = latitude;
		this.longitude = longitude;
		this.canEngineSpeed = canEngineSpeed;
		this.harshAcceleration = harshAcceleration;
		this.harshBraking = harshBraking;
		this.harshCornering = harshCornering;
	}

	public GpsParameterDto(Long gpsParamId, Long gpsImei, Date gpsTime, Integer engineON) {
		super();
		this.gpsParamId = gpsParamId;
		this.gpsImei = gpsImei;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
	}

	public GpsParameterDto(Long gpsParamId, Long gpsImei, Date gpsTime, Integer engineON, Double latitude,
			Double longitude) {
		super();
		this.gpsParamId = gpsParamId;
		this.gpsImei = gpsImei;
		this.gpsTime = gpsTime;
		this.engineON = engineON;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	//

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public Date getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(Date gpsTime) {
		this.gpsTime = gpsTime;
	}

	public Double getGpsSpkm() {
		return gpsSpkm;
	}

	public void setGpsSpkm(Double gpsSpkm) {
		this.gpsSpkm = gpsSpkm;
	}

	public Integer getEngineON() {
		return engineON;
	}

	public void setEngineON(Integer engineON) {
		this.engineON = engineON;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getGpsHdop() {
		return gpsHdop;
	}

	public void setGpsHdop(Double gpsHdop) {
		this.gpsHdop = gpsHdop;
	}

	public Double getCanCoolantTemp() {
		return canCoolantTemp;
	}

	public void setCanCoolantTemp(Double canCoolantTemp) {
		this.canCoolantTemp = canCoolantTemp;
	}

	public Integer getBatteryHealth() {
		return batteryHealth;
	}

	public void setBatteryHealth(Integer batteryHealth) {
		this.batteryHealth = batteryHealth;
	}

	public Date getVehicleLastUpdateON() {
		return vehicleLastUpdateON;
	}

	public void setVehicleLastUpdateON(Date vehicleLastUpdateON) {
		this.vehicleLastUpdateON = vehicleLastUpdateON;
	}

	public Long getGpsParamId() {
		return gpsParamId;
	}

	public void setGpsParamId(Long gpsParamId) {
		this.gpsParamId = gpsParamId;
	}

	public Integer getHarshAcceleration() {
		return harshAcceleration;
	}

	public void setHarshAcceleration(Integer harshAcceleration) {
		this.harshAcceleration = harshAcceleration;
	}

	public Integer getHarshBraking() {
		return harshBraking;
	}

	public void setHarshBraking(Integer harshBraking) {
		this.harshBraking = harshBraking;
	}

	public Integer getHarshCornering() {
		return harshCornering;
	}

	public void setHarshCornering(Integer harshCornering) {
		this.harshCornering = harshCornering;
	}

	public Long getCanEngineSpeed() {
		return canEngineSpeed;
	}

	public void setCanEngineSpeed(Long canEngineSpeed) {
		this.canEngineSpeed = canEngineSpeed;
	}

	public Long getCanVehicleSpeed() {
		return canVehicleSpeed;
	}

	public void setCanVehicleSpeed(Long canVehicleSpeed) {
		this.canVehicleSpeed = canVehicleSpeed;
	}

	public Integer getFuelTankLevel() {
		return fuelTankLevel;
	}

	public void setFuelTankLevel(Integer fuelTankLevel) {
		this.fuelTankLevel = fuelTankLevel;
	}

	public Integer getGpsCog() {
		return gpsCog;
	}

	public void setGpsCog(Integer gpsCog) {
		this.gpsCog = gpsCog;
	}

	@Override
	public String toString() {
		return "GpsParameterDto [gpsImei=" + gpsImei + ", gpsParamId=" + gpsParamId + ", gpsTime=" + gpsTime
				+ "gpsSpkm=" + gpsSpkm + ", engineON=" + engineON + ", latitude=" + latitude + ", longitude="
				+ longitude + "]";
	}

	public Double getAdblueLevel() {
		return adblueLevel;
	}

	public void setAdblueLevel(Double adblueLevel) {
		this.adblueLevel = adblueLevel;
	}

}
