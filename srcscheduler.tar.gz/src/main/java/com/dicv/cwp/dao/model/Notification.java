package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "NOTIFICATION")
public class Notification {

	@Id
	@SequenceGenerator(name = "NOTIFICATION_NOTIFICATIONID_GENERATOR", sequenceName = "NOTIFICATION_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NOTIFICATION_NOTIFICATIONID_GENERATOR")
	@Column(name = "NOTIFICATION_ID")
	private Integer notificationId;

	@Column(name = "MESSAGE")
	private String message;

	@Column(name = "NOTIFICATION_TYPE")
	private String notificationType;

	@Column(name = "READ_DATE_TIME")
	private Timestamp readDateTime;

	@Column(name = "RECEIVED_DATE_TIME")
	private Timestamp receivedDateTime;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATED_BY")
	private Integer userId;

	@Column(name = "VEHICLE_ID")
	private Integer vehicleId;

	@Column(name = "ALERT_TYPE_ID")
	private Integer alertType;

	@Column(name = "EMAIL_ALERT")
	private Integer emailAlert;

	@Column(name = "EVENT_GPS_TIME")
	private Timestamp eventGpsTime;

	@Column(name = "GEO_LATITUDE")
	private Double geoLatitude;

	@Column(name = "GEO_LONGITUTE")
	private Double geoLongitute;

	@Column(name = "SMS_ALERT")
	private Integer smsAlert;

	@Column(name = "WEB_ALERT")
	private Integer webAlert;

	@Column(name = "LOCATION")
	private String location;

	@Column(name = "RECEIVED_VALUE")
	private Integer receivedValue;

	public Integer getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Integer notificationId) {
		this.notificationId = notificationId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Integer getEmailAlert() {
		return emailAlert;
	}

	public void setEmailAlert(Integer emailAlert) {
		this.emailAlert = emailAlert;
	}

	public Timestamp getEventGpsTime() {
		return eventGpsTime;
	}

	public void setEventGpsTime(Timestamp eventGpsTime) {
		this.eventGpsTime = eventGpsTime;
	}

	public Integer getSmsAlert() {
		return smsAlert;
	}

	public void setSmsAlert(Integer smsAlert) {
		this.smsAlert = smsAlert;
	}

	public Integer getWebAlert() {
		return webAlert;
	}

	public void setWebAlert(Integer webAlert) {
		this.webAlert = webAlert;
	}

	public Timestamp getReceivedDateTime() {
		return receivedDateTime;
	}

	public void setReceivedDateTime(Timestamp receivedDateTime) {
		this.receivedDateTime = receivedDateTime;
	}

	public Double getGeoLatitude() {
		return geoLatitude;
	}

	public void setGeoLatitude(Double geoLatitude) {
		this.geoLatitude = geoLatitude;
	}

	public Double getGeoLongitute() {
		return geoLongitute;
	}

	public void setGeoLongitute(Double geoLongitute) {
		this.geoLongitute = geoLongitute;
	}

	public Integer getAlertType() {
		return alertType;
	}

	public void setAlertType(Integer alertType) {
		this.alertType = alertType;
	}

	@Override
	public String toString() {
		return "Notification [notificationId=" + notificationId + ", message=" + message + ", notificationType="
				+ notificationType + ", receivedDateTime=" + receivedDateTime + ", status=" + status + ", userId="
				+ userId + ", vehicleId=" + vehicleId + ", alertType=" + alertType + ", emailAlert=" + emailAlert
				+ ", eventGpsTime=" + eventGpsTime + ", geoLatitude=" + geoLatitude + ", geoLongitute=" + geoLongitute
				+ ", smsAlert=" + smsAlert + ", webAlert=" + webAlert + "]";
	}

	public Timestamp getReadDateTime() {
		return readDateTime;
	}

	public void setReadDateTime(Timestamp readDateTime) {
		this.readDateTime = readDateTime;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getReceivedValue() {
		return receivedValue;
	}

	public void setReceivedValue(Integer receivedValue) {
		this.receivedValue = receivedValue;
	}

}
