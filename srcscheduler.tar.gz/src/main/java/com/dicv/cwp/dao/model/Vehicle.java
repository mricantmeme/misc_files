package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the VEHICLE database table.
 */
@Entity
@Table(name = "VEHICLE")
public class Vehicle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "VEHICLE_VEHICLEID_GENERATOR", sequenceName = "VEHICLE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_VEHICLEID_GENERATOR")
	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	@Column(name = "CURRENT_ENGINE_SPEED")
	private Integer currentEngineSpeed;

	@Column(name = "CURRENT_LAT")
	private Double currentLat;

	@Column(name = "CURRENT_LONG")
	private Double currentLong;

	@Column(name = "CURRENT_VEHICLE_SPEED")
	private Integer currentVehicleSpeed;

	@Column(name = "GPS_COG")
	private Integer gpsCog;

	@Column(name = "GPS_HDOP")
	private Double gpsHdop;

	@Column(name = "VEH_AVG_SPEED")
	private Integer vehicleMaxSpeed;

	@Column(name = "MODIFIED_DATE_TIME")
	private Timestamp modifiedDateTime;

	@Column(name = "REGISTRATION_ID")
	private String registrationId;

	@Column(name = "RUNNING_STATUS")
	private String runningStatus;

	@Column(name = "VARIANT")
	private String variant;

	@Column(name = "VEHICLE_STATUS")
	private String vehicleStatus;

	@Column(name = "VEHICLE_UPDATE_TIME")
	private Timestamp vehicleUpdateTime;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "IN_TRIP")
	private Integer inTrip;

	@Column(name = "MAX_PAYLOAD_CAPACITY")
	private Double maxPayloadCapacity;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "vehicle")
	private GpsImei gpsImei;

	@Column(name = "GROUP_ID")
	private Integer dicvGroupId;

	@Column(name = "ROOT_ADMIN_GROUP_ID")
	private Integer rootAdminGroupId;

	@Column(name = "USER_ID")
	private Integer userId;

	@Column(name = "DEFAULT_DRIVER")
	private Integer defaultDriverUserId;

	@Column(name = "LAST_TRIP_GPS_TIME")
	private Timestamp lastProcessedGpsTime;

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Integer getCurrentEngineSpeed() {
		return currentEngineSpeed;
	}

	public void setCurrentEngineSpeed(Integer currentEngineSpeed) {
		this.currentEngineSpeed = currentEngineSpeed;
	}

	public Double getCurrentLat() {
		return currentLat;
	}

	public Integer getDicvGroupId() {
		return dicvGroupId;
	}

	public void setDicvGroupId(Integer dicvGroupId) {
		this.dicvGroupId = dicvGroupId;
	}

	public void setCurrentLat(Double currentLat) {
		this.currentLat = currentLat;
	}

	public Double getCurrentLong() {
		return currentLong;
	}

	public void setCurrentLong(Double currentLong) {
		this.currentLong = currentLong;
	}

	public Integer getVehicleMaxSpeed() {
		return vehicleMaxSpeed;
	}

	public void setVehicleMaxSpeed(Integer vehicleMaxSpeed) {
		this.vehicleMaxSpeed = vehicleMaxSpeed;
	}

	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getRunningStatus() {
		return runningStatus;
	}

	public void setRunningStatus(String runningStatus) {
		this.runningStatus = runningStatus;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public String getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}

	public Timestamp getVehicleUpdateTime() {
		return vehicleUpdateTime;
	}

	public void setVehicleUpdateTime(Timestamp vehicleUpdateTime) {
		this.vehicleUpdateTime = vehicleUpdateTime;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Double getMaxPayloadCapacity() {
		return maxPayloadCapacity;
	}

	public void setMaxPayloadCapacity(Double maxPayloadCapacity) {
		this.maxPayloadCapacity = maxPayloadCapacity;
	}

	public GpsImei getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(GpsImei gpsImei) {
		this.gpsImei = gpsImei;
	}

	/*
	 * public DicvGroup getDicvGroup() { return dicvGroup; }
	 * 
	 * public void setDicvGroup(DicvGroup dicvGroup) { this.dicvGroup = dicvGroup; }
	 */

	public Integer getInTrip() {
		return inTrip;
	}

	public void setInTrip(Integer inTrip) {
		this.inTrip = inTrip;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Double getGpsHdop() {
		return gpsHdop;
	}

	public void setGpsHdop(Double gpsHdop) {
		this.gpsHdop = gpsHdop;
	}

	public Integer getGpsCog() {
		return gpsCog;
	}

	public void setGpsCog(Integer gpsCog) {
		this.gpsCog = gpsCog;
	}

	public Timestamp getLastProcessedGpsTime() {
		return lastProcessedGpsTime;
	}

	public void setLastProcessedGpsTime(Timestamp lastProcessedGpsTime) {
		this.lastProcessedGpsTime = lastProcessedGpsTime;
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", currentEngineSpeed=" + currentEngineSpeed + ", currentLat="
				+ currentLat + ", currentLong=" + currentLong + ", currentVehicleSpeed=" + currentVehicleSpeed
				+ ", gpsCog=" + gpsCog + ", gpsHdop=" + gpsHdop + ", vehicleMaxSpeed=" + vehicleMaxSpeed
				+ ", modifiedDateTime=" + modifiedDateTime + ", registrationId=" + registrationId + ", runningStatus="
				+ runningStatus + ", variant=" + variant + ", vehicleStatus=" + vehicleStatus + ", vehicleUpdateTime="
				+ vehicleUpdateTime + ", isDeleted=" + isDeleted + ", inTrip=" + inTrip + ", maxPayloadCapacity="
				+ maxPayloadCapacity + ", gpsImei=" + gpsImei + ", userId=" + userId + ", lastProcessedId="
				+ ", lastProcessedGpsTime=" + lastProcessedGpsTime + "]";
	}

	public Integer getRootAdminGroupId() {
		return rootAdminGroupId;
	}

	public void setRootAdminGroupId(Integer rootAdminGroupId) {
		this.rootAdminGroupId = rootAdminGroupId;
	}

	public Integer getCurrentVehicleSpeed() {
		return currentVehicleSpeed;
	}

	public void setCurrentVehicleSpeed(Integer currentVehicleSpeed) {
		this.currentVehicleSpeed = currentVehicleSpeed;
	}

	public Integer getDefaultDriverUserId() {
		return defaultDriverUserId;
	}

	public void setDefaultDriverUserId(Integer defaultDriverUserId) {
		this.defaultDriverUserId = defaultDriverUserId;
	}

}