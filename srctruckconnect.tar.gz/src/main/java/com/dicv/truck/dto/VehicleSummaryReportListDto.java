package com.dicv.truck.dto;

import java.util.List;

public class VehicleSummaryReportListDto {

	private List<VehicleSummaryReportDto> vehicleSummaryReportDtoList;

	public List<VehicleSummaryReportDto> getVehicleSummaryReportDtoList() {
		return vehicleSummaryReportDtoList;
	}

	public void setVehicleSummaryReportDtoList(
			List<VehicleSummaryReportDto> vehicleSummaryReportDtoList) {
		this.vehicleSummaryReportDtoList = vehicleSummaryReportDtoList;
	}

}