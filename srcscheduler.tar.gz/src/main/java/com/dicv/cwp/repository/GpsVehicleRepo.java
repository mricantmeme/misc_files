package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.GpsVehicleParameter;
import com.dicv.cwp.dto.GeoFenceGpsDto;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.dto.GpsVehParamDto;
import com.dicv.cwp.dto.GpsVehParameterDto;

@Repository
public interface GpsVehicleRepo extends JpaRepository<GpsVehicleParameter, Integer> {

	@Query("select max(g.vehicleLastUpdateON) from GpsVehicleParameter g  where g.gpsImei =:gpsImei")
	public Timestamp getLatestVehicleUpdatedTimestamp(@Param("gpsImei") Long gpsImei);

	@Query("Select new com.dicv.cwp.dto.GpsVehParamDto(g.gpsVehicleParamId,"
			+ "g.gpsTime,g.fuelTankLevel,g.gpsLatitude,g.gpsLatitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and gpsTime > :gpsTime and g.fuelTankLevel>0  order by gpsTime asc")
	public List<GpsVehParamDto> getFuelTankGpsParam(@Param("gpsImei") Long imeiNo, @Param("gpsTime") Timestamp gpsTime,
			Pageable pageable);

	/* Batter Health */
	@Query("Select new com.dicv.cwp.dto.GpsVehParamDto(g.gpsVehicleParamId,g.gpsTime,g.batteryHealth,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and gpsTime > :gpsTime and g.batteryHealth < :batteryHealth order by gpsTime asc")
	public List<GpsVehParamDto> getLowBatteryHealth(@Param("gpsImei") Long imeiNo, @Param("gpsTime") Timestamp gpsTime,
			@Param("batteryHealth") Integer batteryHealth, Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :gpsTime and g.mainBtryDisconnect=1 order by gpsTime asc")
	public List<GpsVehParameterDto> getVehicleIdleAlert(@Param("gpsImei") Long gpsImei, @Param("gpsTime") Date gpsTime,
			Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime > :gpsTime and g.mainBtryDisconnect=1 order by gpsTime asc")
	public List<GpsVehParameterDto> getBatteryDisconnect(@Param("gpsImei") Long gpsImei, @Param("gpsTime") Date gpsTime,
			Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParamDto(g.gpsVehicleParamId,g.gpsTime,g.batteryHealth,g.engineON)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and gpsTime > :gpsTime and g.batteryHealth >= :batteryHealth order by gpsTime asc")
	public List<GpsVehParamDto> getHighBatteryHealth(@Param("gpsImei") Long imeiNo, @Param("gpsTime") Timestamp gpsTime,
			@Param("batteryHealth") Integer batteryHealth, Pageable pageable);

	@Query("Select g.gpsLatitude,g.gpsLongitude from GpsVehicleParameter g  where g.gpsVehicleParamId=:gpsVehicleParamId")
	public List<Object[]> getGpsParamLatitudeandLongitude(@Param("gpsVehicleParamId") Long gpsVehicleParamId);

	@Query("Select count(g.gpsVehicleParamId) from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :fromDate  and g.gpsTime <= :toDate and  g.gpsTime is NOT NULL ")
	public Long countofGpsParamDataforUtilization(@Param("gpsImei") Long gpsImei, @Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :fromDate  and g.gpsTime <= :toDate and g.gpsTime >=:gpsParamTime order by gpsTime asc")
	public List<GpsVehParameterDto> collectGpsParamDataforUtilization(@Param("gpsImei") Long gpsImei,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("gpsParamTime") Date gpsParamTime,
			Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :fromDate  and g.gpsTime <= :toDate order by gpsTime asc")
	public List<GpsVehParameterDto> collectGpsParamDataforUtilization(@Param("gpsImei") Long gpsImei,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsParameterDto(g.gpsVehicleParamId,g.gpsImei,"
			+ "g.canEngineSpeed,g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude,g.gpsHdop,g.gpsCog,"
			+ "g.canCoolantTemp,g.canVehicleSpeed,g.batteryHealth,g.fuelTankLevel,g.vehicleLastUpdateON,g.adblueLevel)  from GpsVehicleParameter g where "
			+ "  g.gpsImei=:gpsImei and  g.gpsTime is NOT NULL order by gpsTime desc ")
	public List<GpsParameterDto> fetchVehicleGpsParam(@Param("gpsImei") Long gpsImei, Pageable pageable);

	@Query("select new com.dicv.cwp.dto.GpsParameterDto(g.gpsVehicleParamId,g.gpsImei,"
			+ "g.gpsTime,g.engineON) from GpsVehicleParameter g  where g.gpsImei =:gpsImei and g.gpsTime is NOT NULL  order by gpsTime desc")
	public List<GpsParameterDto> getMaxofGpsParameterForAlert(@Param("gpsImei") Long gpsImei, Pageable pageable);

	/* Trip Analysis */

	@Query("Select new com.dicv.cwp.dto.GpsParameterDto(g.gpsVehicleParamId,g.gpsImei,"
			+ "g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude) from GpsVehicleParameter g where "
			+ "  g.gpsTime >:gpsTime and g.gpsImei=:gpsImei and g.engineON=:engineON and g.gpsTime is NOT NULL order by gpsTime asc ")
	public List<GpsParameterDto> getGPSParamForTripPollar(@Param("gpsImei") Long gpsImei,
			@Param("gpsTime") Date gpsTime, @Param("engineON") Integer engineON, Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsParameterDto(g.gpsVehicleParamId,g.gpsImei,"
			+ "g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude) from GpsVehicleParameter g where "
			+ "  g.gpsTime >:gpsTime and g.gpsImei=:gpsImei and g.gpsTime is NOT NULL order by gpsTime asc ")
	public List<GpsParameterDto> getGPSParamForTripPollarByTimeDiff(@Param("gpsImei") Long gpsImei,
			@Param("gpsTime") Date gpsTime, Pageable pageable);

	@Query("select new com.dicv.cwp.dto.GpsParameterDto(g.gpsVehicleParamId,g.gpsImei,"
			+ "g.gpsTime,g.engineON) from GpsVehicleParameter g  where g.gpsImei =:gpsImei and g.engineON=:engineON and g.gpsTime is NOT NULL order by gpsTime desc")
	public List<GpsParameterDto> getMaxofGpsParameter(@Param("gpsImei") Long gpsImei,
			@Param("engineON") Integer engineON, Pageable pageable);

	@Query("Select count(g.gpsVehicleParamId)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsVehicleParamId >= :startId  and g.gpsVehicleParamId <= :endId order by gpsTime asc")
	public Long fetchCountGpsDataForTripAnalysis(@Param("gpsImei") Long gpsImei, @Param("startId") Long startId,
			@Param("endId") Long endId);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.canEngineSpeed,g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude,g.harshAcceleration,g.harshBraking,g.harshCornering)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsVehicleParamId >= :startId  and g.gpsVehicleParamId <= :endId order by gpsTime asc")
	public List<GpsVehParameterDto> fetchGpsDataForTripAnalysis(@Param("gpsImei") Long gpsImei,
			@Param("startId") Long startId, @Param("endId") Long endId, Pageable pageable);

	@Query("Select g.gpsVehicleParamId  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >=:gpsTime order by gpsTime asc")
	public List<Long> getGpsParamId(@Param("gpsImei") Long gpsImei, @Param("gpsTime") Date gpsTime, Pageable pageable);

	/* Device Health */

	@Query("Select new com.dicv.cwp.dto.GpsVehParamDto(g.gpsVehicleParamId,g.gpsImei,g.gpsTime,"
			+ "g.vehicleLastUpdateON,g.deviceBattery,g.signalStrength,g.gpsVolt)  from GpsVehicleParameter g where  "
			+ "  g.gpsImei=:gpsImei and  g.gpsTime is NOT NULL order by gpsVehicleParamId desc ")
	public List<GpsVehParamDto> getGpsParamDataforDeviceReport(@Param("gpsImei") Long gpsImei, Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GeoFenceGpsDto(g.gpsVehicleParamId,"
			+ "g.gpsTime,g.gpsLatitude,g.gpsLongitude,g.gpsImei)  from GpsVehicleParameter g where g.engineON=1 and g.gpsSpkm>0 and g.gpsVehicleParamId>:gpsVehicleParamId "
			+ "and g.gpsImei IN :imeis order by gpsVehicleParamId asc")
	public List<GeoFenceGpsDto> fetchGpsDataForGeoFenceAlert(@Param("gpsVehicleParamId") Long gpsVehicleParamId,
			@Param("imeis") List<Long> imeis, Pageable pageable);

	@Query("Select count(g.gpsVehicleParamId) from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :fromDate  and g.gpsTime <= :toDate and  g.gpsTime is NOT NULL ")
	public Long countofGpsParamEvents(@Param("gpsImei") Long gpsImei, @Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >= :gpsTime  and g.gpsSpkm >= :gpsSpkm order by gpsTime asc")
	public List<GpsVehParameterDto> fetchOverSpeedReport(@Param("gpsImei") Long gpsImei, @Param("gpsTime") Date gpsTime,
			@Param("gpsSpkm") Double gpsSpkm, Pageable pageable);

	/* Idle Time */

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >:gpsTime and g.gpsSpkm=0 and g.engineON=1 order by gpsTime asc")
	public List<GpsVehParameterDto> getVehicleIdleTimeStarting(@Param("gpsImei") Long gpsImei,
			@Param("gpsTime") Date gpsTime, Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
			+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >:gpsTime and (g.gpsSpkm>0 or g.engineON=0) order by gpsTime asc")
	public List<GpsVehParameterDto> engineRunningOrOff(@Param("gpsImei") Long gpsImei, @Param("gpsTime") Date gpsTime,
			Pageable pageable);

	@Query("Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,g.gpsTime)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
			+ " and g.gpsTime >:startTime and g.gpsTime <=:stopTime order by gpsTime asc")
	public List<GpsVehParameterDto> getGpsDataForIdling(@Param("gpsImei") Long gpsImei, @Param("startTime") Date startTime,
			@Param("stopTime") Date stopTime);

}
