package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the SCHEDULED_TRIP database table.
 * 
 */
@Entity
@Table(name = "SCHEDULED_TRIP")
public class ScheduledTrip implements Serializable {
	public ScheduledTrip(Long scheduledTripId, Date fromDate, String isemail, String issms,
			Timestamp modifiedDateTime, Date toDate, Timestamp tripDateTime, String tripStatus, Integer isDeleted,
			Integer userId, Integer scheduledTripFlag) {
		super();
		this.scheduledTripId = scheduledTripId;
		this.fromDate = fromDate;
		this.isemail = isemail;
		this.issms = issms;
		this.modifiedDateTime = modifiedDateTime;
		this.toDate = toDate;
		this.tripDateTime = tripDateTime;
		this.tripStatus = tripStatus;
		this.isDeleted = isDeleted;
		this.userId = userId;
		this.scheduledTripFlag = scheduledTripFlag;
	}

	private static final long serialVersionUID = 1L;

	/**
	 * Unique key
	 */
	@Id
	@SequenceGenerator(name = "SCHEDULED_TRIP_SCHEDULEDTRIPID_GENERATOR", sequenceName = "SCHEDULEDTRIP_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SCHEDULED_TRIP_SCHEDULEDTRIPID_GENERATOR")
	@Column(name = "SCHEDULED_TRIP_ID")
	private Long scheduledTripId;

	@Temporal(TemporalType.DATE)
	@Column(name = "FROM_DATE")
	private Date fromDate;

	@Column(name = "IS_EMAIL")
	private String isemail;

	@Column(name = "IS_SMS")
	private String issms;

	@Column(name = "MODIFIED_DATE_TIME")
	private Timestamp modifiedDateTime;

	@Temporal(TemporalType.DATE)
	@Column(name = "TO_DATE")
	private Date toDate;

	@Column(name = "TRIP_DATE_TIME")
	private Timestamp tripDateTime;

	@Column(name = "TRIP_STATUS")
	private String tripStatus;

	@Column(name = "SCHEDULED_TRIP_FLAG")
	private Integer scheduledTripFlag = -1;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "USER_ID")
	private Integer userId;

	@Column(name = "UPDATED_BY")
	private Integer dicvUserUpdatedBy;

	@Column(name = "CREATED_DATE")
	private Timestamp createdDate;

	@Column(name = "CUSTOMER_NAME")
	private String customerName;

	@Column(name = "VOLUME")
	private Integer volume;

	@Column(name = "LOAD_WEIGHT")
	private Integer loadWeight;

	@Column(name = "REVENUE")
	private Integer revenue;

	@Column(name = "DRIVER_COST")
	private Double driverCost;

	@Column(name = "OPERATIONAL_COST")
	private Double operationalCost;

	@Column(name = "FUEL_COST")
	private Double fuelCost;

	@Column(name = "DISTANCE")
	private Double distance;

	@Column(name = "DURATION")
	private Integer duration;

	/**
	 * Default Constructor
	 */
	public ScheduledTrip() {
	}


	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public String getIsemail() {
		return isemail;
	}

	public void setIsemail(String isemail) {
		this.isemail = isemail;
	}

	public String getIssms() {
		return issms;
	}

	public void setIssms(String issms) {
		this.issms = issms;
	}

	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Timestamp getTripDateTime() {
		return tripDateTime;
	}

	public void setTripDateTime(Timestamp tripDateTime) {
		this.tripDateTime = tripDateTime;
	}

	public String getTripStatus() {
		return tripStatus;
	}

	public void setTripStatus(String tripStatus) {
		this.tripStatus = tripStatus;
	}

	public Integer getScheduledTripFlag() {
		return scheduledTripFlag;
	}

	public void setScheduledTripFlag(Integer scheduledTripFlag) {
		this.scheduledTripFlag = scheduledTripFlag;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getDicvUserUpdatedBy() {
		return dicvUserUpdatedBy;
	}

	public void setDicvUserUpdatedBy(Integer dicvUserUpdatedBy) {
		this.dicvUserUpdatedBy = dicvUserUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getVolume() {
		return volume;
	}

	public void setVolume(Integer volume) {
		this.volume = volume;
	}

	public Integer getLoadWeight() {
		return loadWeight;
	}

	public void setLoadWeight(Integer loadWeight) {
		this.loadWeight = loadWeight;
	}

	public Integer getRevenue() {
		return revenue;
	}

	public void setRevenue(Integer revenue) {
		this.revenue = revenue;
	}

	public Double getDriverCost() {
		return driverCost;
	}

	public void setDriverCost(Double driverCost) {
		this.driverCost = driverCost;
	}

	public Double getOperationalCost() {
		return operationalCost;
	}

	public void setOperationalCost(Double operationalCost) {
		this.operationalCost = operationalCost;
	}

	public Double getFuelCost() {
		return fuelCost;
	}

	public void setFuelCost(Double fuelCost) {
		this.fuelCost = fuelCost;
	}

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

}