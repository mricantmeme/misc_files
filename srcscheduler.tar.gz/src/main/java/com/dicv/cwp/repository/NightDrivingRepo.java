package com.dicv.cwp.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.NightDriving;

@Repository
public interface NightDrivingRepo extends CrudRepository<NightDriving, Long> {
	
	@Query("Select v from NightDriving v where v.vehicleId=:vehicleId and v.reportDate=:fromDate")
	public NightDriving getNightDriving(@Param("vehicleId") Long vehicleId,
			@Param("fromDate") Date fromDate);
	
}
