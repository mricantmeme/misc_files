package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the GEO_FENCE_INFO database table.
 * 
 */
@Entity
@Table(name = "GEO_FENCE_INFO")
public class GeoFenceInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GEO_FENCE_INFO_GEOFENCEID_GENERATOR", allocationSize = 1, sequenceName = "GEO_FENCE_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GEO_FENCE_INFO_GEOFENCEID_GENERATOR")
	@Column(name = "GEO_FENCE_ID")
	private Integer geoFenceId;

	@Column(name = "APPLY_TO_ALL_VEHICLES")
	private Integer applyToAllVehicles;

	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "EMAIL_MODE")
	private Boolean emailMode;

	@Column(name = "ENTRY_ALERT")
	private Boolean entryAlert;

	@Column(name = "ENTRY_NOTIFICATION_TIME")
	private Date entryNotificationTime;

	@Column(name = "EXIT_ALERT")
	private Boolean exitAlert;

	@Column(name = "EXIT_NOTIFICATION_TIME")
	private Date exitNotificationTime;

	@Column(name = "GEO_FENCE_NAME")
	private String geoFenceName;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "LAST_UPDATED_ON")
	private Timestamp lastUpdatedOn;

	@Column(name = "SKIPPED_ALERT")
	private Boolean skippedAlert;

	@Column(name = "SMS_MODE")
	private Boolean smsMode;

	@Column(name = "UPDATED_BY")
	private Integer updatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "VALID_FROM")
	private Date validFrom;

	@Temporal(TemporalType.DATE)
	@Column(name = "VALID_TO")
	private Date validTo;

	@Column(name = "WEB_MODE")
	private Boolean webMode;

	@ManyToOne
	@JoinColumn(name = "CREATED_BY")
	private DicvUser dicvUser;

	@ManyToOne
	@JoinColumn(name = "GEOFENCE_TYPE_ID")
	private DicvGeoFenceType dicvGeoFenceType;

	@ManyToOne
	@JoinColumn(name = "GEO_FENCE_SHAPE_ID")
	private GeoFenceShape geoFenceShape;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "geoFence")
	private GeoFenceCircle geoFenceCircle;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "geoFence")
	private GeoFencePolygon geoFencePolygon;

	public Integer getGeoFenceId() {
		return geoFenceId;
	}

	public void setGeoFenceId(Integer geoFenceId) {
		this.geoFenceId = geoFenceId;
	}

	public Integer getApplyToAllVehicles() {
		return applyToAllVehicles;
	}

	public void setApplyToAllVehicles(Integer applyToAllVehicles) {
		this.applyToAllVehicles = applyToAllVehicles;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public Boolean getEmailMode() {
		return emailMode;
	}

	public void setEmailMode(Boolean emailMode) {
		this.emailMode = emailMode;
	}

	public Boolean getEntryAlert() {
		return entryAlert;
	}

	public void setEntryAlert(Boolean entryAlert) {
		this.entryAlert = entryAlert;
	}

	public Date getEntryNotificationTime() {
		return entryNotificationTime;
	}

	public void setEntryNotificationTime(Date entryNotificationTime) {
		this.entryNotificationTime = entryNotificationTime;
	}

	public Boolean getExitAlert() {
		return exitAlert;
	}

	public void setExitAlert(Boolean exitAlert) {
		this.exitAlert = exitAlert;
	}

	public Date getExitNotificationTime() {
		return exitNotificationTime;
	}

	public void setExitNotificationTime(Date exitNotificationTime) {
		this.exitNotificationTime = exitNotificationTime;
	}

	public String getGeoFenceName() {
		return geoFenceName;
	}

	public void setGeoFenceName(String geoFenceName) {
		this.geoFenceName = geoFenceName;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Timestamp getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(Timestamp lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}

	public Boolean getSkippedAlert() {
		return skippedAlert;
	}

	public void setSkippedAlert(Boolean skippedAlert) {
		this.skippedAlert = skippedAlert;
	}

	public Boolean getSmsMode() {
		return smsMode;
	}

	public void setSmsMode(Boolean smsMode) {
		this.smsMode = smsMode;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidTo() {
		return validTo;
	}

	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}

	public Boolean getWebMode() {
		return webMode;
	}

	public void setWebMode(Boolean webMode) {
		this.webMode = webMode;
	}

	public DicvUser getDicvUser() {
		return dicvUser;
	}

	public void setDicvUser(DicvUser dicvUser) {
		this.dicvUser = dicvUser;
	}

	public DicvGeoFenceType getDicvGeoFenceType() {
		return dicvGeoFenceType;
	}

	public void setDicvGeoFenceType(DicvGeoFenceType dicvGeoFenceType) {
		this.dicvGeoFenceType = dicvGeoFenceType;
	}

	public GeoFenceShape getGeoFenceShape() {
		return geoFenceShape;
	}

	public void setGeoFenceShape(GeoFenceShape geoFenceShape) {
		this.geoFenceShape = geoFenceShape;
	}

	public GeoFenceCircle getGeoFenceCircle() {
		return geoFenceCircle;
	}

	public void setGeoFenceCircle(GeoFenceCircle geoFenceCircle) {
		this.geoFenceCircle = geoFenceCircle;
	}

	public GeoFencePolygon getGeoFencePolygon() {
		return geoFencePolygon;
	}

	public void setGeoFencePolygon(GeoFencePolygon geoFencePolygon) {
		this.geoFencePolygon = geoFencePolygon;
	}
}