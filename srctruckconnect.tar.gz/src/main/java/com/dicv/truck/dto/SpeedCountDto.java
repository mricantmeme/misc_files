/**
 * 
 */
package com.dicv.truck.dto;

/**
 * @author IMT5KOR
 *
 */
public class SpeedCountDto extends StatusMessageDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4389535504415194893L;
	
	private int speedingCount;
	
	

	public int getSpeedingCount() {
		return speedingCount;
	}

	public void setSpeedingCount(int speedingCount) {
		this.speedingCount = speedingCount;
	}
	
	
	
	

}
