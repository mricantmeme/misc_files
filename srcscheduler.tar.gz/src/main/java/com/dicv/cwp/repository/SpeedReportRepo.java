package com.dicv.cwp.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.SpeedReport;

@Repository
public interface SpeedReportRepo extends CrudRepository<SpeedReport, Long> {

	@Query("Select v from SpeedReport v where v.vehicleId=:vehicleId and v.reportDate=:reportDate")
	public SpeedReport getSpeedReport(@Param("vehicleId") Long vehicleId, @Param("reportDate") Date fromDate);

}
