package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the GPS_VEHICLE_PARAMETERS database table.
 * 
 */
@Entity
@Table(name = "GPS_VEHICLE_PARAMETERS")
public class GpsVehicleParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GPS_VEH_PARAM_SEQ")
	@SequenceGenerator(name = "GPS_VEH_PARAM_SEQ", sequenceName = "GPS_VEH_PARAM_SEQ")
	@Column(name = "GPS_VEH_PARAM_ID")
	private Long gpsVehicleParamId;

	@Column(name = "GPS_SPKM")
	private Double gpsSpkm;

	@Column(name = "GPS_TIME")
	private Timestamp gpsTime;

	@Column(name = "CAN_COOLANT_TEMP")
	private Double canCoolantTemp;

	@Column(name = "CAN_ENGINE_SPEED")
	private Long canEngineSpeed;

	@Column(name = "GPS_LATITUDE")
	private Double gpsLatitude;

	@Column(name = "GPS_LONGITUDE")
	private Double gpsLongitude;

	@Column(name = "CAN_VEHICLE_SPEED")
	private Long canVehicleSpeed;

	@Column(name = "GPS_ALTITUDE")
	private Double gpsAltitude;

	@Column(name = "GPS_COG")
	private Integer gpsCog;

	@Column(name = "GPS_HDOP")
	private Double gpsHdop;

	@Column(name = "GPS_IMEI")
	private Long gpsImei;

	@Column(name = "GPS_VOLT")
	private Double gpsVolt;

	@Column(name = "GPS_DATE")
	private Date gpsDate;

	@Column(name = "CAN_FUEL_CONTENT_REL")
	private Integer fuelTankLevel;

	@Column(name = "CAN_VEHICLE_UPDATED_ON")
	private Timestamp vehicleLastUpdateON;

	@Column(name = "ENGINE_ON")
	private Integer engineON;

	@Column(name = "DEVICE_BATTERY")
	private Double deviceBattery;

	@Column(name = "BATTERY_HEALTH")
	private Integer batteryHealth;

	@Column(name = "SIGNAL_STRENGTH")
	private Integer signalStrength;

	@Column(name = "HARSH_ACCELERATION")
	private Integer harshAcceleration;

	@Column(name = "HARSH_BRAKING")
	private Integer harshBraking;

	@Column(name = "HARSH_CORNERING")
	private Integer harshCornering;
	
	@Column(name = "ADBLUE_LEVEL")
	private Double adblueLevel;
	
	@Column(name = "MAIN_BTRY_DISCONNECT")
	private Integer mainBtryDisconnect;


}