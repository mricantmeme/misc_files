package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TRIP_SPEEDING_LOCATIONS")
public class TripSpeedingLocations implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TRIP_TRIPSPEEDID_GENERATOR", sequenceName = "TRIP_SPEEDING_LOCATIONS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRIP_TRIPSPEEDID_GENERATOR")
	@Column(name = "SPEED_LOC_ID")
	private Long speedLocId;

	@Column(name = "TRIP_ID")
	private Long tripId;

	@Column(name = "SPKM")
	private Double gpsSpkm;

	@Column(name = "LATTITUDE")
	private Double gpsLatitude;

	@Column(name = "LONGITUDE")
	private Double gpsLongitude;

	@Column(name = "SPEEDING_GPS_TIME")
	private Date gpsTime;

	public TripSpeedingLocations() {

	}

	public TripSpeedingLocations(Long speedLocId, Long tripId, Double gpsSpkm, Double gpsLatitude, Double gpsLongitude,
			Date gpsTime) {
		super();
		this.speedLocId = speedLocId;
		this.tripId = tripId;
		this.gpsSpkm = gpsSpkm;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
		this.gpsTime = gpsTime;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}


	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	public Date getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(Date gpsTime) {
		this.gpsTime = gpsTime;
	}

	public Long getSpeedLocId() {
		return speedLocId;
	}

	public void setSpeedLocId(Long speedLocId) {
		this.speedLocId = speedLocId;
	}

	public Double getGpsSpkm() {
		return gpsSpkm;
	}

	public void setGpsSpkm(Double gpsSpkm) {
		this.gpsSpkm = gpsSpkm;
	}

}
