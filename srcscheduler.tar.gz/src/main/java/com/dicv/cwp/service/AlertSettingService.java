package com.dicv.cwp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dicv.cwp.dao.model.AlertSettings;
import com.dicv.cwp.repository.AlertSettingsRepo;

@Component
public class AlertSettingService {

	@Autowired
	private AlertSettingsRepo alertSettingRepo;

	public AlertSettings getAlertSettings() {
		return alertSettingRepo.getAlertSetings();
	}

}
