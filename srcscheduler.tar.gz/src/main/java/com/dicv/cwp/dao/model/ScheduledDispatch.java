package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

/**
 * The persistent class for the SCHEDULED_DISPATCH database table.
 * 
 */
@Entity
@Table(name = "SCHEDULED_DISPATCH")
public class ScheduledDispatch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SCHEDULED_DISPATCH_SCHEDULEDDISPATCHID_GENERATOR", sequenceName = "SCHEDULEDDISPATCH_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SCHEDULED_DISPATCH_SCHEDULEDDISPATCHID_GENERATOR")
	@Column(name = "SCHEDULED_DISPATCH_ID")
	private Integer scheduledDispatchId;

	@Column(name = "DATE_TIME")
	private Timestamp dateTime;

	@Column(name = "DISPATCH_TYPE")
	private String dispatchType;

	@Column(name = "FROM_ADDRESS")
	private String fromAddress;

	private Double latitude;

	private Double longitude;

	private String status;

	@Column(name = "TO_ADDRESS")
	private String toAddress;

	@Column(name = "IS_CORDINATES_WRONG")
	private Boolean isCordinatesWrong;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "MODIFIED_DATE")
	private Timestamp modifiedDateTime;

	// bi-directional many-to-one association to Dispatch
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "scheduledDispatch")
	@Where(clause = "IS_DELETED=0")
	private List<Dispatch> dispatches;

	// bi-directional many-to-one association to ScheduledTripLeg
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "SCHEDULED_TRIP_LEG_ID")
	private ScheduledTripLeg scheduledTripLeg;

	// bi-directional many-to-one association to DicvUser for column created by
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "CREATED_BY")
	private DicvUser dicvUserCreatedBy;

	// bi-directional many-to-one association to DicvUser for column updated by
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "UPDATED_BY")
	private DicvUser dicvUserUpdatedBy;

	public ScheduledDispatch() {
	}

	public Integer getScheduledDispatchId() {
		return this.scheduledDispatchId;
	}

	public void setScheduledDispatchId(Integer scheduledDispatchId) {
		this.scheduledDispatchId = scheduledDispatchId;
	}

	public Timestamp getDateTime() {
		return this.dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getDispatchType() {
		return this.dispatchType;
	}

	public void setDispatchType(String dispatchType) {
		this.dispatchType = dispatchType;
	}

	public String getFromAddress() {
		return this.fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getToAddress() {
		return this.toAddress;
	}

	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}

	public Boolean getIsCordinatesWrong() {
		return isCordinatesWrong;
	}

	public void setIsCordinatesWrong(Boolean isCordinatesWrong) {
		this.isCordinatesWrong = isCordinatesWrong;
	}

	public List<Dispatch> getDispatches() {
		return this.dispatches;
	}

	public void setDispatches(List<Dispatch> dispatches) {
		this.dispatches = dispatches;
	}

	public ScheduledTripLeg getScheduledTripLeg() {
		return this.scheduledTripLeg;
	}

	public void setScheduledTripLeg(ScheduledTripLeg scheduledTripLeg) {
		this.scheduledTripLeg = scheduledTripLeg;
	}

	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public DicvUser getDicvUserCreatedBy() {
		return dicvUserCreatedBy;
	}

	public void setDicvUserCreatedBy(DicvUser dicvUserCreatedBy) {
		this.dicvUserCreatedBy = dicvUserCreatedBy;
	}

	public DicvUser getDicvUserUpdatedBy() {
		return dicvUserUpdatedBy;
	}

	public void setDicvUserUpdatedBy(DicvUser dicvUserUpdatedBy) {
		this.dicvUserUpdatedBy = dicvUserUpdatedBy;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

}