package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dao.model.VehicleAlertHistory;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class OverSpeedAlertService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OverSpeedAlertService.class);

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private VehicleAlertService vehicleAlertService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Value("${over_speed_vehicle}")
	private String overSpeedVehicle;

	@Scheduled(fixedDelay = 10000, initialDelay = 60000)
	public void sendOverSpeed() {

		if (overSpeedVehicle.equals("Yes")) {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			List<Vehicle> vehList = vehicleRepo.getAllVehicle();
			processOverSpeed(vehList);
			stopWatch.stop();
			LOGGER.info("OverSpeed Vehicle Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
		}
	}

	private void processOverSpeed(List<Vehicle> vehList) {
		for (Vehicle vehicle : vehList) {
			try {
				processVehicleSpeed(vehicle);
			} catch (Exception ex) {
				LOGGER.error("OverSpeed Vehicle :: " + vehicle, ex);
				return;
			}
		}
	}

	// Add 5 minutes(newTime) time,speed alert should send for every 5 minutes

	private void processVehicleSpeed(Vehicle vehicle) {

		VehicleAlertHistory lastSent = vehicleAlertService.getVehicleAlertHistory(vehicle.getVehicleId(),
				vehicle.getGpsImei().getGpsImei());

		if (vehicle.getVehicleMaxSpeed() == null)
			vehicle.setVehicleMaxSpeed(80);

		if (lastSent.getSpeedGpsProcessTime() == null)
			lastSent.setSpeedGpsProcessTime(DicvUtil.getCurrentTimeStamp());

		List<GpsVehParameterDto> gpsList = gpsVehicleRepo.fetchOverSpeedReport(vehicle.getGpsImei().getGpsImei(),
				lastSent.getSpeedGpsProcessTime(), vehicle.getVehicleMaxSpeed().doubleValue(),
				new PageRequest(0, 1000));

		if (gpsList == null || gpsList.isEmpty()) {
			return;
		}
		Date newTime = new Date(lastSent.getLastSpeedAlertSent().getTime() + (300000));
		for (GpsVehParameterDto gpsVehParameterDto : gpsList) {
			if (newTime.getTime() > gpsVehParameterDto.getGpsTime().getTime()) {
				continue;
			}
			notificationService.saveOverSpeedAlert(vehicle, gpsVehParameterDto);
			vehicleAlertService.updateVehicleOverSpeedTime(new Timestamp(gpsVehParameterDto.getGpsTime().getTime()),
					vehicle.getVehicleId());
			newTime = new Date(gpsVehParameterDto.getGpsTime().getTime() + (300000));
		}
		Integer size = gpsList.size();
		Date lastProcessedTime = gpsList.get(size - 1).getGpsTime();
		vehicleAlertService.updateOverSpeedProcessedTime(new Timestamp(lastProcessedTime.getTime()),
				vehicle.getVehicleId());

	}

}
