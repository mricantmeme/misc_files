package com.dicv.cwp.utils;

public class DicvConstant {

	public static final String IN_TRIP = "IN_TRIP";

	public static final String NOT_IN_TRIP = "NOT_IN_TRIP";

	public static final String VEHICLET_VARIANT_MDT = "MDT";

	public static final String VEHICLE_VARIANT_HDT = "HDT";

	public static final String VEHICLE_THUNDERBOLT = "Thunderbolt";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	public static final String AUTHORIZATION_BEARER = "Bearer";

	public static final String TRIPSTATUS_PLANNED = "PLANNED";

	public static final String TRIPSTATUS_COMPLETED = "COMPLETED";

	public static final String DRIVERSTATUS_AVAILABLE = "AVAILABLE";

	public static final String DRIVERSTATUS_NOTAVAILABLE = "NOTAVAILABLE";

	public static final String VEHICLESTATUS_AVAILABLE = "AVAILABLE";

	public static final String VEHICLESTATUS_NOTAVAILABLE = "NOTAVAILABLE";

	public static final String REPORTS_DATE_FORMAT = "dd-MMM-YY";

	public static final String DRIVER_ROLE = "DRIVER";

	public static final String ROOT_ADMIN_ROLE = "ROOTADMIN";

	public static final String FLEET_MANAGER_ROLE = "FLEETMANAGER";

	public static final String CUSTOMER_ADMIN_ROLE = "CUSTOMERADMIN";

	public static final String VEH_STATUS_RUNNING = "RUNNING";

	public static final String VEH_STATUS_OFFLINE = "OFFLINE";

	public static final String VEH_STATUS_NEW = "NEW";

	public static final String VEH_STATUS_IDLE = "IDLE";

	public static final String CATEGORY_NOT_AVAILABLE = "Category Not Available";

	public static final String GOOGLE_MAP_URL = "https://www.google.com/maps/search/?api=1&query=";

	public static final String ROOT_ADMIN = "Admin";
	public static final String AUTHENTICATION_ERROR = "Exception in Getting Details";
	public static final String VEH_DETAILS = "Exception in Getting Vehicle  Details";
	public static final String NO_RECORDS_FOUND = "No Records Found";
	public static final String IMEI_ALREADY_EXIST = "Gps Imei No Already Exist";
	public static final String MANDATORY_FIELDS_MISSING = "Please provide all Mandatory Fields";
	public static final String GPS_IMEI_CRUD = "Exception in Adding Gps Imei Details";
	public static final String GPS_IMEI = "Exception in Getting Gps Imei Details";
	public static final String VEHICLE_ADD = "Vehicle Added Successfully";
	public static final String VEHICLE_UPDATE = "Vehicle Updated Successfully";
	public static final String USER_NO_PREVILAGE = "User Not have Previlage";
	public static final String VEH_CANNOT_EDIT = "Vehicle Cannot be edited";
	public static final String IMEI_LENGTH = "The IMEI number should have length of 15";
	public static final String CATEGORY_VALID = "Please input valid category";
	public static final String VALID_VEH_TYPE = "Please provide valid vehicle type";

}
