package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.VehicleIdleAlert;
import com.dicv.cwp.dao.model.VehicleIdleTimeProcess;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.VehicleIdleProcessRepo;
import com.dicv.cwp.repository.VehicleIdleRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class VehicleIdlingAlert {

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private VehicleIdleProcessRepo vehicleIdleProcessRepo;

	@Autowired
	private GpsParamService gpsParamService;

	@Autowired
	private VehicleIdleRepo idleRepo;

	@Value("${idling_alert}")
	private String idlingAlert;

	@Autowired
	private GoogleAPIService addressUtil;

	private static final Logger LOGGER = Logger.getLogger(VehicleIdlingAlert.class);

	@Scheduled(fixedDelay = 10000)
	public void schedulerProcess() {
		try {
			if (idlingAlert != null && idlingAlert.equals("Yes")) {
				LOGGER.info("Vehicle Idle Time  Started");
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				startVehicleIdleTime();
				stopWatch.stop();
				LOGGER.info(
						"Vehicle Idle Time Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
			}
		} catch (Exception ex) {
			LOGGER.error("Vehicle Idle Time Error " + ex);
		}

	}

	@Transactional
	public void startVehicleIdleTime() {
		List<VehicleListDto> allVehicleList = vehicleService.getVehicleNoAndIMEI();
		if (allVehicleList != null && allVehicleList.size() > 0) {
			for (VehicleListDto veh : allVehicleList) {
				try {
					processVehicleIdlingAlert(veh);
				} catch (Exception ex) {
					LOGGER.error("Exception Battery Disconnect Vehicle :: " + veh.getRegistrationId(), ex);
					continue;
				}
			}
		}
	}

	private void processVehicleIdlingAlert(VehicleListDto veh) {
		try {
			if (veh.getGpsImei() != null) {

				VehicleIdleTimeProcess idleTimeProcess = vehicleIdleProcessRepo
						.getVehicleIdleTimeProcess(veh.getVehicleId());

				if (idleTimeProcess == null) {
					addIdlingProcess(veh);
				} else if (idleTimeProcess.getProcessTime() == null) {
					idleTimeProcess.setProcessTime(DicvUtil.getCurrentTimeStamp());
					updateIdlingProcessTime(idleTimeProcess);
				} else {
					List<VehicleIdleAlert> idleList = idleRepo.getVehicleIdle(veh.getVehicleId(),
							new PageRequest(0, 1));
					if (idleList != null && idleList.size() > 0) {
						VehicleIdleAlert idle = idleList.get(0);
						checkVehicleIdlingStop(veh, idleTimeProcess, idle);
					} else {
						checkIdlingStartTime(veh, idleTimeProcess);
					}
					updateIdlingProcessTime(idleTimeProcess);

				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while Vehicle Idling Alert processing Vehicle :: " + veh.getRegistrationId(), ex);
		}
	}

	private void checkIdlingStartTime(VehicleListDto veh, VehicleIdleTimeProcess idleTimeProcess) {
		// Next Idle
		GpsVehParameterDto gpsVehParameterDto = gpsParamService.getVehicleIdleTimeStarting(veh.getGpsImei(),
				idleTimeProcess.getProcessTime());

		if (gpsVehParameterDto != null) {
			addIdleStartTime(veh, gpsVehParameterDto);
			idleTimeProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsVehParameterDto.getGpsTime()));
		}
	}

	private void checkVehicleIdlingStop(VehicleListDto veh, VehicleIdleTimeProcess idleTimeProcess,
			VehicleIdleAlert idle) {
		// Check Next Vehicle Running or Engine OFF
		GpsVehParameterDto gpsParam = gpsParamService.engineRunningOrOff(veh.getGpsImei(), idle.getIdleStartTime());
		if (gpsParam != null) {

			// Check Data Sequence

			List<GpsVehParameterDto> gpsList = gpsParamService.getGpsDataForIdling(veh.getGpsImei(),
					idle.getIdleStartTime(), gpsParam.getGpsTime());

			GpsVehParameterDto gpsDataparam = gpsDataInSequence(gpsList);
			if (gpsDataparam == null) {
				updateIdleStopTime(idle, gpsParam, 0);
				idleTimeProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsParam.getGpsTime()));
			} else {
				updateIdleStopTime(idle, gpsDataparam, 1);
				idleTimeProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsDataparam.getGpsTime()));
			}
		}
	}

	private GpsVehParameterDto gpsDataInSequence(List<GpsVehParameterDto> gpsList) {
		if (gpsList != null && gpsList.size() > 1) {

			final Integer totalRecords = gpsList.size();
			GpsVehParameterDto gpsVehicleParamNext = null;
			Integer gpsRecordCount = 0;
			for (GpsVehParameterDto gpsVehicleParam : gpsList) {
				gpsRecordCount = gpsRecordCount + 1;
				if (gpsRecordCount >= totalRecords) {
					break;
				}
				gpsVehicleParamNext = gpsList.get(gpsRecordCount);

				Long vehicleDiffInSeconds = (gpsVehicleParamNext.getGpsTime().getTime()
						- gpsVehicleParam.getGpsTime().getTime()) / 1000;
				if (vehicleDiffInSeconds > 900) {
					return gpsVehicleParam;
				}

			}
		}
		return null;
	}

	private void addIdleStartTime(VehicleListDto veh, GpsVehParameterDto gpsVehParameterDto) {
		VehicleIdleAlert idleTime = new VehicleIdleAlert();
		idleTime.setIdleStartTime(new Timestamp(gpsVehParameterDto.getGpsTime().getTime()));
		idleTime.setVehicleId(veh.getVehicleId());
		idleTime.setLatitude(gpsVehParameterDto.getGpsLatitude());
		idleTime.setLongitude(gpsVehParameterDto.getGpsLongitude());
		idleTime.setCreatedAt(DicvUtil.getCurrentTimeStamp());
		Address address = addressUtil.getAddress(gpsVehParameterDto.getGpsLatitude(),
				gpsVehParameterDto.getGpsLongitude());
		if (address.getResponse()) {
			idleTime.setLocation(address.getAddress());
			idleTime.setGeoResponse(2);
		} else {
			idleTime.setGeoResponse(0);
		}
		idleRepo.save(idleTime);
	}

	private void updateIdleStopTime(VehicleIdleAlert idle, GpsVehParameterDto gpsParam, Integer dataLoss) {
		idle.setIdleStopTime(new Timestamp(gpsParam.getGpsTime().getTime()));
		idle.setTimeSpent(gpsParam.getGpsTime().getTime() - idle.getIdleStartTime().getTime());
		idle.setIsDataLoss(dataLoss);
		idleRepo.save(idle);
	}

	private void addIdlingProcess(VehicleListDto veh) {
		VehicleIdleTimeProcess vehicleIdleTimeProcess = new VehicleIdleTimeProcess();
		vehicleIdleTimeProcess.setProcessTime(DicvUtil.getCurrentTimeStamp());
		vehicleIdleTimeProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		vehicleIdleTimeProcess.setVehicleId(veh.getVehicleId());
		vehicleIdleProcessRepo.save(vehicleIdleTimeProcess);
	}

	private void updateIdlingProcessTime(VehicleIdleTimeProcess vehicleIdleTimeProcess) {
		vehicleIdleTimeProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		vehicleIdleProcessRepo.save(vehicleIdleTimeProcess);
	}

}
