package com.dicv.cwp.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.VehicleUtilization;
@Repository
public interface VehicleUtilizationRepo extends CrudRepository<VehicleUtilization, Long> {

	@Query("Select v from VehicleUtilization v where v.vehicleId=:vehicleId and v.reportDate=:fromDate")
	public VehicleUtilization getVehicleUtilization(@Param("vehicleId") Long vehicleId,
			@Param("fromDate") Date fromDate);

}
