package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleAlertHistory;

@Repository
public interface VehicleAlertHistoryRepo extends CrudRepository<VehicleAlertHistory, Long> {

	@Query("Select a from VehicleAlertHistory a where a.vehicleId=:vehicleId")
	public List<VehicleAlertHistory> getVehicleAlertHistory(@Param("vehicleId") Long vehicleId);

	/* Over Speed Alert */

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleAlertHistory g set g.lastSpeedAlertSent =:lastSpeedAlertSent where g.vehicleId =:vehicleId")
	public void updateLastSpeedAlertSent(@Param("lastSpeedAlertSent") Timestamp lastSpeedAlertSent,
			@Param("vehicleId") Long vehicleId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleAlertHistory g set g.speedGpsProcessTime =:speedGpsProcessTime where g.vehicleId =:vehicleId")
	public void updateOverSpeedProcessedTime(@Param("speedGpsProcessTime") Timestamp speedGpsProcessTime,
			@Param("vehicleId") Long vehicleId);

	/* Battery Health Alert */

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleAlertHistory v set v.mainBatteryDetected=:mainBatteryDetected where v.vehicleId =:vehicleId")
	public void updateBatteryDisconnect(@Param("mainBatteryDetected") Timestamp mainBatteryDetected,
			@Param("vehicleId") Long vehicleId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update VehicleAlertHistory v set v.idleTimeProcess=:idleTimeProcess where v.vehicleId =:vehicleId")
	public void updateIdleTime(@Param("idleTimeProcess") Timestamp idleTimeProcess, @Param("vehicleId") Long vehicleId);

}
