package com.dicv.cwp.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.dicv.cwp.dto.Address;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.GeocodingApiRequest;
import com.google.maps.model.AddressComponent;
import com.google.maps.model.AddressComponentType;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;

@Component
public class GoogleAPIService {

	@Value("${google_api_key}")
	private String googleApiKey;

	private static Logger LOGGER = Logger.getLogger(GoogleAPIService.class);

	public Address getAddress(Double latitude, Double longitude) {
		Address address = new Address();
		try {
			address.setResponse(false);
			if (latitude == null || longitude == null)
				return address;
			GeoApiContext context = new GeoApiContext().setApiKey(googleApiKey);
			LatLng latlng = new LatLng(latitude, longitude);
			GeocodingResult[] results = GeocodingApi.newRequest(context).latlng(latlng).await();
			if (results != null) {
				if (results[0].formattedAddress != null) {
					address.setAddress(results[0].formattedAddress);
					for (AddressComponent add : results[0].addressComponents) {
						if (add.types[0].equals(AddressComponentType.ADMINISTRATIVE_AREA_LEVEL_2)) {
							address.setCity(add.longName + " ,");
							address.setResponse(true);
						}
						if (add.types[0].equals(AddressComponentType.ADMINISTRATIVE_AREA_LEVEL_1)) {
							address.setState(add.longName);
							address.setResponse(true);
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error Calling Google API ", e);
			return address;
		}
		return address;
	}

}
