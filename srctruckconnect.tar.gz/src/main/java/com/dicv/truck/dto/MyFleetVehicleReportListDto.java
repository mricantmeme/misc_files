package com.dicv.truck.dto;

import java.util.List;

public class MyFleetVehicleReportListDto {
	

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7928314270217884128L;
	
	
	private List<MyFleetVehicleReport> myFleetVehicleReport;


	public List<MyFleetVehicleReport> getMyFleetVehicleReport() {
		return myFleetVehicleReport;
	}


	public void setMyFleetVehicleReport(List<MyFleetVehicleReport> myFleetVehicleReport) {
		this.myFleetVehicleReport = myFleetVehicleReport;
	}

	
	



}
