package com.dicv.cwp.dto;

import java.util.Date;

public class GeoFenceGpsDto {

	public GeoFenceGpsDto(Long gpsVehicleParamId, Date gpsTime, Double gpsLatitude, Double gpsLongitude, Long gpsImei) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
		this.gpsTime = gpsTime;
		this.gpsImei = gpsImei;
	}

	private Long gpsVehicleParamId;

	private Double gpsLatitude;

	private Double gpsLongitude;

	private Date gpsTime;

	private Long gpsImei;

	public Long getGpsVehicleParamId() {
		return gpsVehicleParamId;
	}

	public void setGpsVehicleParamId(Long gpsVehicleParamId) {
		this.gpsVehicleParamId = gpsVehicleParamId;
	}

	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public Date getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(Date gpsTime) {
		this.gpsTime = gpsTime;
	}
}
