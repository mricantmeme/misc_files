package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dto.GpsVehParameterDto;

@Repository
public class GpsParamRepoImpl implements GpsParamRepo {

	@PersistenceContext
	EntityManager entityManager;

	private static final Logger LOGGER = Logger.getLogger(GpsParamRepoImpl.class);


	@Override
	public Integer countofHarshEvents(Timestamp startTime, Timestamp endTime, Long imeiNo, String harshName) {

		try {

			String queryStr = "Select SUM(" + harshName
					+ ")  from GpsVehicleParameter g where g.gpsImei=:gpsImei and g.gpsTime>="
					+ ":startTime  and g.gpsTime<=:endTime";
			Query query = entityManager.createQuery(queryStr);
			query.setParameter("startTime", startTime);
			query.setParameter("endTime", endTime);
			query.setParameter("gpsImei", imeiNo);
			Long count = (Long) query.getSingleResult();
			if (count != null && count > 0) {
				return count.intValue();
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Harsh Event", ex);
		}
		return 0;

	}



	@Override
	public GpsVehParameterDto getGpsStopLocation(long imeiNo, Date startParamTime, Date lastStopTime,
			Date lastParamTime, boolean start) {
		try {
			String gpsQuery = "Select new com.dicv.cwp.dto.GpsVehParameterDto(g.gpsVehicleParamId,"
					+ "g.gpsSpkm,g.gpsTime,g.engineON,g.gpsLatitude,g.gpsLongitude)  from GpsVehicleParameter g where g.gpsImei=:gpsImei "
					+ " and g.gpsTime >:lastStopTime ";

			if (start) {
				gpsQuery = gpsQuery + " and g.gpsSpkm>0";
			} else {
				gpsQuery = gpsQuery + " and g.gpsSpkm=0";
			}

			gpsQuery = gpsQuery
					+ " and g.gpsTime >= :startParamTime and g.gpsTime <= :lastParamTime and g.gpsTime is NOT NULL order by gpsTime asc ";

			Query query = entityManager.createQuery(gpsQuery);
			query.setParameter("startParamTime", startParamTime);
			query.setParameter("lastStopTime", lastStopTime);
			query.setParameter("lastParamTime", lastParamTime);
			query.setParameter("gpsImei", imeiNo);
			query.setMaxResults(1);
			List<GpsVehParameterDto> gpsVehicleParameterList = query.getResultList();
			if (gpsVehicleParameterList != null && gpsVehicleParameterList.size() > 0) {
				return gpsVehicleParameterList.get(0);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in getting Vehicle getGpsStopLocation Details for Trip Analysis for IMEI {} " + imeiNo + " " + ex);
		}
		return null;

	}

}
