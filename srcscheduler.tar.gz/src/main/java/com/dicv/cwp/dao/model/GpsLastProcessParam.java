package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "LAST_PROCESSED_PARAM")
public class GpsLastProcessParam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LAST_PROCESSED_PARAM_SEQ")
	@SequenceGenerator(name = "LAST_PROCESSED_PARAM_SEQ", sequenceName = "LAST_PROCESSED_PARAM_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "LAST_PROCESSED_PARAM_ID")
	private Long lastProcessedId;

	@Column(name = "LAST_GEO_PARAM_ID")
	private Long lastProcessedFenceId;

	@Column(name = "POLLING_COUNT")
	private Integer pollingCount;

	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;

	@Column(name = "OFFLINE_WAIT_TIME")
	private Integer offLineWaitTime;

	@Column(name = "TRIP_WAIT_TIME")
	private Integer tripWaitTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLastProcessedId() {
		return lastProcessedId;
	}

	public void setLastProcessedId(Long lastProcessedId) {
		this.lastProcessedId = lastProcessedId;
	}

	public Long getLastProcessedFenceId() {
		return lastProcessedFenceId;
	}

	public void setLastProcessedFenceId(Long lastProcessedFenceId) {
		this.lastProcessedFenceId = lastProcessedFenceId;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Integer getPollingCount() {
		return pollingCount;
	}

	public void setPollingCount(Integer pollingCount) {
		this.pollingCount = pollingCount;
	}

	public Integer getOffLineWaitTime() {
		return offLineWaitTime;
	}

	public void setOffLineWaitTime(Integer offLineWaitTime) {
		this.offLineWaitTime = offLineWaitTime;
	}

	public Integer getTripWaitTime() {
		return tripWaitTime;
	}

	public void setTripWaitTime(Integer tripWaitTime) {
		this.tripWaitTime = tripWaitTime;
	}

}
