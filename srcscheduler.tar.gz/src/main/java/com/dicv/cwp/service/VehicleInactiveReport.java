package com.dicv.cwp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleEventReport;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.VehicleEventReportRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class VehicleInactiveReport {

	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleInactiveReport.class);

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private GpsParamService gpsParamService;

	@Autowired
	private VehicleEventReportRepo vehicleEventReportRepo;

	@Value("${vehicle_inactive_report}")
	private String vehicleInactiveReport;

	@Scheduled(cron = "0 0 4 * * *")
	public void startInactiveReport() {
		try {
			if (vehicleInactiveReport.equals("Yes")) {
				List<VehicleListDto> vehList = vehicleService.getVehicleNoAndIMEI();
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yy");
				Date gpsDate = sdf1.parse(getPreviousDay(new Date()));
				if (vehList != null && vehList.size() > 0) {
					updateVehicleEventCount(vehList, gpsDate);
				}
				LOGGER.info("Inactive Report Completed");
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Inactive Report ", ex);
		}
	}

	private void updateVehicleEventCount(List<VehicleListDto> vehList, Date gpsDate) throws ParseException {
		deleteReport(gpsDate);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HHmmss");
		Date previousDayStartTime = sdf.parse(DicvUtil.getStartTimeOfDate(gpsDate));
		Date previousDayEndTime = sdf.parse(DicvUtil.getEndTimeOfDate(gpsDate));
		for (VehicleListDto veh : vehList) {
			try {
				processVehicle(veh.getVehicleId(), veh.getGpsImei(), previousDayStartTime, previousDayEndTime, gpsDate);
			} catch (Exception ex) {
				LOGGER.error("Exception in Inactive Report ", ex);
			}
		}
		LOGGER.info("Process Completed for " + gpsDate);
	}

	@Async
	public void fromController(Date fromDate) {
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yy");
			List<VehicleListDto> vehList = vehicleService.getVehicleNoAndIMEI();
			Date gpsDate = sdf1.parse(getDay(fromDate));
			if (vehList != null && vehList.size() > 0) {
				updateVehicleEventCount(vehList, gpsDate);
			}
		} catch (Exception e) {
			LOGGER.error("Exception :: " + e.getMessage());
		}
	}

	@Transactional
	private void processVehicle(Long vehicleId, Long gpsImei, Date fromTime, Date toTime, Date gpsDate) {
		VehicleEventReport vehicleEventReport = new VehicleEventReport();
		vehicleEventReport.setVehicleId(vehicleId);
		vehicleEventReport.setGpsCount(gpsParamService.countofGpsParamEvents(gpsImei, fromTime, toTime));
		vehicleEventReport.setGpsDate(gpsDate);
		vehicleEventReport.setModifiedDateTime(DicvUtil.getCurrentTimeStamp());
		vehicleEventReportRepo.save(vehicleEventReport);

	}

	@Transactional
	private void deleteReport(Date gpsDate) {
		vehicleEventReportRepo.deleteReport(gpsDate);

	}

	public static String getPreviousDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yy");
		return sdf1.format(calendar.getTime());
	}

	public static String getDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yy");
		return sdf1.format(calendar.getTime());
	}

}
