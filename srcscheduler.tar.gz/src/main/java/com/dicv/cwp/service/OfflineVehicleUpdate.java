package com.dicv.cwp.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.GpsLastProcessParam;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.repository.GpsLastProcessRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvConstant;

@Component
public class OfflineVehicleUpdate {

	private static final Logger LOGGER = LoggerFactory.getLogger(OfflineVehicleUpdate.class);


	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private GpsLastProcessRepo gpsLastProcessRepo;

	@Value("${offline_vehicle_close}")
	private String closeVehicle;

	@Scheduled(fixedDelay = 60000)
	public void vehicleStatusUpdate() {
		try {
			if (closeVehicle.equals("Yes")) {
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				List<Vehicle> vehRunningList = getRunningIdleVehListWithNoNewData();
				if (vehRunningList != null && vehRunningList.size() > 0) {
					for (Vehicle veh : vehRunningList) {
						try {
							vehicleRepo.updateVehicleStatus(DicvConstant.VEH_STATUS_OFFLINE, veh.getVehicleId());
						} catch (Exception ex) {
							LOGGER.error("Exception in OFFLINE Vehicle Closing Status ", ex);
						}
					}
				}
				stopWatch.stop();
				LOGGER.info("Offline Vehicle Close Completed ::  TimeTaken in Seconds = "
						+ stopWatch.getTotalTimeSeconds());
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in OFFLINE Vehicle Closing Status ", ex);
		}
	}

	private List<Vehicle> getRunningIdleVehListWithNoNewData() {
		GpsLastProcessParam gpsProcess = gpsLastProcessRepo.findAll().get(0);
		List<String> vehStatus = new ArrayList<String>();
		vehStatus.add(DicvConstant.VEH_STATUS_RUNNING);
		vehStatus.add(DicvConstant.VEH_STATUS_IDLE);
		Date now = new Date();
		Date timeDiff = new Date(now.getTime() - (gpsProcess.getOffLineWaitTime()));
		List<Vehicle> vehRunningList = vehicleRepo.getUnReachedVehicle(vehStatus, timeDiff);
		return vehRunningList;
	}

}
