package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.AlertSettings;
import com.dicv.cwp.dao.model.FuelDropAlert;
import com.dicv.cwp.dao.model.FuelDropProcessTime;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.GpsVehParamDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.FuelDropAlertRepo;
import com.dicv.cwp.repository.FuelDropProcessRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class FuelDropService {

	@Autowired
	private FuelDropAlertRepo fuelDropAlertRepo;

	@Autowired
	private GpsParamService gpsParamService;

	@Autowired
	private FuelDropProcessRepo fuelDropProcessRepo;

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private AlertSettingService alertSettingService;
	
	@Autowired
	private GoogleAPIService addressUtil;

	private static final Logger LOGGER = Logger.getLogger(FuelDropService.class);

	@Value("${fuel_drop}")
	private String fuelDrop;

	@Scheduled(fixedDelay = 10000, initialDelay = 60000)
	public void schedulerProcess() {
		if (fuelDrop != null && fuelDrop.equals("Yes")) {
			LOGGER.info("Fuel Drop Started ");
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			startFuelDropProcess();
			stopWatch.stop();
			LOGGER.info("Fuel Drop Completed in " + stopWatch.getTotalTimeSeconds());
		}
	}

	public void startFuelDropProcess() {
		AlertSettings alertSetings = alertSettingService.getAlertSettings();
		List<VehicleListDto> vehicleList = vehicleService.getVehicleNoAndIMEI();
		if (vehicleList != null && vehicleList.size() > 0) {
			for (VehicleListDto veh : vehicleList) {
				try {
					processForVehicle(veh, alertSetings.getFuelDrop(), alertSetings.getFuelDropRetry());
				} catch (Exception ex) {
					LOGGER.error("Exception while processing Fuel Drop Schedular :: " + veh.getVehicleId(), ex);
				}
			}
		}
	}

	@Transactional
	public void processForVehicle(VehicleListDto veh, Integer fuelDrop, Integer fuelDropRetry) {
		if (veh.getGpsImei() != null) {
			FuelDropProcessTime fuelProcessTime = fuelDropProcessRepo.getFuelDropProcess(veh.getVehicleId());
			if (fuelProcessTime == null) {
				fuelProcessTime = saveFuelDropProcess(veh);
			} else {
				try {
					List<GpsVehParamDto> gpsParamData = gpsParamService.collectGpsData(veh, fuelProcessTime);
					if (gpsParamData != null && gpsParamData.size() > 1) {
						// Fuel Drop
						checkFFuelLevel(veh, fuelProcessTime, gpsParamData, fuelDrop, fuelDropRetry); // FD for loop end
					}
				} catch (Exception ex) {
					LOGGER.error("Exception while processing Fuel Drop Vehicle :: " + veh.getVehicleId(), ex);
					fuelDropProcessRepo.save(fuelProcessTime);
					return;
				}
				fuelProcessTime.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
				fuelDropProcessRepo.save(fuelProcessTime);
			}

		}
	}

	private FuelDropProcessTime saveFuelDropProcess(VehicleListDto veh) {
		FuelDropProcessTime fuelProcessTime;
		fuelProcessTime = new FuelDropProcessTime();
		fuelProcessTime.setVehicleId(veh.getVehicleId());
		fuelProcessTime.setProcessTime(DicvUtil.getCurrentTimeStamp());
		fuelProcessTime.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		fuelProcessTime = fuelDropProcessRepo.save(fuelProcessTime);
		return fuelProcessTime;
	}

	private void checkFFuelLevel(VehicleListDto veh, FuelDropProcessTime fuelProcessTime,
			List<GpsVehParamDto> gpsParamData, Integer fuelDrop, Integer fuelDropRetry) {
		Integer difference = 0;
		GpsVehParamDto gpsParamPrev = gpsParamData.get(0);
		Integer size = gpsParamData.size();
		Integer i = 0;
		boolean isFuelDropExist = false;

		for (GpsVehParamDto gpsParam : gpsParamData) {
			fuelProcessTime.setProcessTime(DicvUtil.getTimeStampFromDate(gpsParam.getGpsTime()));
			i = i + 1;
			if (i == 1 || i >= size) {
				continue;
			}
			difference = gpsParamPrev.getFuelTankLevel() - gpsParam.getFuelTankLevel();
			if (difference >= fuelDrop) {
				// check for Next occurrence
				List<GpsVehParamDto> newGpsParamData = gpsParamService.collectGpsDataForFuelDropRetry(veh.getGpsImei(),
						new Timestamp(gpsParam.getGpsTime().getTime()), fuelDropRetry);
				gpsInnerLoop: for (GpsVehParamDto latestGpsVehParamDto : newGpsParamData) {
					fuelProcessTime.setProcessTime(DicvUtil.getTimeStampFromDate(latestGpsVehParamDto.getGpsTime()));
					Integer newDifference = gpsParamPrev.getFuelTankLevel() - latestGpsVehParamDto.getFuelTankLevel();
					if (newDifference >= fuelDrop) {
						isFuelDropExist = true;
					} else {
						isFuelDropExist = false;
						fuelDropProcessRepo.save(fuelProcessTime);
						break gpsInnerLoop;
					}
				}
				if (isFuelDropExist) {
					LOGGER.info("Fuel Drop Detected " + gpsParam.getGpsTime());
					saveFuelDropAlert(veh, gpsParamPrev, gpsParam);
					fuelDropProcessRepo.save(fuelProcessTime);
					break;
				}
			}
			gpsParamPrev = new GpsVehParamDto(gpsParam);
		}
	}

	private void saveFuelDropAlert(VehicleListDto veh, GpsVehParamDto gpsParamPrev, GpsVehParamDto gpsParam) {
		FuelDropAlert fuelDropAlert = new FuelDropAlert();
		fuelDropAlert.setCreatedAt(DicvUtil.getCurrentTimeStamp());
		fuelDropAlert.setFromLevel(gpsParamPrev.getFuelTankLevel());
		fuelDropAlert.setFuelDropToTime(DicvUtil.getTimeStampFromDate(gpsParam.getGpsTime()));
		fuelDropAlert.setFuelDropTime(DicvUtil.getTimeStampFromDate(gpsParamPrev.getGpsTime()));
		fuelDropAlert.setLatitude(gpsParamPrev.getGpsLatitude());
		fuelDropAlert.setLongitude(gpsParamPrev.getGpsLongitude());
		fuelDropAlert.setToLatitude(gpsParam.getGpsLatitude());
		fuelDropAlert.setToLongitude(gpsParam.getGpsLongitude());
		fuelDropAlert.setToLevel(gpsParam.getFuelTankLevel());
		fuelDropAlert.setVehicleId(veh.getVehicleId());	Address address = addressUtil.getAddress(gpsParam.getGpsLatitude(),
				gpsParam.getGpsLongitude());
		fuelDropAlert.setEmailSent(0);
		if (address.getResponse()) {
			fuelDropAlert.setLocation(address.getAddress());
			fuelDropAlert.setGeoResponse(2);
		} else {
			fuelDropAlert.setGeoResponse(0);
		}
		fuelDropAlertRepo.save(fuelDropAlert);
		gpsParamPrev = new GpsVehParamDto(gpsParam);
	}

}
