package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "FUEL_DROP")
public class FuelDropAlert {
	
	@Id
	@SequenceGenerator(name = "FUEL_DROP_ID_GENERATOR", sequenceName = "FUEL_DROP_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FUEL_DROP_ID_GENERATOR")
	@Column(name = "FUEL_DROP_ID")
	private Long fuelDropId;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	@Column(name = "FUEL_DROP_TIME")
	private Timestamp fuelDropTime;
	
	@Column(name = "TO_FUEL_DROP_TIME")
	private Timestamp fuelDropToTime;

	@Column(name = "CREATED_AT")
	private Timestamp createdAt;

	@Column(name = "FROM_LEVEL")
	private Integer fromLevel;
	
	@Column(name = "TO_LEVEL")
	private Integer toLevel;
	
	@Column(name = "LATITUDE")
	private Double latitude;

	@Column(name = "LONGITUDE")
	private Double longitude;
	
	@Column(name = "TO_LATITUDE")
	private Double toLatitude;

	@Column(name = "TO_LONGITUDE")
	private Double toLongitude;
	
	@Column(name = "EMAIL_SENT")
	private Integer emailSent;
	
	@Column(name = "GEO_RESPONSE")
	private Integer geoResponse;
	
	@Column(name = "LOCATION")
	private String location;

	public Long getFuelDropId() {
		return fuelDropId;
	}

	public void setFuelDropId(Long fuelDropId) {
		this.fuelDropId = fuelDropId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Timestamp getFuelDropTime() {
		return fuelDropTime;
	}

	public void setFuelDropTime(Timestamp fuelDropTime) {
		this.fuelDropTime = fuelDropTime;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Integer getFromLevel() {
		return fromLevel;
	}

	public void setFromLevel(Integer fromLevel) {
		this.fromLevel = fromLevel;
	}

	public Integer getToLevel() {
		return toLevel;
	}

	public void setToLevel(Integer toLevel) {
		this.toLevel = toLevel;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Timestamp getFuelDropToTime() {
		return fuelDropToTime;
	}

	public void setFuelDropToTime(Timestamp fuelDropToTime) {
		this.fuelDropToTime = fuelDropToTime;
	}

	public Double getToLatitude() {
		return toLatitude;
	}

	public void setToLatitude(Double toLatitude) {
		this.toLatitude = toLatitude;
	}

	public Double getToLongitude() {
		return toLongitude;
	}

	public void setToLongitude(Double toLongitude) {
		this.toLongitude = toLongitude;
	}

	@Override
	public String toString() {
		return "FuelDropAlert [fuelDropId=" + fuelDropId + ", vehicleId=" + vehicleId + ", fuelDropTime=" + fuelDropTime
				+ ", fuelDropToTime=" + fuelDropToTime + ", createdAt=" + createdAt + ", fromLevel=" + fromLevel
				+ ", toLevel=" + toLevel + ", latitude=" + latitude + ", longitude=" + longitude + ", toLatitude="
				+ toLatitude + ", toLongitude=" + toLongitude + "]";
	}

	public Integer getEmailSent() {
		return emailSent;
	}

	public void setEmailSent(Integer emailSent) {
		this.emailSent = emailSent;
	}

	public Integer getGeoResponse() {
		return geoResponse;
	}

	public void setGeoResponse(Integer geoResponse) {
		this.geoResponse = geoResponse;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
