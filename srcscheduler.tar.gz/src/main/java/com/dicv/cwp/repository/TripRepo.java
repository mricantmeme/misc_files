package com.dicv.cwp.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.Trip;

@Repository
public interface TripRepo extends JpaRepository<Trip, Long> {

	@Query("Select t from Trip t where t.tripId=:tripId")
	public Trip getTripDetails(@Param("tripId") Long tripId);

	@Query("Select t from Trip t where t.tripStatus=:tripStatus and t.processStatus=:processStatus order by tripId asc")
	public List<Trip> getTripListByStatus(@Param("tripStatus") String tripStatus,
			@Param("processStatus") Integer processStatus, Pageable pageable);

	@Query("Select t from Trip t where t.tripStatus=:tripStatus and t.nosOfStop=:nosOfStop and t.tripId<=:processTripId  order by tripId desc")
	public List<Trip> getTripListByStopStatus(@Param("tripStatus") String tripStatus,
			@Param("nosOfStop") Integer nosOfStop, @Param("processTripId") Long processTripId, Pageable pageable);

	@Query("Select t from Trip t where  t.processStatus=:processStatus")
	public List<Trip> getTripListByProcessStatus(@Param("processStatus") Integer processStatus, Pageable pageable);

	@Query("Select t.tripId from Trip t where t.geoResponse=1 AND t.stopLocationLat is NOT NULL  order by tripId desc")
	public List<Long> getTripListForAddressUpdate(Pageable pageable);

	@Query("Select t from Trip t where t.vehicleId=:vehicleId and t.tripStatus=:tripStatus and t.scheduledTripId is null")
	public List<Trip> getActiveTripForVehicleId(@Param("vehicleId") Long vehicleId,
			@Param("tripStatus") String tripStatus);

	@Query("Select t from Trip t where t.vehicleId=:vehicleId and t.tripStatus=:tripStatus and t.scheduledTripId is null")
	public List<Trip> getActiveTripByVehicle(@Param("vehicleId") Long vehicleId,
			@Param("tripStatus") String tripStatus);

	@Query("Select t from Trip t where t.vehicleId=:vehicleId and t.tripStartTime >=:fromDate and t.tripStartTime <=:endDate and "
			+ " t.tripEndTime >=:fromDate and t.tripEndTime <=:endDate")
	public List<Trip> getTripByVehicle(@Param("vehicleId") Long vehicleId, @Param("fromDate") Date fromDate,
			@Param("endDate") Date endDate);

	@Query("Select t from Trip t where t.vehicleId=:vehicleId and t.tripStartTime >=:fromDate and t.tripStartTime<=:endDate and (t.tripEndTime >:endDate OR t.tripEndTime is NULL)")
	public List<Trip> getDiffStartandEndDates(@Param("vehicleId") Long vehicleId, @Param("fromDate") Date fromDate,
			@Param("endDate") Date endDate);

}
