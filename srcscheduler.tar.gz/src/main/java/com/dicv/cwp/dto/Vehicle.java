package com.dicv.cwp.dto;

import java.util.Date;

public class Vehicle {

	private Long vehicleId;

	private Double currentLatitude;

	private Double currentLongtitude;

	private Date vehicleUpdateTime;

	private Integer inTrip;

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Double getCurrentLatitude() {
		return currentLatitude;
	}

	public void setCurrentLatitude(Double currentLatitude) {
		this.currentLatitude = currentLatitude;
	}

	public Double getCurrentLongtitude() {
		return currentLongtitude;
	}

	public void setCurrentLongtitude(Double currentLongtitude) {
		this.currentLongtitude = currentLongtitude;
	}

	public Date getVehicleUpdateTime() {
		return vehicleUpdateTime;
	}

	public void setVehicleUpdateTime(Date vehicleUpdateTime) {
		this.vehicleUpdateTime = vehicleUpdateTime;
	}

	public Integer getInTrip() {
		return inTrip;
	}

	public void setInTrip(Integer inTrip) {
		this.inTrip = inTrip;
	}

}
