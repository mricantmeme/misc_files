/*package com.dicv.cwp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.dicv.cwp.schedular.BatteryDisconnectAlert;
import com.dicv.cwp.schedular.BatteryHealthAlert;
import com.dicv.cwp.schedular.DeviceHealthReport;
import com.dicv.cwp.schedular.DriverAnalysis;
import com.dicv.cwp.schedular.FuelDropAlert;
import com.dicv.cwp.schedular.GeoFenceAlertService;
import com.dicv.cwp.schedular.GeoFenceUpdate;
import com.dicv.cwp.schedular.GpsEventPollar;
import com.dicv.cwp.schedular.NightDrivingReport;
import com.dicv.cwp.schedular.OfflineVehicleUpdate;
import com.dicv.cwp.schedular.OverSpeedAlertService;
import com.dicv.cwp.schedular.TripAddressUpdate;
import com.dicv.cwp.schedular.TripAnalysis;
import com.dicv.cwp.schedular.TripEventPollar;
import com.dicv.cwp.schedular.TruckAnalysis;
import com.dicv.cwp.schedular.VehicleAlertService;
import com.dicv.cwp.schedular.VehicleInactiveReport;

@EnableAsync
@EnableScheduling
@Configuration
public class SpringAsyncConfig extends WebMvcConfigurationSupport {

	@Bean
	public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setCorePoolSize(100);
		threadPoolTaskExecutor.setMaxPoolSize(1000);
		threadPoolTaskExecutor.setThreadPriority(1);
		threadPoolTaskExecutor.setQueueCapacity(30);
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		return threadPoolTaskExecutor;
	}

	@Bean
	public TaskScheduler taskScheduler() {
		return new ConcurrentTaskScheduler();
	}

	@Bean
	public BatteryDisconnectAlert batteryDisconnectAlert() {
		return new BatteryDisconnectAlert();
	}

	@Bean
	public BatteryHealthAlert batteryHealthAlert() {
		return new BatteryHealthAlert();
	}

	@Bean
	public DeviceHealthReport deviceHealthReport() {
		return new DeviceHealthReport();
	}

	@Bean
	public DriverAnalysis driverAnalysis() {
		return new DriverAnalysis();
	}

	@Bean
	public FuelDropAlert fuelDropAlert() {
		return new FuelDropAlert();
	}

	@Bean
	public GeoFenceAlertService geoFenceAlertService() {
		return new GeoFenceAlertService();
	}

	@Bean
	public GeoFenceUpdate geoFenceUpdate() {
		return new GeoFenceUpdate();
	}

	@Bean
	public GpsEventPollar gpsEventPollar() {
		return new GpsEventPollar();
	}

	@Bean
	public NightDrivingReport nightDrivingReport() {
		return new NightDrivingReport();
	}

	@Bean
	public OfflineVehicleUpdate OfflineVehicleUpdate() {
		return new OfflineVehicleUpdate();
	}

	@Bean
	public OverSpeedAlertService overSpeedAlertService() {
		return new OverSpeedAlertService();
	}

	@Bean
	public TripAddressUpdate tripAddressUpdate() {
		return new TripAddressUpdate();
	}

	@Bean
	public TripAnalysis tripAnalysis() {
		return new TripAnalysis();
	}

	@Bean
	public TripEventPollar tripEventPollar() {
		return new TripEventPollar();
	}

	@Bean
	public TruckAnalysis truckAnalysis() {
		return new TruckAnalysis();
	}

	@Bean
	public VehicleAlertService vehicleAlertService() {
		return new VehicleAlertService();
	}

	@Bean
	public VehicleInactiveReport vehicleInactiveReport() {
		return new VehicleInactiveReport();
	}

}
*/