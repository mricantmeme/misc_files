package com.dicv.cwp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.NightDriving;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.NightDrivingRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.service.SendMailService;
import com.dicv.cwp.utils.DicvUtil;
import com.dicv.cwp.utils.DistanceCalculation;

@Service
public class NightDrivingReport {

	@Value("${night_driving}")
	private String vehicleUtilization;

	@Value("${server_name}")
	private String serverName;

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private SendMailService sendMailService;

	@Autowired
	private NightDrivingRepo nightDrivingRepo;

	private static final Logger LOGGER = LoggerFactory.getLogger(NightDrivingReport.class);

	@Scheduled(cron = "0 0 6 * * *")
	public void schedulerProcess() {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			if (vehicleUtilization != null && vehicleUtilization.equals("Yes")) {

				List<Vehicle> allVehicleList = vehicleRepo.getAllVehicle();
				processVehicleUtilization(allVehicleList);
				watch.stop();
				LOGGER.info("Night Driving Report Completed  :: ");
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Night Driving Report  " + ex);
			sendEmail("Vehicle Night Driving Report :: " + serverName, "Exception in Night Driving Report ");
		}

	}

	private void processVehicleUtilization(List<Vehicle> allVehicleList) throws ParseException {
		if (allVehicleList != null && allVehicleList.size() > 0) {
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
			Date fromDate = sdf1.parse(DicvUtil.getPreviousStartOfDay(new Date()));
			Date toDate = sdf1.parse(DicvUtil.getPreviousEndOfDay(new Date()));
			processVehicle(allVehicleList, fromDate, toDate);
		}
	}

	@Async
	public void runUtilizationProcess(Long vehicleId, Date from, Date to) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			List<Vehicle> allVehicleList = null;
			if (vehicleId == null || vehicleId == 0) {
				allVehicleList = vehicleRepo.getAllVehicle();
			} else {
				Vehicle veh = vehicleRepo.getVehicle(vehicleId);
				allVehicleList = new ArrayList<Vehicle>();
				allVehicleList.add(veh);
			}
			if (allVehicleList != null && allVehicleList.size() > 0) {
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
				Date fromDate = sdf1.parse(DicvUtil.getStartTimeOfDate(from));
				Date toDate = sdf1.parse(DicvUtil.getEndTimeOfDate(to));
				processVehicle(allVehicleList, fromDate, toDate);
			}
			watch.stop();
			LOGGER.info("Completed Utilization Processing for Vehicle " + vehicleId);
		} catch (Exception ex) {
			LOGGER.error("Exception in Vehicle Utilization " + ex);
		}
	}

	private void processVehicle(List<Vehicle> allVehicleList, Date fromDate, Date toDate) {
		for (Vehicle veh : allVehicleList) {
			try {
				processUtilization(fromDate, toDate, veh);
			} catch (Exception ex) {
				LOGGER.error("Exception in Vehicle Utilization  " + ex);
				continue;
			}
		}
	}

	@Transactional
	private void processUtilization(Date reportFromDate, Date reportToDate, Vehicle veh) {
		try {

			Double vehicleDistance = 0d;
			Double vehicleInvalidSpeed = 0d;
			Double vehicleDistanceSum = 0d;
			Long engineOnTime = 0l;
			Long engineRunTime = 0l;
			Long timeIn_9_10 = 0l;
			Long timeIn_10_11 = 0l;
			Long timeIn_11_12 = 0l;
			Long timeIn_12_1 = 0l;
			Long timeIn_1_2 = 0l;
			Long timeIn_2_3 = 0l;
			Long timeIn_3_4 = 0l;
			Long timeIn_4_5 = 0l;
			Long timeIn_5_6 = 0l;
			Double distIn_9_10 = 0d;
			Double distIn_10_11 = 0d;
			Double distIn_11_12 = 0d;
			Double distIn_12_1 = 0d;
			Double distIn_1_2 = 0d;
			Double distIn_2_3 = 0d;
			Double distIn_3_4 = 0d;
			Double distIn_4_5 = 0d;
			Double distIn_5_6 = 0d;
			int hours = 0;
			for (int dateLoop = 1; dateLoop <= 2; dateLoop++) {
				Date gpsParamTime = null;
				if (veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null) {
					Long gpsImei = veh.getGpsImei().getGpsImei().longValue();

					Date fromDate = new Date();
					Date toDate = new Date();
					if (dateLoop == 1) {
						fromDate = DicvUtil.getTime12_06Start(reportFromDate);
						toDate = DicvUtil.getTime12_06End(reportFromDate);
					} else if (dateLoop == 2) {
						fromDate = DicvUtil.getTime09_12Start(reportFromDate);
						toDate = DicvUtil.getTime09_12End(reportFromDate);
					}

					Long totalCount = gpsVehicleRepo.countofGpsParamDataforUtilization(gpsImei, fromDate, toDate);
					if (totalCount > 0) {

						Integer iterCount = totalCount.intValue() <= 1000 ? 0 : totalCount.intValue() / 1000;
						if ((totalCount.intValue() % 1000) > 0)
							iterCount = iterCount + 1;
						for (int i = 1; i <= iterCount; i++) {

							List<GpsVehParameterDto> gpsParamData = (gpsParamTime == null)
									? gpsVehicleRepo.collectGpsParamDataforUtilization(
											veh.getGpsImei().getGpsImei().longValue(), fromDate, toDate,
											new PageRequest(0, 1000))
									: gpsVehicleRepo.collectGpsParamDataforUtilization(
											veh.getGpsImei().getGpsImei().longValue(), fromDate, toDate, gpsParamTime,
											new PageRequest(0, 1000));
							if (gpsParamData != null && gpsParamData.size() > 1) {

								Integer totalRecords = gpsParamData.size();
								Integer gpsRecordCount = 0;
								for (GpsVehParameterDto gpsVehicleParam : gpsParamData) {

									gpsRecordCount = gpsRecordCount + 1;
									gpsParamTime = new Date(gpsVehicleParam.getGpsTime().getTime());
									if (gpsRecordCount >= totalRecords) {
										break;
									}
									GpsVehParameterDto gpsVehicleParamNext = gpsParamData.get(gpsRecordCount);
									if (!checkGpsNullValue(gpsVehicleParam, gpsVehicleParamNext))
										continue;
									Long vehicleDiffInSeconds = (gpsVehicleParamNext.getGpsTime().getTime()
											- gpsVehicleParam.getGpsTime().getTime()) / 1000;
									if (vehicleDiffInSeconds < 0)
										continue;
									vehicleDistance = DistanceCalculation.distance(gpsVehicleParam.getGpsLatitude(),
											gpsVehicleParam.getGpsLongitude(), gpsVehicleParamNext.getGpsLatitude(),
											gpsVehicleParamNext.getGpsLongitude());
									vehicleInvalidSpeed = 0d;
									if (vehicleDistance > 0 && vehicleDiffInSeconds > 0) {
										vehicleInvalidSpeed = ((vehicleDistance / vehicleDiffInSeconds) * 3600);
									}
									if (vehicleInvalidSpeed > 9999 || vehicleDiffInSeconds > 900) {
										continue;
									}
									// Total Distance
									vehicleDistanceSum = (checkNullValue(vehicleDistanceSum, vehicleDistance));
									vehicleDistanceSum = roundOffDecimal(vehicleDistanceSum);
									// Engine On Time
									if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParamNext.getEngineON() == 1) {
										engineOnTime = engineOnTime + vehicleDiffInSeconds;
										// Engine Run Time
										if (gpsVehicleParam.getGpsSpkm() > 0 && gpsVehicleParamNext.getGpsSpkm() > 0) {
											engineRunTime = engineRunTime + vehicleDiffInSeconds;
											Calendar calendar = Calendar.getInstance();
											calendar.setTime(gpsParamTime);
											hours = calendar.get(Calendar.HOUR_OF_DAY);

											// Speed Report

											switch (hours) {
											case 0:
												timeIn_12_1 = timeIn_12_1 + vehicleDiffInSeconds;
												distIn_12_1 = distIn_12_1 + vehicleDistance;
												distIn_12_1 = roundOffDecimal(distIn_12_1);
												break;
											case 1:
												timeIn_1_2 = timeIn_1_2 + vehicleDiffInSeconds;
												distIn_1_2 = distIn_1_2 + vehicleDistance;
												distIn_1_2 = roundOffDecimal(distIn_1_2);
												break;
											case 2:
												timeIn_2_3 = timeIn_2_3 + vehicleDiffInSeconds;
												distIn_2_3 = distIn_2_3 + vehicleDistance;
												distIn_2_3 = roundOffDecimal(distIn_2_3);
												break;
											case 3:
												timeIn_3_4 = timeIn_3_4 + vehicleDiffInSeconds;
												distIn_3_4 = distIn_3_4 + vehicleDistance;
												distIn_3_4 = roundOffDecimal(distIn_3_4);
												break;
											case 4:
												timeIn_4_5 = timeIn_4_5 + vehicleDiffInSeconds;
												distIn_4_5 = distIn_4_5 + vehicleDistance;
												distIn_4_5 = roundOffDecimal(distIn_4_5);
												break;
											case 5:
												timeIn_5_6 = timeIn_5_6 + vehicleDiffInSeconds;
												distIn_5_6 = distIn_5_6 + vehicleDistance;
												distIn_5_6 = roundOffDecimal(distIn_5_6);
												break;

											case 21:
												timeIn_9_10 = timeIn_9_10 + vehicleDiffInSeconds;
												distIn_9_10 = distIn_9_10 + vehicleDistance;
												distIn_9_10 = roundOffDecimal(distIn_9_10);
												break;
											case 22:
												timeIn_10_11 = timeIn_10_11 + vehicleDiffInSeconds;
												distIn_10_11 = distIn_10_11 + vehicleDistance;
												distIn_10_11 = roundOffDecimal(distIn_10_11);
												break;
											case 23:
												timeIn_11_12 = timeIn_11_12 + vehicleDiffInSeconds;
												distIn_11_12 = distIn_11_12 + vehicleDistance;
												distIn_11_12 = roundOffDecimal(distIn_11_12);
												break;
											}

										}
									}
								} // Gps For Loop Ending

							}
						}
					}

					saveNightDriving(veh.getVehicleId(), reportFromDate, timeIn_9_10, timeIn_10_11, timeIn_11_12,
							timeIn_12_1, timeIn_1_2, timeIn_2_3, timeIn_3_4, timeIn_4_5, timeIn_5_6, distIn_9_10,
							distIn_10_11, distIn_11_12, distIn_12_1, distIn_1_2, distIn_2_3, distIn_3_4, distIn_4_5,
							distIn_5_6);
				}

			}
		} catch (Exception ex) {
			LOGGER.error("Exception while processing Night Driving Vehicle :: " + veh.getRegistrationId(), ex);
			return;
		}
	}

	private void saveNightDriving(Long vehicleId, Date reportFromDate, Long timeIn_9_10, Long timeIn_10_11,
			Long timeIn_11_12, Long timeIn_12_1, Long timeIn_1_2, Long timeIn_2_3, Long timeIn_3_4, Long timeIn_4_5,
			Long timeIn_5_6, Double distIn_9_10, Double distIn_10_11, Double distIn_11_12, Double distIn_12_1,
			Double distIn_1_2, Double distIn_2_3, Double distIn_3_4, Double distIn_4_5, Double distIn_5_6) {
		NightDriving nigtDriving = nightDrivingRepo.getNightDriving(vehicleId, reportFromDate);
		if (nigtDriving == null) {
			nigtDriving = new NightDriving();
			nigtDriving.setVehicleId(vehicleId);
		}
		nigtDriving.setDistIn_10_11(distIn_10_11);
		nigtDriving.setDistIn_11_12(distIn_11_12);
		nigtDriving.setDistIn_12_1(distIn_12_1);
		nigtDriving.setDistIn_1_2(distIn_1_2);
		nigtDriving.setDistIn_2_3(distIn_2_3);
		nigtDriving.setDistIn_3_4(distIn_3_4);
		nigtDriving.setDistIn_4_5(distIn_4_5);
		nigtDriving.setDistIn_5_6(distIn_5_6);
		nigtDriving.setDistIn_5_6(distIn_5_6);
		nigtDriving.setDistIn_9_10(distIn_9_10);
		nigtDriving.setReportDate(reportFromDate);
		nigtDriving.setTimeIn_9_10(timeIn_9_10);
		nigtDriving.setTimeIn_5_6(timeIn_5_6);
		nigtDriving.setTimeIn_4_5(timeIn_4_5);
		nigtDriving.setTimeIn_3_4(timeIn_3_4);
		nigtDriving.setTimeIn_2_3(timeIn_2_3);
		nigtDriving.setTimeIn_1_2(timeIn_1_2);
		nigtDriving.setTimeIn_12_1(timeIn_12_1);
		nigtDriving.setTimeIn_11_12(timeIn_11_12);
		nigtDriving.setTimeIn_10_11(timeIn_10_11);
		nigtDriving.setUpdatedTime(DicvUtil.getTimestamp());
		nightDrivingRepo.save(nigtDriving);
	}

	private boolean checkGpsNullValue(GpsVehParameterDto gpsVehicleParam, GpsVehParameterDto gpsVehicleParamNext) {
		if (gpsVehicleParam.getGpsLatitude() == null || gpsVehicleParam.getGpsLongitude() == null
				|| gpsVehicleParam.getGpsSpkm() == null || gpsVehicleParam.getGpsTime() == null
				|| gpsVehicleParam.getEngineON() == null || gpsVehicleParamNext.getGpsLatitude() == null
				|| gpsVehicleParamNext.getGpsLongitude() == null || gpsVehicleParamNext.getGpsSpkm() == null
				|| gpsVehicleParamNext.getGpsTime() == null || gpsVehicleParamNext.getEngineON() == null) {
			return false;
		}
		return true;
	}

	private Double roundOffDecimal(Double driverScore) {
		if (driverScore > 0)
			driverScore = Math.round(driverScore * 100D) / 100D;
		return driverScore;
	}

	private Double checkNullValue(Double value1, Double value2) {
		value1 = value1 == null ? 0d : value1;
		value2 = value2 == null ? 0d : value2;
		return value1 + value2;
	}

	private void sendEmail(String subject, String msg) {
		sendMailService.sendMail("paras.dicv@gmail.com", "harikrishnan.d@contus.in", subject,
				msg + " For  " + new Date());
	}

}
