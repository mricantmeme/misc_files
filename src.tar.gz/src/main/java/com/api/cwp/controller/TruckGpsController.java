package com.api.cwp.controller;

public class TruckGpsController {

}
