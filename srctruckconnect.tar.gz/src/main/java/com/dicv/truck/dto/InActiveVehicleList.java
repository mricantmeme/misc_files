package com.dicv.truck.dto;

import java.util.List;

public class InActiveVehicleList {
	
	
	private List<InActiveVehicleDto> inActiveVehicleList;

	public List<InActiveVehicleDto> getInActiveVehicleList() {
		return inActiveVehicleList;
	}

	public void setInActiveVehicleList(List<InActiveVehicleDto> inActiveVehicleList) {
		this.inActiveVehicleList = inActiveVehicleList;
	}

}
