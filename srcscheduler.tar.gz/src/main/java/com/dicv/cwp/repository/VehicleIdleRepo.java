package com.dicv.cwp.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.VehicleIdleAlert;

@Repository
public interface VehicleIdleRepo extends JpaRepository<VehicleIdleAlert, Long> {

	@Query("Select v from VehicleIdleAlert v where v.vehicleId=:vehicleId and v.idleStopTime IS NULL order by v.vehicleIdleId desc")
	public List<VehicleIdleAlert> getVehicleIdle(@Param(value = "vehicleId") Long vehicleId, Pageable pageable);

}
