package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.BatteryDisconnect;
import com.dicv.cwp.dao.model.BatteryDisconnectProcess;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.BatteryDisconnectProcessRepo;
import com.dicv.cwp.repository.BatteryDisconnectRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class BatteryDisconnectService {

	@Autowired
	private BatteryDisconnectProcessRepo batteryDiscProcessRepo;

	@Autowired
	private GpsParamService gpsParamService;

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private GoogleAPIService addressUtil;

	@Autowired
	private BatteryDisconnectRepo batteryDiscRepo;

	@Value("${battery_disconnect}")
	private String batteryConnect;

	private static final Logger LOGGER = Logger.getLogger(BatteryDisconnectService.class);

	@Scheduled(fixedDelay = 60000, initialDelay = 60000)
	public void schedulerProcess() {
		try {
			if (batteryConnect != null && batteryConnect.equals("Yes")) {
				LOGGER.info("Battery Disconnect  Started");
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				startVehicleBatteryDisconnect();
				stopWatch.stop();
				LOGGER.info(
						"Battery Disconnect Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
			}
		} catch (Exception ex) {
			LOGGER.error("Main Battery Disconnect " + ex);
		}

	}

	@Transactional
	public void startVehicleBatteryDisconnect() {
		List<VehicleListDto> allVehicleList = vehicleService.getVehicleNoAndIMEI();
		if (allVehicleList != null && allVehicleList.size() > 0) {
			for (VehicleListDto veh : allVehicleList) {
				try {
					processVehicleBattery(veh);
				} catch (Exception ex) {
					LOGGER.error("Exception Battery Disconnect Vehicle :: " + veh.getRegistrationId(), ex);
					continue;
				}
			}
		}
	}

	public void processVehicleBattery(VehicleListDto veh) {
		try {
			if (veh.getGpsImei() != null) {
				BatteryDisconnectProcess batteryProcess = batteryDiscProcessRepo
						.getBatteryDisconnectProcess(veh.getVehicleId());
				if (batteryProcess == null) {
					batteryProcess = addToBatteryProcess(veh);
				} else if (batteryProcess.getMainBatteryDetected() == null) {
					batteryProcess.setMainBatteryDetected(DicvUtil.getCurrentTimeStamp());
					updateBatteryDiscProcessTime(batteryProcess);
				} else {
					checkForBatteryDisconnect(veh, batteryProcess);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId(), ex);
		}
	}

	private void checkForBatteryDisconnect(VehicleListDto veh, BatteryDisconnectProcess batteryProcess) {
		try {
			Timestamp nextPollingTime = new Timestamp(batteryProcess.getMainBatteryDetected().getTime() + 300000);

			GpsVehParameterDto gpsParamData = gpsParamService.getBatteryDisconnect(veh.getGpsImei(), nextPollingTime);
			if (gpsParamData != null) {
				batteryProcess.setMainBatteryDetected(DicvUtil.getTimeStampFromDate(gpsParamData.getGpsTime()));
				updateBatteryDiscProcessTime(batteryProcess);
				addBatteryDisconnect(veh, gpsParamData);
			} else {
				updateMaximumGpsDataTimestamp(veh, batteryProcess);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while Main Battery Disconnect processing Vehicle :: " + veh.getRegistrationId(),
					ex);
		}
	}

	private void addBatteryDisconnect(VehicleListDto veh, GpsVehParameterDto gpsParamData) {
		BatteryDisconnect batteryDisconnect = new BatteryDisconnect();
		batteryDisconnect.setCreatedAt(DicvUtil.getCurrentTimeStamp());
		batteryDisconnect.setEmailSent(0);
		batteryDisconnect.setGpsTime(DicvUtil.getTimeStampFromDate(gpsParamData.getGpsTime()));
		batteryDisconnect.setLatitude(gpsParamData.getGpsLatitude());
		Address address = addressUtil.getAddress(gpsParamData.getGpsLatitude(), gpsParamData.getGpsLongitude());
		if (address.getResponse()) {
			batteryDisconnect.setLocation(address.getAddress());
			batteryDisconnect.setGeoResponse(2);
		} else {
			batteryDisconnect.setGeoResponse(0);
		}
		batteryDisconnect.setLongitude(gpsParamData.getGpsLongitude());
		batteryDisconnect.setVehicleId(veh.getVehicleId());
		batteryDiscRepo.save(batteryDisconnect);
	}

	private void updateMaximumGpsDataTimestamp(VehicleListDto veh, BatteryDisconnectProcess batteryProcess) {
		GpsParameterDto gpsVehParamDto = gpsParamService.getMaxofGpsParameterForAlert(veh.getGpsImei());
		if (gpsVehParamDto != null) {
			batteryProcess.setProcessTime(DicvUtil.getTimeStampFromDate(gpsVehParamDto.getGpsTime()));
			updateBatteryDiscProcessTime(batteryProcess);
		}
	}

	private void updateBatteryDiscProcessTime(BatteryDisconnectProcess batteryProcess) {
		batteryProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		batteryDiscProcessRepo.save(batteryProcess);
	}

	private BatteryDisconnectProcess addToBatteryProcess(VehicleListDto veh) {
		BatteryDisconnectProcess batteryProcess = new BatteryDisconnectProcess();
		batteryProcess.setProcessTime(DicvUtil.getCurrentTimeStamp());
		batteryProcess.setUpdatedAt(DicvUtil.getCurrentTimeStamp());
		batteryProcess.setVehicleId(veh.getVehicleId());
		batteryProcess.setMainBatteryDetected(DicvUtil.getCurrentTimeStamp());
		batteryDiscProcessRepo.save(batteryProcess);
		return batteryProcess;
	}

}
