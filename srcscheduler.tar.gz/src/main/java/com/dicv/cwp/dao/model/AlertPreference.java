package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ALERT_PREFERENCE")
public class AlertPreference {

	@Id
	@SequenceGenerator(name = "ALERT_PREFERENCE_ALERTID_GENERATOR", sequenceName = "ALERT_PREFERENCE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ALERT_PREFERENCE_ALERTID_GENERATOR")
	@Column(name = "ALERT_ID")
	private Integer alertId;

	@Column(name = "DELIVERY_EMAIL_ALERT")
	private Integer deliveryEmailAlert;

	@Column(name = "DELIVERY_SMS_ALERT")
	private Integer deliverySmsAlert;

	@Column(name = "DELIVERY_WEB_ALERT")
	private Integer deliveryWebAlert;

	@Column(name = "GEOFENCE_IN_EMAIL_ALERT")
	private Integer geofenceInEmailAlert;

	@Column(name = "GEOFENCE_IN_SMS_ALERT")
	private Integer geofenceInSmsAlert;

	@Column(name = "GEOFENCE_IN_WEB_ALERT")
	private Integer geofenceInWebAlert;

	@Column(name = "GEOFENCE_OUT_EMAIL_ALERT")
	private Integer geofenceOutEmailAlert;

	@Column(name = "GEOFENCE_OUT_SMS_ALERT")
	private Integer geofenceOutSmsAlert;

	@Column(name = "GEOFENCE_OUT_WEB_ALERT")
	private Integer geofenceOutWebAlert;

	@Column(name = "LOW_BATTERY_EMAIL_ALERT")
	private Integer lowBatteryEmailAlert;

	@Column(name = "LOW_BATTERY_SMS_ALERT")
	private Integer lowBatterySmsAlert;

	@Column(name = "LOW_BATTERY_WEB_ALERT")
	private Integer lowBatteryWebAlert;

	@Column(name = "OVER_SPEED_EMAIL_ALERT")
	private Integer overSpeedEmailAlert;

	@Column(name = "OVER_SPEED_SMS_ALERT")
	private Integer overSpeedSmsAlert;

	@Column(name = "OVER_SPEED_WEB_ALERT")
	private Integer overSpeedWebAlert;

	@Column(name = "PICKUP_EMAIL_ALERT")
	private Integer pickupEmailAlert;

	@Column(name = "PICKUP_SMS_ALERT")
	private Integer pickupSmsAlert;

	@Column(name = "PICKUP_WEB_ALERT")
	private Integer pickupWebAlert;

	@Column(name = "TRIP_START_EMAIL_ALERT")
	private Integer tripStartEmailAlert;

	@Column(name = "TRIP_START_SMS_ALERT")
	private Integer tripStartSmsAlert;

	@Column(name = "TRIP_START_WEB_ALERT")
	private Integer tripStartWebAlert;

	@Column(name = "TRIP_STOP_EMAIL_ALERT")
	private Integer tripStopEmailAlert;

	@Column(name = "TRIP_STOP_SMS_ALERT")
	private Integer tripStopSmsAlert;

	@Column(name = "TRIP_STOP_WEB_ALERT")
	private Integer tripStopWebAlert;

	@Column(name = "MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name = "CREATED_DATE")
	private Timestamp createdDate;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	// bi-directional many-to-one association to DicvUser
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_ID")
	private DicvUser dicvUser;

	public AlertPreference() {
	}

	public Integer getAlertId() {
		return this.alertId;
	}

	public void setDeliveryEmailAlert(Integer deliveryEmailAlert) {
		this.deliveryEmailAlert = deliveryEmailAlert;
	}

	public void setDeliverySmsAlert(Integer deliverySmsAlert) {
		this.deliverySmsAlert = deliverySmsAlert;
	}

	public void setDeliveryWebAlert(Integer deliveryWebAlert) {
		this.deliveryWebAlert = deliveryWebAlert;
	}

	public void setGeofenceInEmailAlert(Integer geofenceInEmailAlert) {
		this.geofenceInEmailAlert = geofenceInEmailAlert;
	}

	public void setGeofenceInSmsAlert(Integer geofenceInSmsAlert) {
		this.geofenceInSmsAlert = geofenceInSmsAlert;
	}

	public void setGeofenceInWebAlert(Integer geofenceInWebAlert) {
		this.geofenceInWebAlert = geofenceInWebAlert;
	}

	public void setGeofenceOutEmailAlert(Integer geofenceOutEmailAlert) {
		this.geofenceOutEmailAlert = geofenceOutEmailAlert;
	}

	public void setGeofenceOutSmsAlert(Integer geofenceOutSmsAlert) {
		this.geofenceOutSmsAlert = geofenceOutSmsAlert;
	}

	public void setGeofenceOutWebAlert(Integer geofenceOutWebAlert) {
		this.geofenceOutWebAlert = geofenceOutWebAlert;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public void setLowBatteryEmailAlert(Integer lowBatteryEmailAlert) {
		this.lowBatteryEmailAlert = lowBatteryEmailAlert;
	}

	public void setLowBatterySmsAlert(Integer lowBatterySmsAlert) {
		this.lowBatterySmsAlert = lowBatterySmsAlert;
	}

	public void setLowBatteryWebAlert(Integer lowBatteryWebAlert) {
		this.lowBatteryWebAlert = lowBatteryWebAlert;
	}

	public void setOverSpeedEmailAlert(Integer overSpeedEmailAlert) {
		this.overSpeedEmailAlert = overSpeedEmailAlert;
	}

	public void setOverSpeedSmsAlert(Integer overSpeedSmsAlert) {
		this.overSpeedSmsAlert = overSpeedSmsAlert;
	}

	public void setOverSpeedWebAlert(Integer overSpeedWebAlert) {
		this.overSpeedWebAlert = overSpeedWebAlert;
	}

	public void setPickupEmailAlert(Integer pickupEmailAlert) {
		this.pickupEmailAlert = pickupEmailAlert;
	}

	public void setPickupSmsAlert(Integer pickupSmsAlert) {
		this.pickupSmsAlert = pickupSmsAlert;
	}

	public void setPickupWebAlert(Integer pickupWebAlert) {
		this.pickupWebAlert = pickupWebAlert;
	}

	public void setTripStartEmailAlert(Integer tripStartEmailAlert) {
		this.tripStartEmailAlert = tripStartEmailAlert;
	}

	public void setTripStartSmsAlert(Integer tripStartSmsAlert) {
		this.tripStartSmsAlert = tripStartSmsAlert;
	}

	public void setTripStartWebAlert(Integer tripStartWebAlert) {
		this.tripStartWebAlert = tripStartWebAlert;
	}

	public void setTripStopEmailAlert(Integer tripStopEmailAlert) {
		this.tripStopEmailAlert = tripStopEmailAlert;
	}

	public void setTripStopSmsAlert(Integer tripStopSmsAlert) {
		this.tripStopSmsAlert = tripStopSmsAlert;
	}

	public void setTripStopWebAlert(Integer tripStopWebAlert) {
		this.tripStopWebAlert = tripStopWebAlert;
	}

	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getDeliveryEmailAlert() {
		return deliveryEmailAlert;
	}

	public Integer getDeliverySmsAlert() {
		return deliverySmsAlert;
	}

	public Integer getDeliveryWebAlert() {
		return deliveryWebAlert;
	}

	public Integer getGeofenceInEmailAlert() {
		return geofenceInEmailAlert;
	}

	public Integer getGeofenceInSmsAlert() {
		return geofenceInSmsAlert;
	}

	public Integer getGeofenceInWebAlert() {
		return geofenceInWebAlert;
	}

	public Integer getGeofenceOutEmailAlert() {
		return geofenceOutEmailAlert;
	}

	public Integer getGeofenceOutSmsAlert() {
		return geofenceOutSmsAlert;
	}

	public Integer getGeofenceOutWebAlert() {
		return geofenceOutWebAlert;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public Integer getLowBatteryEmailAlert() {
		return lowBatteryEmailAlert;
	}

	public Integer getLowBatterySmsAlert() {
		return lowBatterySmsAlert;
	}

	public Integer getLowBatteryWebAlert() {
		return lowBatteryWebAlert;
	}

	public Integer getOverSpeedEmailAlert() {
		return overSpeedEmailAlert;
	}

	public Integer getOverSpeedSmsAlert() {
		return overSpeedSmsAlert;
	}

	public Integer getOverSpeedWebAlert() {
		return overSpeedWebAlert;
	}

	public Integer getPickupEmailAlert() {
		return pickupEmailAlert;
	}

	public Integer getPickupSmsAlert() {
		return pickupSmsAlert;
	}

	public Integer getPickupWebAlert() {
		return pickupWebAlert;
	}

	public Integer getTripStartEmailAlert() {
		return tripStartEmailAlert;
	}

	public Integer getTripStartSmsAlert() {
		return tripStartSmsAlert;
	}

	public Integer getTripStartWebAlert() {
		return tripStartWebAlert;
	}

	public Integer getTripStopEmailAlert() {
		return tripStopEmailAlert;
	}

	public Integer getTripStopSmsAlert() {
		return tripStopSmsAlert;
	}

	public Integer getTripStopWebAlert() {
		return tripStopWebAlert;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public DicvUser getDicvUser() {
		return dicvUser;
	}

	public void setDicvUser(DicvUser dicvUser) {
		this.dicvUser = dicvUser;
	}


}
