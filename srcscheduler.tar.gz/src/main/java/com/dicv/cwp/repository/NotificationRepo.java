package com.dicv.cwp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.Notification;

@Repository
public interface NotificationRepo extends CrudRepository<Notification, Integer> {

}
