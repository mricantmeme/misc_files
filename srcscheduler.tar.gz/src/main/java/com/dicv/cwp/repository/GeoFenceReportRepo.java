package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.GeoFenceReport;

@Repository
public interface GeoFenceReportRepo extends CrudRepository<GeoFenceReport, Long> {

	@Query("Select v FROM GeoFenceReport v where v.vehicleId=:vehicleId and v."
			+ "geoFenceId=:geoFenceId and v.userId=:userId and v.geoFenceExitTime is NULL order by v.geoFenceReportId desc")
	public List<GeoFenceReport> getGeoFenceReport(@Param("vehicleId") Long vehicleId, @Param("userId") Integer userId,
			@Param("geoFenceId") Integer geoFenceId, Pageable pageable);

	@Query("Select v FROM GeoFenceReport v where v.geoFenceEntryTime is NOT NULL and v.geoFenceExitTime is NOT NULL and v.time_spent IS  NULL")
	public List<GeoFenceReport> getGeoFenceReport();

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update GeoFenceReport v set v.geoFenceExitTime =:geoFenceExitTime  where v.vehicleId=:vehicleId and v.vehicleEntry=1 and v."
			+ "geoFenceId=:geoFenceId and v.userId=:userId and v.geoFenceExitTime is NULL")
	public void updateGeoFenceReport(@Param("vehicleId") Long vehicleId, @Param("userId") Integer userId,
			@Param("geoFenceId") Integer geoFenceId, @Param("geoFenceExitTime") Timestamp geoFenceExitTime);

}
