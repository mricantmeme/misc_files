package com.dicv.cwp.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the DICV_GROUPS database table.
 * 
 */
@Entity
@Table(name = "DICV_GROUPS")
public class DicvGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DICV_GROUPS_GROUPID_GENERATOR", sequenceName = "DICV_GROUPS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DICV_GROUPS_GROUPID_GENERATOR")
	@Column(name = "GROUP_ID")
	private Integer groupId;

	@Column(name = "GROUP_NAME")
	private String groupName;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

}