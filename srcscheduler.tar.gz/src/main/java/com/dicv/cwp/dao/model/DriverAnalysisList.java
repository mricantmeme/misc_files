package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "DRIVER_ANALYSIS_LIST")
public class DriverAnalysisList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DRIVER_ANALYSIS_LIST_GENERATOR", sequenceName = "DRIVER_ANALYSIS_LIST_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DRIVER_ANALYSIS_LIST_GENERATOR")
	@Column(name = "DRIVER_ANALYSIS_ID")
	private Long driverAnalysisId;

	@Column(name = "AVERAGE_VEHICLE_SPEED")
	private Double averageVehicleSpeed;

	@Column(name = "DRIVER_SCORE")
	private Double driverScore;

	@Column(name = "ECONOMIC_BAND")
	private Double economicBand;

	@Column(name = "FUEL_EFFICIENCY")
	private Integer fuelEfficiency;

	@Column(name = "GREEN_BAND_DISTANCE")
	private Double greenBandDistance;

	@Column(name = "ENGINE_IDLE_TIME_PERCENT")
	private Double engineIdleTimePercent;

	@Column(name = "MAX_SPEED_LAT")
	private Double maxSpeedLat;

	@Column(name = "MAX_SPEED_LONG")
	private Double maxSpeedLong;

	@Column(name = "MAX_SPEED_TIME")
	private Timestamp maxSpeedTime;

	@Column(name = "MAXIMUM_SPEED")
	private Double maximumSpeed;

	@Column(name = "ENGINE_NON_IDLE_TIME_PERCENT")
	private Double engineNonIdleTimePercent;

	@Column(name = "RECORD_TIMESTAMP")
	private Timestamp recordTimestamp;

	@Temporal(TemporalType.DATE)
	@Column(name = "REPORT_DATE")
	private Date reportDate;

	@Column(name = "SPEED_ADHERENCE")
	private Double speedAdherence;

	@Column(name = "SPEED_VIOLATION")
	private Double speedViolation;

	@Column(name = "SPEED_VIOLATION_TIME")
	private Long speedViolationTime;

	@Column(name = "SPEEDBAND_0_TO_20KM")
	private Long speedband0To20km;

	@Column(name = "SPEEDBAND_21_TO_40KM")
	private Long speedband21To40km;

	@Column(name = "SPEEDBAND_41_TO_60KM")
	private Long speedband41To60km;

	@Column(name = "SPEEDBAND_OVER_80KM")
	private Long speedbandOver80km;

	@Column(name = "SPEEDBAND_TO_80KM")
	private Long speedbandTo80km;

	@Column(name = "STAR_COUNT")
	private Double starCount;

	@Column(name = "TOTAL_DRIVE_TIME")
	private Long totalDriveTime;

	@Column(name = "TRIP_DISTANCE")
	private Double tripDistance;

	@Column(name = "GREEN_BAND_TIME")
	private Long greenBandTime;

	@Column(name = "YELLOW_BAND_TIME")
	private Long yellowBandTime;

	@Column(name = "RED_BAND_TIME")
	private Long redBandTime;

	@Column(name = "ENGINE_RUN_TIME")
	private Long engineRunTime;

	@Column(name = "ENGINE_IDLE_TIME")
	private Long engineIdleTime;

	@Column(name = "LAST_UPD_TS")
	private Timestamp lastUpdTs;

	@Column(name = "ECONOMY_BAND_DISTANCE")
	private Double economyBandDistance;

	@Column(name = "ECONOMIC_DRIVING")
	private Double economyDriving;

	@Column(name = "DRIVER_ID")
	private Integer driverId;

	@Column(name = "ECONOMY_BAND_TIME")
	private Long economicBandTime;

	@Column(name = "GROUP_ID")
	private Integer groupId;

	@Column(name = "OWNER_ID")
	private Integer ownerId;

	@Column(name = "IS_CAN_PARAMETER")
	private Integer isCanParameter;

	@Column(name = "HARSH_ACCELERATION")
	private Integer harshAcceleration;

	@Column(name = "HARSH_CORNERING")
	private Integer harshCornering;

	@Column(name = "HARSH_BRAKING")
	private Integer harshBraking;

	@Column(name = "SPEEDING_COUNT")
	private Integer speedingCount;

	public Double getAverageVehicleSpeed() {
		return averageVehicleSpeed;
	}

	public void setAverageVehicleSpeed(Double averageVehicleSpeed) {
		this.averageVehicleSpeed = averageVehicleSpeed;
	}

	public Double getDriverScore() {
		return driverScore;
	}

	public void setDriverScore(Double driverScore) {
		this.driverScore = driverScore;
	}

	public Double getEconomicBand() {
		return economicBand;
	}

	public void setEconomicBand(Double economicBand) {
		this.economicBand = economicBand;
	}

	public Integer getFuelEfficiency() {
		return fuelEfficiency;
	}

	public void setFuelEfficiency(Integer fuelEfficiency) {
		this.fuelEfficiency = fuelEfficiency;
	}

	public Double getGreenBandDistance() {
		return greenBandDistance;
	}

	public void setGreenBandDistance(Double greenBandDistance) {
		this.greenBandDistance = greenBandDistance;
	}

	public Double getMaxSpeedLat() {
		return maxSpeedLat;
	}

	public void setMaxSpeedLat(Double maxSpeedLat) {
		this.maxSpeedLat = maxSpeedLat;
	}

	public Double getMaxSpeedLong() {
		return maxSpeedLong;
	}

	public void setMaxSpeedLong(Double maxSpeedLong) {
		this.maxSpeedLong = maxSpeedLong;
	}

	public Timestamp getMaxSpeedTime() {
		return maxSpeedTime;
	}

	public void setMaxSpeedTime(Timestamp maxSpeedTime) {
		this.maxSpeedTime = maxSpeedTime;
	}

	public Double getEngineNonIdleTimePercent() {
		return engineNonIdleTimePercent;
	}

	public void setEngineNonIdleTimePercent(Double engineNonIdleTimePercent) {
		this.engineNonIdleTimePercent = engineNonIdleTimePercent;
	}

	public Timestamp getRecordTimestamp() {
		return recordTimestamp;
	}

	public void setRecordTimestamp(Timestamp recordTimestamp) {
		this.recordTimestamp = recordTimestamp;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public Double getSpeedAdherence() {
		return speedAdherence;
	}

	public void setSpeedAdherence(Double speedAdherence) {
		this.speedAdherence = speedAdherence;
	}

	public Double getSpeedViolation() {
		return speedViolation;
	}

	public void setSpeedViolation(Double speedViolation) {
		this.speedViolation = speedViolation;
	}

	public Long getSpeedViolationTime() {
		return speedViolationTime;
	}

	public void setSpeedViolationTime(Long speedViolationTime) {
		this.speedViolationTime = speedViolationTime;
	}

	public Long getSpeedband0To20km() {
		return speedband0To20km;
	}

	public void setSpeedband0To20km(Long speedband0To20km) {
		this.speedband0To20km = speedband0To20km;
	}

	public Long getSpeedband21To40km() {
		return speedband21To40km;
	}

	public void setSpeedband21To40km(Long speedband21To40km) {
		this.speedband21To40km = speedband21To40km;
	}

	public Long getSpeedband41To60km() {
		return speedband41To60km;
	}

	public void setSpeedband41To60km(Long speedband41To60km) {
		this.speedband41To60km = speedband41To60km;
	}

	public Long getSpeedbandOver80km() {
		return speedbandOver80km;
	}

	public void setSpeedbandOver80km(Long speedbandOver80km) {
		this.speedbandOver80km = speedbandOver80km;
	}

	public Long getSpeedbandTo80km() {
		return speedbandTo80km;
	}

	public void setSpeedbandTo80km(Long speedbandTo80km) {
		this.speedbandTo80km = speedbandTo80km;
	}

	public Double getStarCount() {
		return starCount;
	}

	public void setStarCount(Double starCount) {
		this.starCount = starCount;
	}

	public Long getTotalDriveTime() {
		return totalDriveTime;
	}

	public void setTotalDriveTime(Long totalDriveTime) {
		this.totalDriveTime = totalDriveTime;
	}

	public Double getTripDistance() {
		return tripDistance;
	}

	public void setTripDistance(Double tripDistance) {
		this.tripDistance = tripDistance;
	}

	public Long getGreenBandTime() {
		return greenBandTime;
	}

	public void setGreenBandTime(Long greenBandTime) {
		this.greenBandTime = greenBandTime;
	}

	public Long getYellowBandTime() {
		return yellowBandTime;
	}

	public void setYellowBandTime(Long yellowBandTime) {
		this.yellowBandTime = yellowBandTime;
	}

	public Long getRedBandTime() {
		return redBandTime;
	}

	public void setRedBandTime(Long redBandTime) {
		this.redBandTime = redBandTime;
	}

	public Long getEngineRunTime() {
		return engineRunTime;
	}

	public void setEngineRunTime(Long engineRunTime) {
		this.engineRunTime = engineRunTime;
	}

	public Long getEngineIdleTime() {
		return engineIdleTime;
	}

	public void setEngineIdleTime(Long engineIdleTime) {
		this.engineIdleTime = engineIdleTime;
	}

	public Timestamp getLastUpdTs() {
		return lastUpdTs;
	}

	public void setLastUpdTs(Timestamp lastUpdTs) {
		this.lastUpdTs = lastUpdTs;
	}

	public Double getEconomyBandDistance() {
		return economyBandDistance;
	}

	public void setEconomyBandDistance(Double economyBandDistance) {
		this.economyBandDistance = economyBandDistance;
	}

	public Double getEconomyDriving() {
		return economyDriving;
	}

	public void setEconomyDriving(Double economyDriving) {
		this.economyDriving = economyDriving;
	}

	public Long getDriverAnalysisId() {
		return driverAnalysisId;
	}

	public void setDriverAnalysisId(Long driverAnalysisId) {
		this.driverAnalysisId = driverAnalysisId;
	}

	public Integer getDriverId() {
		return driverId;
	}

	public void setDriverId(Integer driverId) {
		this.driverId = driverId;
	}

	public Double getEngineIdleTimePercent() {
		return engineIdleTimePercent;
	}

	public void setEngineIdleTimePercent(Double engineIdleTimePercent) {
		this.engineIdleTimePercent = engineIdleTimePercent;
	}

	public Long getEconomicBandTime() {
		return economicBandTime;
	}

	public void setEconomicBandTime(Long economicBandTime) {
		this.economicBandTime = economicBandTime;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public Integer getIsCanParameter() {
		return isCanParameter;
	}

	public void setIsCanParameter(Integer isCanParameter) {
		this.isCanParameter = isCanParameter;
	}

	public Integer getHarshAcceleration() {
		return harshAcceleration;
	}

	public void setHarshAcceleration(Integer harshAcceleration) {
		this.harshAcceleration = harshAcceleration;
	}

	public Integer getHarshCornering() {
		return harshCornering;
	}

	public void setHarshCornering(Integer harshCornering) {
		this.harshCornering = harshCornering;
	}

	public Integer getHarshBraking() {
		return harshBraking;
	}

	public void setHarshBraking(Integer harshBraking) {
		this.harshBraking = harshBraking;
	}

	@Override
	public String toString() {
		return "DriverAnalysisList [driverAnalysisId=" + driverAnalysisId + ", averageVehicleSpeed="
				+ averageVehicleSpeed + ", driverScore=" + driverScore + ", economicBand=" + economicBand
				+ ", fuelEfficiency=" + fuelEfficiency + ", greenBandDistance=" + greenBandDistance
				+ ", engineIdleTimePercent=" + engineIdleTimePercent + ", maxSpeedLat=" + maxSpeedLat
				+ ", maxSpeedLong=" + maxSpeedLong + ", maxSpeedTime=" + maxSpeedTime + ", maximumSpeed=" + maximumSpeed
				+ ", engineNonIdleTimePercent=" + engineNonIdleTimePercent + ", recordTimestamp=" + recordTimestamp
				+ ", reportDate=" + reportDate + ", speedAdherence=" + speedAdherence + ", speedViolation="
				+ speedViolation + ", speedViolationTime=" + speedViolationTime + ", speedband0To20km="
				+ speedband0To20km + ", speedband21To40km=" + speedband21To40km + ", speedband41To60km="
				+ speedband41To60km + ", speedbandOver80km=" + speedbandOver80km + ", speedbandTo80km="
				+ speedbandTo80km + ", starCount=" + starCount + ", totalDriveTime=" + totalDriveTime
				+ ", tripDistance=" + tripDistance + ", greenBandTime=" + greenBandTime + ", yellowBandTime="
				+ yellowBandTime + ", redBandTime=" + redBandTime + ", engineRunTime=" + engineRunTime
				+ ", engineIdleTime=" + engineIdleTime + ", lastUpdTs=" + lastUpdTs + ", economyBandDistance="
				+ economyBandDistance + ",driverId=" + driverId + ", economicBandTime=" + economicBandTime
				+ ", groupId=" + groupId + ", ownerId=" + ownerId + ", isCanParameter=" + isCanParameter
				+ ", harshAcceleration=" + harshAcceleration + ", harshCornering=" + harshCornering + ", harshBraking="
				+ harshBraking + ",economyDriving=" + economyDriving + "]";
	}

	public Integer getSpeedingCount() {
		return speedingCount;
	}

	public void setSpeedingCount(Integer speedingCount) {
		this.speedingCount = speedingCount;
	}

	public Double getMaximumSpeed() {
		return maximumSpeed;
	}

	public void setMaximumSpeed(Double maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}

}
