package com.dicv.cwp.dao.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VEHICLE_GPS_EVENT_REPORT")
public class VehicleEventReport {

	@Id
	@SequenceGenerator(name = "VEHICLE_GPS_EVENT_ID_GENERATOR", sequenceName = "VEHICLE_GPS_EVENT_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_GPS_EVENT_ID_GENERATOR")
	@Column(name = "VEHICLE_GPS_EVENT_ID")
	private Long vehicleGpsEventId;

	@Column(name = "COUNT")
	private Long gpsCount;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	@Column(name = "UPDATED_TIME")
	private Timestamp modifiedDateTime;

	@Column(name = "GPS_DATE")
	private Date gpsDate;

	public Long getVehicleGpsEventId() {
		return vehicleGpsEventId;
	}

	public void setVehicleGpsEventId(Long vehicleGpsEventId) {
		this.vehicleGpsEventId = vehicleGpsEventId;
	}



	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}

	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}

	public Date getGpsDate() {
		return gpsDate;
	}

	public void setGpsDate(Date gpsDate) {
		this.gpsDate = gpsDate;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Long getGpsCount() {
		return gpsCount;
	}

	public void setGpsCount(Long gpsCount) {
		this.gpsCount = gpsCount;
	}

}
