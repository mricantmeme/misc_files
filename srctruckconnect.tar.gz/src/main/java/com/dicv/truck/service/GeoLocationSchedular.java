package com.dicv.truck.service;

import org.springframework.stereotype.Component;

@Component
public class GeoLocationSchedular {

}
