package com.dicv.cwp.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.GeoFenceReport;
import com.dicv.cwp.repository.GeoFenceReportRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class GeoFenceUpdate {

	private static Logger LOGGER = Logger.getLogger(GeoFenceUpdate.class);

	@Autowired
	private GeoFenceReportRepo geoFenceReportRepo;

	@Value("${geo_fence_time}")
	private String geoFenceTime;

	@Scheduled(fixedDelay = 120000)
	public void sendOverSpeedAndGeoFence() {
		if (geoFenceTime != null && geoFenceTime.equals("Yes")) {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			try {

				List<GeoFenceReport> report = geoFenceReportRepo.getGeoFenceReport();

				for (GeoFenceReport rep : report) {

					Long timeSpent = (rep.getGeoFenceExitTime().getTime() - rep.getGeoFenceEntryTime().getTime())
							/ 1000;
					rep.setTime_spent(timeSpent.toString());
					rep.setGeoSystimestamp(DicvUtil.getCurrentTimeStamp());
					geoFenceReportRepo.save(rep);

				}

			} catch (Exception ex) {
				LOGGER.error("Geo Fence  Time Spent Alert Exception :: ", ex);
			}
			stopWatch.stop();
			LOGGER.info("Geo Fence  Time Spent Pollar Completed in :: " + stopWatch.getTotalTimeSeconds() + " sec");
		}
	}

}
