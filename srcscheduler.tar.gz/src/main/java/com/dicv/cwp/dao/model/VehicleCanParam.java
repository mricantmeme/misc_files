package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the VEHICLE_CAN_PARAM database table.
 * 
 */
@Entity
@Table(name = "VEHICLE_CAN_PARAM")
public class VehicleCanParam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "VEH_CAN_PARAM_ID_GENERATOR", sequenceName = "VEHICLE_CAN_PARAM_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEH_CAN_PARAM_ID_GENERATOR")
	@Column(name = "VEH_CAN_PARAM_ID")
	private Long vehicleCanParamId;

	@Column(name = "VEHICLE_ENGINE_RPM")
	private Long vehicleEngineRpm;

	@Column(name = "VEHICLE_ENGINE_COOLANT_TEMP")
	private Double vehicleEngineCoolantTemp;

	@Column(name = "VEHICLE_SPEED_CAN")
	private Long vehicleSpeedCan;

	@Column(name = "FUEL_TANK_RELATIVE_VALUE")
	private Integer fuelTankLevel;

	@Column(name = "BATTERY_HEALTH")
	private Integer batteryHealth;

	@Column(name = "UPDATED_DATE_TIME")
	private Timestamp updatedDateTime;

	@Column(name = "RECEIVED_DATE_TIME")
	private Timestamp receivedDateTime;

	@Column(name = "LAST_ENGINE_ON")
	private Timestamp lastEngineOnTime;

	@Column(name = "CAN_VEHICLE_UPDATED_ON")
	private Timestamp vehicleLastUpdateON;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;
	
	@Column(name = "ADBLUE_LEVEL")
	private Double adblueLevel;

	public VehicleCanParam() {
	}

	public Long getVehicleEngineRpm() {
		return vehicleEngineRpm;
	}

	public void setVehicleEngineRpm(Long vehicleEngineRpm) {
		this.vehicleEngineRpm = vehicleEngineRpm;
	}

	public Double getVehicleEngineCoolantTemp() {
		return vehicleEngineCoolantTemp;
	}

	public void setVehicleEngineCoolantTemp(Double vehicleEngineCoolantTemp) {
		this.vehicleEngineCoolantTemp = vehicleEngineCoolantTemp;
	}

	public Long getVehicleSpeedCan() {
		return vehicleSpeedCan;
	}

	public void setVehicleSpeedCan(Long vehicleSpeedCan) {
		this.vehicleSpeedCan = vehicleSpeedCan;
	}

	public Integer getFuelTankLevel() {
		return fuelTankLevel;
	}

	public void setFuelTankLevel(Integer fuelTankLevel) {
		this.fuelTankLevel = fuelTankLevel;
	}

	public Integer getBatteryHealth() {
		return batteryHealth;
	}

	public void setBatteryHealth(Integer batteryHealth) {
		this.batteryHealth = batteryHealth;
	}

	public Timestamp getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Timestamp updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public Timestamp getReceivedDateTime() {
		return receivedDateTime;
	}

	public void setReceivedDateTime(Timestamp receivedDateTime) {
		this.receivedDateTime = receivedDateTime;
	}

	public Timestamp getLastEngineOnTime() {
		return lastEngineOnTime;
	}

	public void setLastEngineOnTime(Timestamp lastEngineOnTime) {
		this.lastEngineOnTime = lastEngineOnTime;
	}

	public Timestamp getVehicleLastUpdateON() {
		return vehicleLastUpdateON;
	}

	public void setVehicleLastUpdateON(Timestamp vehicleLastUpdateON) {
		this.vehicleLastUpdateON = vehicleLastUpdateON;
	}

	public Long getVehicleCanParamId() {
		return vehicleCanParamId;
	}

	public void setVehicleCanParamId(Long vehicleCanParamId) {
		this.vehicleCanParamId = vehicleCanParamId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Double getAdblueLevel() {
		return adblueLevel;
	}

	public void setAdblueLevel(Double adblueLevel) {
		this.adblueLevel = adblueLevel;
	}

}