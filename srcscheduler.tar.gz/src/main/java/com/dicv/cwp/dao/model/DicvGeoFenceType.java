package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

/**
 * The persistent class for the DICV_TYPE database table.
 * 
 */
@Entity
@Table(name = "DICV_GEOFENCE_TYPE")
// @NamedQuery(query="select t.typeId,t.typeName, from DicvType t where subTypeId=:subTypeId",name="findSubGeoFenceType"),
@NamedQueries({
		@NamedQuery(query = "select t from DicvGeoFenceType t where t.geoFenceTypeId=:typeId and t.isDeleted= 0", name = "findAndEditGeoFenceType"),
		@NamedQuery(query = "select t from DicvGeoFenceType t where t.typeName=:typeName and t.isDeleted= 0", name = "findGeoFenceTypeExist"),
		@NamedQuery(query = "select t from DicvGeoFenceType t join t.createdByUser c where c.userId in (:userIdList) and t.isDeleted= 0", name = "DicvGeoFenceType.findAll"),
		@NamedQuery(query = "select count(t) from DicvGeoFenceType t where t.createdByUser=:createdByUser", name="findGeoFencetypeCountByUser")// ,
// @NamedQuery(query="select t.typeId from DicvType t where t.geoFenceTypeId=:geoFenceTypeId ",name="deleteGeoFenceTypeId")
})
public class DicvGeoFenceType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DICV_TYPE_GEOFENCETYPEID_GENERATOR", sequenceName = "DICV_GEOFENCE_TYPE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DICV_TYPE_GEOFENCETYPEID_GENERATOR")
	@Column(name = "GEOFENCE_TYPE_ID")
	private Integer geoFenceTypeId;

	@Column(name = "GEOFENCE_TYPE_NAME")
	private String typeName;

	// bi-directional many-to-one association to GeoFenceInfo
	// @OneToMany(mappedBy="dicvGeoFenceType")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dicvGeoFenceType")
	@Where(clause = "IS_DELETED=0")
	private List<GeoFenceInfo> geoFenceInfos;

	// //bi-directional many-to-one association to Vehicle
	// @OneToMany(mappedBy="dicvType")
	// private List<Vehicle> vehicles;

	@Column(name = "CREATED_DATE")
	private Timestamp createdOn;

	@Column(name = "MODIFIED_DATE")
	private Timestamp updatedOn;

	@Column(name = "IS_DELETED")
	private int isDeleted;

	// bi-directional many-to-one association to DicvUser
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATED_BY")
	private DicvUser createdByUser;

	// bi-directional many-to-one association to DicvUser
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "UPDATED_BY")
	private DicvUser updatedByUser;

	public Integer getGeoFenceTypeId() {
		return geoFenceTypeId;
	}

	public void setGeoFenceTypeId(Integer geoFenceTypeId) {
		this.geoFenceTypeId = geoFenceTypeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public List<GeoFenceInfo> getGeoFenceInfos() {
		return geoFenceInfos;
	}

	public void setGeoFenceInfos(List<GeoFenceInfo> geoFenceInfos) {
		this.geoFenceInfos = geoFenceInfos;
	}

	// public List<Vehicle> getVehicles() {
	// return vehicles;
	// }
	//
	// public void setVehicles(List<Vehicle> vehicles) {
	// this.vehicles = vehicles;
	// }

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public DicvUser getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(DicvUser createdByUser) {
		this.createdByUser = createdByUser;
	}

	public DicvUser getUpdatedByUser() {
		return updatedByUser;
	}

	public void setUpdatedByUser(DicvUser updatedByUser) {
		this.updatedByUser = updatedByUser;
	}

}