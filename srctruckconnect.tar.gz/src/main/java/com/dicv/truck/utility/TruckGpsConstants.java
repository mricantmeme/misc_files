package com.dicv.truck.utility;

public class TruckGpsConstants {
	
	public static final String API_RESPONSE = "\"SUCCESS\"";

}
