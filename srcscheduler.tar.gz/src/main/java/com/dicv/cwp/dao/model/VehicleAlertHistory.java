package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VEHICLE_ALERT_HISTORY")
public class VehicleAlertHistory {

	public VehicleAlertHistory() {
		super();
	}

	@Id
	@SequenceGenerator(name = "VEHICLE_ALERT_HISTORY_ID_GENERATOR", sequenceName = "VEHICLE_ALERT_HISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_ALERT_HISTORY_ID_GENERATOR")
	@Column(name = "VEHICLE_ALERT_HISTORY_ID")
	private Long vehicleAlertHistoryId;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	@Column(name = "LAST_SPEED_ALERT_SENT")
	private Timestamp lastSpeedAlertSent;

	@Column(name = "SPEED_GPS_PROCESS_TIME")
	private Timestamp speedGpsProcessTime;

	@Column(name = "BATTERY_HEALTH_PROCESS_TIME")
	private Timestamp batteryHealthTime;

	@Column(name = "LOW_BATTERY_DETECTED")
	private Integer lowBatteryDetected;

	@Column(name = "MAIN_BATTERY_DETECTED")
	private Timestamp mainBatteryDetected;

	@Column(name = "BATTERY_DISC_TIME")
	private Timestamp batteryDiscGps;

	@Column(name = "FUEL_DROP_PROCESS_TIME")
	private Timestamp fuelDropProcessTime;
	
	@Column(name = "IDLE_TIME_PROCESS")
	private Timestamp idleTimeProcess;
	
	

	public Long getVehicleAlertHistoryId() {
		return vehicleAlertHistoryId;
	}

	public void setVehicleAlertHistoryId(Long vehicleAlertHistoryId) {
		this.vehicleAlertHistoryId = vehicleAlertHistoryId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Timestamp getLastSpeedAlertSent() {
		return lastSpeedAlertSent;
	}

	public void setLastSpeedAlertSent(Timestamp lastSpeedAlertSent) {
		this.lastSpeedAlertSent = lastSpeedAlertSent;
	}

	public Timestamp getSpeedGpsProcessTime() {
		return speedGpsProcessTime;
	}

	public void setSpeedGpsProcessTime(Timestamp speedGpsProcessTime) {
		this.speedGpsProcessTime = speedGpsProcessTime;
	}

	public Timestamp getBatteryHealthTime() {
		return batteryHealthTime;
	}

	public void setBatteryHealthTime(Timestamp batteryHealthTime) {
		this.batteryHealthTime = batteryHealthTime;
	}

	public Timestamp getBatteryDiscGps() {
		return batteryDiscGps;
	}

	public void setBatteryDiscGps(Timestamp batteryDiscGps) {
		this.batteryDiscGps = batteryDiscGps;
	}

	public Timestamp getFuelDropProcessTime() {
		return fuelDropProcessTime;
	}

	public void setFuelDropProcessTime(Timestamp fuelDropProcessTime) {
		this.fuelDropProcessTime = fuelDropProcessTime;
	}

	public Integer getLowBatteryDetected() {
		return lowBatteryDetected;
	}

	public void setLowBatteryDetected(Integer lowBatteryDetected) {
		this.lowBatteryDetected = lowBatteryDetected;
	}



	public void setMainBatteryDetected(Timestamp mainBatteryDetected) {
		this.mainBatteryDetected = mainBatteryDetected;
	}

	public Timestamp getMainBatteryDetected() {
		return mainBatteryDetected;
	}

	public Timestamp getIdleTimeProcess() {
		return idleTimeProcess;
	}

	public void setIdleTimeProcess(Timestamp idleTimeProcess) {
		this.idleTimeProcess = idleTimeProcess;
	}

}
