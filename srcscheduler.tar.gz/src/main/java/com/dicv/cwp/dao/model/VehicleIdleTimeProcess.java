package com.dicv.cwp.dao.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VEHICLE_IDLE_PROCESS")
public class VehicleIdleTimeProcess {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7171193274135790838L;

	@Id
	@SequenceGenerator(name = "VEHICLE_IDLE_PROCESS_SEQ", sequenceName = "VEHICLE_IDLE_PROCESS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_IDLE_PROCESS_SEQ")
	@Column(name = "VEHICLE_IDLE_PROCESS_ID")
	private Long vehicleIdleTimeProcessId;

	@Column(name = "PROCESS_TIME")
	private Timestamp processTime;

	@Column(name = "UPDATED_AT")
	private Timestamp updatedAt;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	public Timestamp getProcessTime() {
		return processTime;
	}

	public void setProcessTime(Timestamp processTime) {
		this.processTime = processTime;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}
}
