package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VEHICLE_TO_GEO_FENCE")
public class VehicleToGeoFence implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "VEHICLE_TO_GEO_FENCE_VEHGEOFENCEID_GENERATOR", sequenceName = "VEHICLE_TO_GEO_FENCE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_TO_GEO_FENCE_VEHGEOFENCEID_GENERATOR")
	@Column(name = "VEH_GEO_FENCE_ID")
	private Integer vehGeoFenceId;

	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "IS_DELETED")
	private Integer isDeleted;

	@Column(name = "LAST_UPDATED_ON")
	private Timestamp lastUpdatedOn;

	@Column(name = "CREATED_BY")
	private Integer createdBy;

	@Column(name = "IS_VEHICLE_INSIDE")
	private Integer isVehicleInside;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GEO_FENCE_ID")
	private GeoFenceInfo geoFenceInfo;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "VEHICLE_ID")
	private Vehicle vehicle;

	public Integer getVehGeoFenceId() {
		return vehGeoFenceId;
	}

	public void setVehGeoFenceId(Integer vehGeoFenceId) {
		this.vehGeoFenceId = vehGeoFenceId;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Timestamp getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(Timestamp lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getIsVehicleInside() {
		return isVehicleInside;
	}

	public void setIsVehicleInside(Integer isVehicleInside) {
		this.isVehicleInside = isVehicleInside;
	}

	public GeoFenceInfo getGeoFenceInfo() {
		return geoFenceInfo;
	}

	public void setGeoFenceInfo(GeoFenceInfo geoFenceInfo) {
		this.geoFenceInfo = geoFenceInfo;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	@Override
	public String toString() {
		return "VehicleToGeoFence [vehGeoFenceId=" + vehGeoFenceId + ", createdOn=" + createdOn + ", isDeleted="
				+ isDeleted + ", lastUpdatedOn=" + lastUpdatedOn + ", createdBy=" + createdBy + ", isVehicleInside="
				+ isVehicleInside + ", geoFenceInfo=" + geoFenceInfo + " ]";
	}

}