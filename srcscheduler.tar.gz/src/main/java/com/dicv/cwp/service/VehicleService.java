package com.dicv.cwp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.VehicleRepo;

@Component
public class VehicleService {

	@Autowired
	private VehicleRepo vehicleRepo;

	public List<Vehicle> getVehicleList() {
		List<Vehicle> vehicleList = vehicleRepo.getAllVehicle();
		return vehicleList;
	}

	public List<VehicleListDto> getVehicleNoAndIMEI() {
		List<VehicleListDto> allVehicleList = vehicleRepo.loadAllVehicles();
		return allVehicleList;
	}

}
