package com.dicv.cwp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.SpeedReport;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dao.model.VehicleUtilization;
import com.dicv.cwp.dto.Address;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.SpeedReportRepo;
import com.dicv.cwp.repository.TripStopLocationsRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.repository.VehicleUtilizationRepo;
import com.dicv.cwp.utils.DicvUtil;
import com.dicv.cwp.utils.DistanceCalculation;

@Service
public class TruckAnalysis {

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Value("${vehicle_Utilization}")
	private String vehicleUtilization;

	@Value("${server_name}")
	private String serverName;

	@Autowired
	private VehicleUtilizationRepo vehicleUtilizationRepo;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private SendMailService sendMailService;

	@Autowired
	private TripStopLocationsRepo tripStopRepo;

	@Autowired
	private SpeedReportRepo speedReportRepo;

	@Autowired
	private GoogleAPIService addressUtil;

	private static final Logger LOGGER = LoggerFactory.getLogger(TruckAnalysis.class);

	@Scheduled(cron = "0 0 5 * * *")
	public void schedulerProcess() {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			if (vehicleUtilization != null && vehicleUtilization.equals("Yes")) {

				List<Vehicle> allVehicleList = vehicleRepo.getAllVehicle();
				processVehicleUtilization(allVehicleList);
				watch.stop();
				sendEmail("Vehicle Utilization Report :: " + serverName,
						"Total time taken for completing report process :: " + watch.getTotalTimeSeconds()
								+ " Seconds ");
				LOGGER.info("Vehicle Utilization Schedular Completed  :: ");
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Vehicle Utilization  " + ex);
			sendEmail("Vehicle Utilization Report :: " + serverName, "Exception in Vehicle Utilization Report ");
		}

	}

	private void processVehicleUtilization(List<Vehicle> allVehicleList) throws ParseException {
		if (allVehicleList != null && allVehicleList.size() > 0) {
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
			Date fromDate = sdf1.parse(DicvUtil.getPreviousStartOfDay(new Date()));
			Date toDate = sdf1.parse(DicvUtil.getPreviousEndOfDay(new Date()));
			processVehicle(allVehicleList, fromDate, toDate);
		}
	}

	@Async
	public void runUtilizationProcess(Long vehicleId, Date from, Date to) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			List<Vehicle> allVehicleList = null;
			if (vehicleId == null || vehicleId == 0) {
				allVehicleList = vehicleRepo.getAllVehicle();
			} else {
				Vehicle veh = vehicleRepo.getVehicle(vehicleId);
				allVehicleList = new ArrayList<Vehicle>();
				allVehicleList.add(veh);
			}
			LOGGER.info("Processing for Vehicle " + vehicleId);
			if (allVehicleList != null && allVehicleList.size() > 0) {
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
				Date fromDate = sdf1.parse(DicvUtil.getStartTimeOfDate(from));
				Date toDate = sdf1.parse(DicvUtil.getEndTimeOfDate(to));
				processVehicle(allVehicleList, fromDate, toDate);
			}
			watch.stop();
			LOGGER.info("Completed Utilization Processing for Vehicle " + vehicleId);
		} catch (Exception ex) {
			LOGGER.error("Exception in Vehicle Utilization " + ex);
		}
	}

	private void processVehicle(List<Vehicle> allVehicleList, Date fromDate, Date toDate) {
		for (Vehicle veh : allVehicleList) {
			try {
				processUtilization(fromDate, toDate, veh);
			} catch (Exception ex) {
				LOGGER.error("Exception in Vehicle Utilization  " + ex);
			}
		}
	}

	@Transactional
	private void processUtilization(Date fromDate, Date toDate, Vehicle veh) {
		try {
			Long vehicleTotalIdleTime = 0l;
			Integer vehNoOfStops = 0;
			Long vehicleMaxIdleTime = 0l;
			Double vehMaxIdleLatitude = 0d;
			Double vehMaxIdleLongitude = 0d;
			Double vehMaxSpeedLatitude = 0d;
			Double vehMaxSpeedLongitude = 0d;
			Double vehCurLatitude = 0d;
			Double vehCurLongitude = 0d;
			Double vehMaxSpeed = 0d;
			Double avgSpeed = 0d;
			Double vehicleUtilization = 0d;
			Double vehicleDistance = 0d;
			Double vehicleInvalidSpeed = 0d;
			Double vehicleDistanceSum = 0d;
			Long engineOnTime = 0l;
			Long engineRunTime = 0l;
			Long vehicleIdleTime = 0l;
			Long timeIn0To10km = 0l;
			Long timeIn11To20km = 0l;
			Long timeIn21To30km = 0l;
			Long timeIn31To40km = 0l;
			Long timeIn41To50km = 0l;
			Long timeIn51To60km = 0l;
			Long timeIn61To70km = 0l;
			Long timeIn71To80km = 0l;
			Long timeIn81To90km = 0l;
			Long timeIn91To100km = 0l;
			Long timeIn101To110km = 0l;
			Long timeInOver110km = 0l;
			Double distIn0To10km = 0d;
			Double distIn11To20km = 0d;
			Double distIn21To30km = 0d;
			Double distIn31To40km = 0d;
			Double distIn41To50km = 0d;
			Double distIn51To60km = 0d;
			Double distIn61To70km = 0d;
			Double disteIn71To80km = 0d;
			Double distIn81To90km = 0d;
			Double distIn91To100km = 0d;
			Double distIn101To110km = 0d;
			Double distInOver110km = 0d;
			Date gpsParamTime = null;
			if (veh.getGpsImei() != null && veh.getGpsImei().getGpsImei() != null) {
				final Long gpsImei = veh.getGpsImei().getGpsImei().longValue();
				final Long totalCount = countTotalGpsParamData(fromDate, toDate, gpsImei);
				if (totalCount > 0) {
					Integer iterCount = totalCount.intValue() <= 1000 ? 0 : totalCount.intValue() / 1000;
					if ((totalCount.intValue() % 1000) > 0)
						iterCount = iterCount + 1;
					for (int i = 1; i <= iterCount; i++) {

						final List<GpsVehParameterDto> gpsParamData = getGpsParamData(fromDate, toDate, veh,
								gpsParamTime);
						if (gpsParamData != null && gpsParamData.size() > 1) {

							final Integer totalRecords = gpsParamData.size();
							Integer gpsRecordCount = 0;
							for (GpsVehParameterDto gpsVehicleParam : gpsParamData) {

								gpsRecordCount = gpsRecordCount + 1;
								gpsParamTime = new Date(gpsVehicleParam.getGpsTime().getTime());
								if (gpsRecordCount >= totalRecords) {
									break;
								}
								final GpsVehParameterDto gpsVehicleParamNext = gpsParamData.get(gpsRecordCount);
								if (!checkGpsNullValue(gpsVehicleParam, gpsVehicleParamNext))
									continue;

								vehCurLatitude = gpsVehicleParam.getGpsLatitude();
								vehCurLongitude = gpsVehicleParam.getGpsLongitude();

								final Long vehicleDiffInSeconds = (gpsVehicleParamNext.getGpsTime().getTime()
										- gpsVehicleParam.getGpsTime().getTime()) / 1000;
								if (vehicleDiffInSeconds < 0)
									continue;
								vehicleDistance = DistanceCalculation.distance(gpsVehicleParam.getGpsLatitude(),
										gpsVehicleParam.getGpsLongitude(), gpsVehicleParamNext.getGpsLatitude(),
										gpsVehicleParamNext.getGpsLongitude());
								vehicleInvalidSpeed = 0d;
								if (vehicleDistance > 0 && vehicleDiffInSeconds > 0) {
									vehicleInvalidSpeed = ((vehicleDistance / vehicleDiffInSeconds) * 3600);
								}
								if (vehicleInvalidSpeed > 9999 || vehicleDiffInSeconds > 900) {
									continue;
								}
								// Total Distance
								vehicleDistanceSum = checkNullValue(vehicleDistanceSum, vehicleDistance);
								vehicleDistanceSum = roundOffDecimal(vehicleDistanceSum);
								// Engine On Time
								if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParamNext.getEngineON() == 1) {
									engineOnTime = engineOnTime + vehicleDiffInSeconds;
									// Engine Run Time
									if (gpsVehicleParam.getGpsSpkm() > 0 && gpsVehicleParamNext.getGpsSpkm() > 0) {
										engineRunTime = engineRunTime + vehicleDiffInSeconds;
										vehicleIdleTime = 0l;
									}
									if (gpsVehicleParam.getGpsSpkm() == 0 && gpsVehicleParamNext.getGpsSpkm() == 0) {
										vehicleIdleTime = vehicleDiffInSeconds + vehicleIdleTime;
										vehicleTotalIdleTime = vehicleTotalIdleTime + vehicleDiffInSeconds;
										// max idle time
										if (vehicleMaxIdleTime <= vehicleIdleTime) {
											vehicleMaxIdleTime = vehicleIdleTime;
											vehMaxIdleLatitude = gpsVehicleParam.getGpsLatitude();
											vehMaxIdleLongitude = gpsVehicleParam.getGpsLongitude();
										}

									}
									// Speed Report
									if (gpsVehicleParam.getGpsSpkm() >= 0 && gpsVehicleParam.getGpsSpkm() <= 10) {
										timeIn0To10km = timeIn0To10km + vehicleDiffInSeconds;
										distIn0To10km = distIn0To10km + vehicleDistance;
										distIn0To10km = roundOffDecimal(distIn0To10km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 11
											&& gpsVehicleParam.getGpsSpkm() <= 20) {
										timeIn11To20km = timeIn11To20km + vehicleDiffInSeconds;
										distIn11To20km = distIn11To20km + vehicleDistance;
										distIn11To20km = roundOffDecimal(distIn11To20km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 21
											&& gpsVehicleParam.getGpsSpkm() <= 30) {
										timeIn21To30km = timeIn21To30km + vehicleDiffInSeconds;
										distIn21To30km = distIn21To30km + vehicleDistance;
										distIn21To30km = roundOffDecimal(distIn21To30km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 31
											&& gpsVehicleParam.getGpsSpkm() <= 40) {
										timeIn31To40km = timeIn31To40km + vehicleDiffInSeconds;
										distIn31To40km = distIn31To40km + vehicleDistance;
										distIn31To40km = roundOffDecimal(distIn31To40km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 41
											&& gpsVehicleParam.getGpsSpkm() <= 50) {
										timeIn41To50km = timeIn41To50km + vehicleDiffInSeconds;
										distIn41To50km = distIn41To50km + vehicleDistance;
										distIn41To50km = roundOffDecimal(distIn41To50km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 51
											&& gpsVehicleParam.getGpsSpkm() <= 60) {
										timeIn51To60km = timeIn51To60km + vehicleDiffInSeconds;
										distIn51To60km = distIn51To60km + vehicleDistance;
										distIn51To60km = roundOffDecimal(distIn51To60km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 61
											&& gpsVehicleParam.getGpsSpkm() <= 70) {
										timeIn61To70km = timeIn61To70km + vehicleDiffInSeconds;
										distIn61To70km = distIn61To70km + vehicleDistance;
										distIn61To70km = roundOffDecimal(distIn61To70km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 71
											&& gpsVehicleParam.getGpsSpkm() <= 80) {
										timeIn71To80km = timeIn71To80km + vehicleDiffInSeconds;
										disteIn71To80km = disteIn71To80km + vehicleDistance;
										disteIn71To80km = roundOffDecimal(disteIn71To80km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 81
											&& gpsVehicleParam.getGpsSpkm() <= 90) {
										timeIn81To90km = timeIn81To90km + vehicleDiffInSeconds;
										distIn81To90km = distIn81To90km + vehicleDistance;
										distIn81To90km = roundOffDecimal(distIn81To90km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 91
											&& gpsVehicleParam.getGpsSpkm() <= 100) {
										timeIn91To100km = timeIn91To100km + vehicleDiffInSeconds;
										distIn91To100km = distIn91To100km + vehicleDistance;
										distIn91To100km = roundOffDecimal(distIn91To100km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 101
											&& gpsVehicleParam.getGpsSpkm() <= 110) {
										timeIn101To110km = timeIn101To110km + vehicleDiffInSeconds;
										distIn101To110km = distIn101To110km + vehicleDistance;
										distIn101To110km = roundOffDecimal(distIn101To110km);
									} else if (gpsVehicleParam.getGpsSpkm() >= 111) {
										timeInOver110km = timeInOver110km + vehicleDiffInSeconds;
										distInOver110km = distInOver110km + vehicleDistance;
										distInOver110km = roundOffDecimal(distInOver110km);
									}

								} else {
									vehicleIdleTime = 0l;
								}

								// Maximum Speed
								if (vehMaxSpeed < gpsVehicleParam.getGpsSpkm()) {
									vehMaxSpeed = gpsVehicleParam.getGpsSpkm();
									vehMaxSpeedLatitude = gpsVehicleParam.getGpsLatitude();
									vehMaxSpeedLongitude = gpsVehicleParam.getGpsLongitude();
								}
							}

						} // Gps For Loop Ending
					}
					if (engineRunTime == 0 || engineOnTime == 0 || vehicleDistanceSum == 0) {
						avgSpeed = 0d;
					} else {
						avgSpeed = (vehicleDistanceSum / (engineRunTime.doubleValue() / 3600d));
						avgSpeed = roundOffDecimal(avgSpeed);
					}

					vehNoOfStops = getVehicleStop(veh.getVehicleId(), fromDate, toDate);
					// Utilization
					if (engineRunTime > 0)
						vehicleUtilization = ((engineRunTime / 3600d) / 24) * 100;
					vehicleUtilization = vehicleUtilization == null || vehicleUtilization == 0 ? 0
							: roundOffDecimal(vehicleUtilization);
					vehicleUtilization = vehicleUtilization < 0 ? 0 : vehicleUtilization;
					vehicleUtilization = vehicleUtilization > 100 ? 100 : vehicleUtilization;
				}
			}

			saveSpeedReport(veh.getVehicleId(), fromDate, timeIn0To10km, timeIn11To20km, timeIn21To30km, timeIn31To40km,
					timeIn41To50km, timeIn51To60km, timeIn61To70km, timeIn71To80km, timeIn81To90km, timeIn91To100km,
					timeIn101To110km, timeInOver110km, distIn0To10km, distIn11To20km, distIn21To30km, distIn31To40km,
					distIn41To50km, distIn51To60km, distIn61To70km, disteIn71To80km, distIn81To90km, distIn91To100km,
					distIn101To110km, distInOver110km, vehMaxSpeed, vehicleDistanceSum, vehMaxSpeedLatitude,
					vehMaxSpeedLongitude);

			saveVehiUtilization(fromDate, veh, vehicleTotalIdleTime, vehNoOfStops, vehicleMaxIdleTime,
					vehMaxIdleLatitude, vehMaxIdleLongitude, vehCurLatitude, vehCurLongitude, vehMaxSpeed, avgSpeed,
					vehicleUtilization, vehicleDistanceSum, engineOnTime, engineRunTime, vehMaxSpeedLatitude,
					vehMaxSpeedLongitude);
		} catch (Exception ex) {
			LOGGER.error("Exception while processing Vehicle :: " + veh.getRegistrationId(), ex);
			return;
		}
	}

	private Long countTotalGpsParamData(Date fromDate, Date toDate, final Long gpsImei) {
		return gpsVehicleRepo.countofGpsParamDataforUtilization(gpsImei, fromDate, toDate);
	}

	private List<GpsVehParameterDto> getGpsParamData(Date fromDate, Date toDate, Vehicle veh, Date gpsParamTime) {
		List<GpsVehParameterDto> gpsParamData = (gpsParamTime == null)
				? gpsVehicleRepo.collectGpsParamDataforUtilization(veh.getGpsImei().getGpsImei().longValue(), fromDate,
						toDate, new PageRequest(0, 1000))
				: gpsVehicleRepo.collectGpsParamDataforUtilization(veh.getGpsImei().getGpsImei().longValue(), fromDate,
						toDate, gpsParamTime, new PageRequest(0, 1000));
		return gpsParamData;
	}

	@Transactional
	private void saveSpeedReport(Long vehicleId, Date reportDate, Long timeIn0To10km, Long timeIn11To20km,
			Long timeIn21To30km, Long timeIn31To40km, Long timeIn41To50km, Long timeIn51To60km, Long timeIn61To70km,
			Long timeIn71To80km, Long timeIn81To90km, Long timeIn91To100km, Long timeIn101To110km, Long timeInOver110km,
			Double distIn0To10km, Double distIn11To20km, Double distIn21To30km, Double distIn31To40km,
			Double distIn41To50km, Double distIn51To60km, Double distIn61To70km, Double disteIn71To80km,
			Double distIn81To90km, Double distIn91To100km, Double distIn101To110km, Double distInOver110km,
			Double maxSpeed, Double totalDistance, Double maxSpeedLat, Double maxSpeedLong) {
		try {
			SpeedReport newSpeedReport = speedReportRepo.getSpeedReport(vehicleId, reportDate);
			if (newSpeedReport == null) {
				newSpeedReport = new SpeedReport();
			}
			newSpeedReport.setDisteIn71To80km(disteIn71To80km);
			newSpeedReport.setDistIn0To10km(distIn0To10km);
			newSpeedReport.setDistIn101To110km(distIn101To110km);
			newSpeedReport.setDistIn11To20km(distIn11To20km);
			newSpeedReport.setDistIn21To30km(distIn21To30km);
			newSpeedReport.setDistIn31To40km(distIn31To40km);
			newSpeedReport.setDistIn41To50km(distIn41To50km);
			newSpeedReport.setDistIn51To60km(distIn51To60km);
			newSpeedReport.setDistIn61To70km(distIn61To70km);
			newSpeedReport.setDistIn81To90km(distIn81To90km);
			newSpeedReport.setDistIn91To100km(distIn91To100km);
			newSpeedReport.setDistInOver110km(distInOver110km);
			newSpeedReport.setMaxSpeed(maxSpeedLong);
			newSpeedReport.setMaxSpeedLat(maxSpeedLat);
			newSpeedReport.setMaxSpeedLong(maxSpeedLong);
			Address address = addressUtil.getAddress(maxSpeedLat, maxSpeedLong);
			if (address.getResponse())
				newSpeedReport.setLocation(address.getAddress());
			newSpeedReport.setReportDate(reportDate);
			newSpeedReport.setTimeIn0To10km(timeIn0To10km);
			newSpeedReport.setTimeIn101To110km(timeIn101To110km);
			newSpeedReport.setTimeIn11To20km(timeIn11To20km);
			newSpeedReport.setTimeIn21To30km(timeIn21To30km);
			newSpeedReport.setTimeIn31To40km(timeIn31To40km);
			newSpeedReport.setTimeIn41To50km(timeIn41To50km);
			newSpeedReport.setTimeIn41To50km(timeIn41To50km);
			newSpeedReport.setTimeIn51To60km(timeIn51To60km);
			newSpeedReport.setTimeIn61To70km(timeIn61To70km);
			newSpeedReport.setTimeIn71To80km(timeIn71To80km);
			newSpeedReport.setTimeIn81To90km(timeIn81To90km);
			newSpeedReport.setTimeIn91To100km(timeIn91To100km);
			newSpeedReport.setTimeInOver110km(timeInOver110km);
			newSpeedReport.setTotalDistance(totalDistance);
			newSpeedReport.setVehicleId(vehicleId);
			newSpeedReport.setUpdatedTime(DicvUtil.getCurrentTimeStamp());
			speedReportRepo.save(newSpeedReport);
		} catch (Exception ex) {
			LOGGER.error("Speed Report Exception  ", ex);
		}
	}

	private Integer getVehicleStop(Long vehId, Date fromDate, Date toDate) {
		Long stop = 0l;
		try {
			stop = tripStopRepo.getStopCount(vehId, fromDate, toDate);
		} catch (Exception ex) {
			LOGGER.error("Exception while Soppings Vehicle :: " + vehId, ex);
			return 0;
		}
		return stop.intValue();
	}

	@Transactional
	private void saveVehiUtilization(Date fromDate, Vehicle veh, Long vehicleTotalIdleTime, Integer vehNoOfStops,
			Long vehicleMaxIdleTime, Double vehMaxIdleLatitude, Double vehMaxIdleLongitude, Double vehCurLatitude,
			Double vehCurLongitude, Double vehMaxSpeed, Double avgSpeed, Double vehicleUtilization,
			Double vehicleDistanceSum, Long engineOnTime, Long engineRunTime, Double vehMaxSpeedLatitude,
			Double vehMaxSpeedLongitude) {
		VehicleUtilization vehUtil = vehicleUtilizationRepo.getVehicleUtilization(veh.getVehicleId(), fromDate);
		if (vehUtil == null) {
			vehUtil = new VehicleUtilization();
		}
		vehUtil.setVehicleId(veh.getVehicleId());
		vehUtil.setCurrentLat(vehCurLatitude);
		vehUtil.setUserId(veh.getUserId());
		vehUtil.setCurrentLong(vehCurLongitude);
		vehUtil.setMaximumSpeed(vehMaxSpeed);
		vehUtil.setReportDate(fromDate);
		vehUtil.setTotalDistance(vehicleDistanceSum);
		vehUtil.setTotalUpTime(engineOnTime);
		vehUtil.setTotalDrivingTime(engineRunTime);
		vehUtil.setMaximumSpeed(vehMaxSpeed);
		vehUtil.setAverageSpeed(avgSpeed);
		vehUtil.setMaxIdleLongtitude(vehMaxIdleLongitude);
		vehUtil.setMaxIdleLatitude(vehMaxIdleLatitude);
		vehUtil.setTotalIdleTime(vehicleTotalIdleTime);
		vehUtil.setUtilization(vehicleUtilization);
		vehUtil.setMaxIdleTime(vehicleMaxIdleTime);
		vehUtil.setNoOfStops(vehNoOfStops);
		vehUtil.setMaxSpeedLat(vehMaxSpeedLatitude);
		vehUtil.setMaxSpeedLong(vehMaxSpeedLongitude);
		vehUtil.setRecordTimestamp(DicvUtil.getTimestamp());
		Address address = addressUtil.getAddress(vehMaxIdleLatitude, vehMaxIdleLongitude);
		if (address.getResponse())
			vehUtil.setIdleLocation(address.getAddress());
		address = addressUtil.getAddress(vehMaxSpeedLatitude, vehMaxSpeedLongitude);
		if (address.getResponse())
			vehUtil.setSpeedLocation(address.getAddress());
		vehicleUtilizationRepo.save(vehUtil);

	}

	private boolean checkGpsNullValue(GpsVehParameterDto gpsVehicleParam, GpsVehParameterDto gpsVehicleParamNext) {
		if (gpsVehicleParam.getGpsLatitude() == null || gpsVehicleParam.getGpsLongitude() == null
				|| gpsVehicleParam.getGpsSpkm() == null || gpsVehicleParam.getGpsTime() == null
				|| gpsVehicleParam.getEngineON() == null || gpsVehicleParamNext.getGpsLatitude() == null
				|| gpsVehicleParamNext.getGpsLongitude() == null || gpsVehicleParamNext.getGpsSpkm() == null
				|| gpsVehicleParamNext.getGpsTime() == null || gpsVehicleParamNext.getEngineON() == null) {
			return false;
		}
		return true;
	}

	private Double roundOffDecimal(Double driverScore) {
		if (driverScore > 0)
			driverScore = Math.round(driverScore * 100D) / 100D;
		return driverScore;
	}

	private Double checkNullValue(Double value1, Double value2) {
		value1 = value1 == null ? 0d : value1;
		value2 = value2 == null ? 0d : value2;
		return value1 + value2;
	}

	private void sendEmail(String subject, String msg) {
		sendMailService.sendMail("paras.dicv@gmail.com", "harikrishnan.d@contus.in", subject,
				msg + " For  " + new Date());
	}

}
