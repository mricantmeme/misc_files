package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.BatteryDisconnect;

@Repository
public interface BatteryDisconnectRepo extends JpaRepository<BatteryDisconnect, Long> {

}
