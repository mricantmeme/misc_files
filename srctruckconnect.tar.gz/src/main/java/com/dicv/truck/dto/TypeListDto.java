package com.dicv.truck.dto;

import java.util.List;

public class TypeListDto extends StatusMessageDto {

	private List<TypeDto> typeList;

	public List<TypeDto> getTypeList() {
		return typeList;
	}

	public void setTypeList(List<TypeDto> typeList) {
		this.typeList = typeList;
	}



}
