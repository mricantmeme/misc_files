package com.dicv.cwp.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.VehicleEventReport;

@Repository
public interface VehicleEventReportRepo extends JpaRepository<VehicleEventReport, Long> {

	@Transactional
	@Modifying
	@Query("delete VehicleEventReport t where t.gpsDate=:gpsDate")
	public void deleteReport(@Param("gpsDate") Date gpsDate);

}
