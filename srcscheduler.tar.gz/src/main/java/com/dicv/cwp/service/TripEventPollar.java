package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.GpsLastProcessParam;
import com.dicv.cwp.dao.model.Trip;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.repository.GpsLastProcessRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.TripRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvConstant;
import com.dicv.cwp.utils.DicvUtil;

@Service
public class TripEventPollar {

	private static final Logger LOGGER = LoggerFactory.getLogger(TripEventPollar.class);

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Autowired
	private TripRepo tripRepo;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private GpsLastProcessRepo gpsLastProcessRepo;

	@Value("${trip_event_pollar}")
	private String tripPollar;

	@Value("${tripPollarCondition}")
	private String tripPollarCondition;

	@Value("${trip_page_count}")
	private Integer tripPageCount;

	@Scheduled(fixedDelay = 1000)
	public void tripStartStop() {

		if (tripPollar.equals("Yes")) {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			List<Vehicle> vehList = null;
			LOGGER.info("Trip Start/Stop Started in :: " + LocalDateTime.now());
			if (tripPollarCondition == "Yes") {
				vehList = vehicleRepo.getAllVehicleByTripTime(new PageRequest(0, tripPageCount));
			} else {
				vehList = vehicleRepo.getAllVehicle();
			}
			GpsLastProcessParam gpsProcess = gpsLastProcessRepo.findAll().get(0);
			for (Vehicle veh : vehList) {
				try {
					processVehicleTrip(gpsProcess, veh);
				} catch (Exception ex) {
					LOGGER.error("Exception in Processing Vehicle " + veh.getVehicleId(), ex);
					continue;
				}
			}
			stopWatch.stop();
			LOGGER.info("Trip Start/Stop Completed in :: " + stopWatch.getTotalTimeSeconds() + " sec");
		}

	}

	@Transactional
	private void processVehicleTrip(GpsLastProcessParam gpsProcess, Vehicle veh) {
		List<Trip> trip = tripRepo.getActiveTripByVehicle(veh.getVehicleId(), DicvConstant.VEH_STATUS_RUNNING);
		if (veh.getLastProcessedGpsTime() == null)
			veh.setLastProcessedGpsTime(DicvUtil.getCurrentTimeStamp());
		Date lastPolledTime = new Date(veh.getLastProcessedGpsTime().getTime());
		Date newLastPolledTime = new Date(veh.getLastProcessedGpsTime().getTime());
		if (trip != null && trip.size() > 0) {
			newLastPolledTime = runningTripAvailable(gpsProcess, veh, trip, lastPolledTime, newLastPolledTime);
		} else {
			newLastPolledTime = noRunningTrip(veh, lastPolledTime, newLastPolledTime);
		}
		vehicleRepo.updateLastUpdatedTime(new Timestamp(newLastPolledTime.getTime()), veh.getVehicleId());
	}

	private Date runningTripAvailable(GpsLastProcessParam gpsProcess, Vehicle veh, List<Trip> trip, Date lastPolledTime,
			Date newLastPolledTime) {
		List<GpsParameterDto> latestGpsEngineData;
		List<GpsParameterDto> gpsParamData;
		// Check FirstEngineOFF
		gpsParamData = gpsVehicleRepo.getGPSParamForTripPollar(veh.getGpsImei().getGpsImei(), lastPolledTime, 0,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0) {
			newLastPolledTime = checkEngineNextON(gpsProcess, veh, gpsParamData);
		} else {
			// No EngineOff for Vehicle
			latestGpsEngineData = gpsVehicleRepo.getMaxofGpsParameter(veh.getGpsImei().getGpsImei(), 1,
					new PageRequest(0, 1));
			if (latestGpsEngineData != null && latestGpsEngineData.size() > 0)
				newLastPolledTime = latestGpsEngineData.get(0).getGpsTime();

		}
		return newLastPolledTime;
	}

	private Date checkEngineNextON(GpsLastProcessParam gpsProcess, Vehicle veh, List<GpsParameterDto> gpsParamData) {
		Date newLastPolledTime = new Date(veh.getLastProcessedGpsTime().getTime());
		Date timeDiff;
		GpsParameterDto gpsDto;
		List<GpsParameterDto> latestGpsEngineData;
		// check Next EngineON
		timeDiff = new Date(veh.getLastProcessedGpsTime().getTime() + gpsProcess.getTripWaitTime());
		gpsDto = gpsParamData.get(0);
		latestGpsEngineData = gpsVehicleRepo.getGPSParamForTripPollar(veh.getGpsImei().getGpsImei(),
				gpsDto.getGpsTime(), 1, new PageRequest(0, 1));
		if (latestGpsEngineData != null && latestGpsEngineData.size() > 0) {
			newLastPolledTime = latestGpsEngineData.get(0).getGpsTime();
			if (latestGpsEngineData.get(0).getGpsTime().getTime() >= timeDiff.getTime()) {
				gpsDto = gpsParamData.get(0);
				closeTrip(veh.getDefaultDriverUserId(), veh.getVehicleId(), gpsDto.getGpsParamId(),
						gpsDto.getLatitude(), gpsDto.getLongitude(), gpsDto.getGpsTime());
			}
		} else {
			latestGpsEngineData = gpsVehicleRepo.getGPSParamForTripPollarByTimeDiff(veh.getGpsImei().getGpsImei(),
					timeDiff, new PageRequest(0, 1));
			// Close Trip
			if (latestGpsEngineData != null && latestGpsEngineData.size() > 0) {
				gpsDto = gpsParamData.get(0);
				newLastPolledTime = gpsParamData.get(0).getGpsTime();
				closeTrip(veh.getDefaultDriverUserId(), veh.getVehicleId(), gpsDto.getGpsParamId(),
						gpsDto.getLatitude(), gpsDto.getLongitude(), gpsDto.getGpsTime());
			}
		}
		return newLastPolledTime;
	}

	private Date noRunningTrip(Vehicle veh, Date lastPolledTime, Date newLastPolledTime) {
		GpsParameterDto gpsDto;
		List<GpsParameterDto> latestGpsEngineData;
		List<GpsParameterDto> gpsParamData;
		// No Running Trip
		gpsParamData = gpsVehicleRepo.getGPSParamForTripPollar(veh.getGpsImei().getGpsImei(), lastPolledTime, 1,
				new PageRequest(0, 1));
		if (gpsParamData != null && gpsParamData.size() > 0) {
			// Create Trip
			gpsDto = gpsParamData.get(0);
			newLastPolledTime = gpsParamData.get(0).getGpsTime();
			createTrip(veh.getDefaultDriverUserId(), veh.getVehicleId(), gpsDto.getGpsParamId(), gpsDto.getLatitude(),
					gpsDto.getLongitude(), gpsDto.getGpsTime());
		} else {
			// No EngineOff for Vehicle
			latestGpsEngineData = gpsVehicleRepo.getMaxofGpsParameter(veh.getGpsImei().getGpsImei(), 0,
					new PageRequest(0, 1));
			if (latestGpsEngineData != null && latestGpsEngineData.size() > 0)
				newLastPolledTime = latestGpsEngineData.get(0).getGpsTime();
		}
		return newLastPolledTime;
	}

	// Save Trip
	public void createTrip(Integer userId, Long vehicleId, Long gpsParamId, Double latitude, Double longitude,
			Date gpsTime) {
		try {
			Trip trip = new Trip();
			trip.setCreatedDate(DicvUtil.getTimestamp());
			trip.setStartGpsParamId(gpsParamId);
			trip.setStartLocationLat(latitude);
			trip.setVehicleId(vehicleId);
			trip.setStartLocationLong(longitude);
			trip.setTripStatus(DicvConstant.VEH_STATUS_RUNNING);
			trip.setIsDeleted(0);
			trip.setTripStartTime(new Timestamp(gpsTime.getTime()));
			trip.setUserId(userId);
			trip.setGeoResponse(0);
			trip.setLastUpdateRecvdTime(new Timestamp(gpsTime.getTime()));
			trip.setProcessStatus(1);
			trip.setScheduledTripId(null);
			trip = tripRepo.save(trip);
		} catch (Exception ex) {
			LOGGER.info("Exception in Creating Trip  ", ex);

		}
	}

	// Close Trip
	public void closeTrip(Integer userId, Long vehicleId, Long gpsParamId, Double latitude, Double longitude,
			Date gpsTime) {
		try {
			List<Trip> list = tripRepo.getActiveTripByVehicle(vehicleId, DicvConstant.VEH_STATUS_RUNNING);
			if (list != null) {
				for (Trip trip : list) {
					try {
						saveCloseTrip(gpsParamId, latitude, longitude, gpsTime, trip);
					} catch (Exception ex) {
						LOGGER.error("Exception in Closing Trip " + trip.getTripId(), ex);
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.info("Exception in Closing Trip  ", ex);
		}
	}

	private void saveCloseTrip(Long gpsParamId, Double latitude, Double longitude, Date gpsTime, Trip trip) {
		trip.setModifiedDate(DicvUtil.getTimestamp());
		trip.setStopGpsParamId(gpsParamId);
		trip.setStopLocationLat(latitude);
		trip.setStopLocationLong(longitude);
		trip.setProcessStatus(2);
		trip.setGeoResponse(1);
		trip.setTripStatus(DicvConstant.TRIPSTATUS_COMPLETED);
		trip.setTripEndTime(new Timestamp(gpsTime.getTime()));
		trip.setLastUpdateRecvdTime(new Timestamp(gpsTime.getTime()));
		tripRepo.save(trip);
	}

}
