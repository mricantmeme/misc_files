package com.dicv.cwp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.DicvUser;

@Repository
public interface DicvUserRepo extends CrudRepository<DicvUser, Integer> {

	@Query("Select v.email from DicvUser v where v.userId=:userId and v.recordStatus!='d'")
	public String getUserEmailAddress(@Param("userId") Integer userId);

	@Query("Select v.userId from DicvUser v where v.userType.userType=:userType and v.recordStatus!='d'")
	public List<Integer> getAllDriverList(@Param("userType") String userType);

}
