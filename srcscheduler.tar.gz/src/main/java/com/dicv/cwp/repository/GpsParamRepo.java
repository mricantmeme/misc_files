package com.dicv.cwp.repository;

import java.sql.Timestamp;
import java.util.Date;

import com.dicv.cwp.dto.GpsVehParameterDto;

public interface GpsParamRepo {

	public Integer countofHarshEvents(Timestamp startTime, Timestamp endTime, Long imeiNo, String harshName);

	public GpsVehParameterDto getGpsStopLocation(long imeiNo, Date startParamTime, Date lastStopTime, Date lastParamTime,boolean start);

}
