package com.dicv.cwp.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the GEO_FENCE_REPORT database table.
 * 
 */
@Entity
@Table(name = "GEO_FENCE_REPORT")
public class GeoFenceReport implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GEO_FENCE_REPORT_GENERATOR", sequenceName = "GEO_FENCE_REPORT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GEO_FENCE_REPORT_GENERATOR")
	@Column(name = "GEO_FENCE_REPORT_ID")
	private Long geoFenceReportId;

	@Column(name = "VEHICLE_ID")
	private Long vehicleId;

	@Column(name = "USER_ID")
	private Integer userId;

	@Column(name = "GEO_FENCE_ID")
	private Integer geoFenceId;

	@Column(name = "GEO_SYSTIMESTAMP")
	private Timestamp geoSystimestamp;

	@Column(name = "GEO_FENCE_ENTRY_TIME")
	private Timestamp geoFenceEntryTime;

	@Column(name = "GEO_FENCE_EXIT_TIME")
	private Timestamp geoFenceExitTime;

	@Column(name = "TIME_SPENT")
	private String time_spent;

	@Column(name = "VEHICLE_ENTRY")
	private Integer vehicleEntry;

	public Long getGeoFenceReportId() {
		return geoFenceReportId;
	}

	public void setGeoFenceReportId(Long geoFenceReportId) {
		this.geoFenceReportId = geoFenceReportId;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getGeoFenceId() {
		return geoFenceId;
	}

	public void setGeoFenceId(Integer geoFenceId) {
		this.geoFenceId = geoFenceId;
	}

	public Timestamp getGeoSystimestamp() {
		return geoSystimestamp;
	}

	public void setGeoSystimestamp(Timestamp geoSystimestamp) {
		this.geoSystimestamp = geoSystimestamp;
	}

	public Timestamp getGeoFenceEntryTime() {
		return geoFenceEntryTime;
	}

	public void setGeoFenceEntryTime(Timestamp geoFenceEntryTime) {
		this.geoFenceEntryTime = geoFenceEntryTime;
	}

	public Timestamp getGeoFenceExitTime() {
		return geoFenceExitTime;
	}

	public void setGeoFenceExitTime(Timestamp geoFenceExitTime) {
		this.geoFenceExitTime = geoFenceExitTime;
	}

	public String getTime_spent() {
		return time_spent;
	}

	public void setTime_spent(String time_spent) {
		this.time_spent = time_spent;
	}

	public Integer getVehicleEntry() {
		return vehicleEntry;
	}

	public void setVehicleEntry(Integer vehicleEntry) {
		this.vehicleEntry = vehicleEntry;
	}
	
	
	
	
	

}