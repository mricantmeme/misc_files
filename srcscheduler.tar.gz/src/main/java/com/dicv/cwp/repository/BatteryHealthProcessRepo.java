package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.BatteryHealthProcess;

@Repository
public interface BatteryHealthProcessRepo extends JpaRepository<BatteryHealthProcess, Long> {

	@Query("select f from BatteryHealthProcess f where f.vehicleId=:veicleId ")
	public BatteryHealthProcess getBatteryHealthProcess(@Param("veicleId") Long vehicleId);
}
