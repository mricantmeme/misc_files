package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.TripSpeedingLocations;

@Repository
public interface TripSeedingLocationsRepo extends CrudRepository<TripSpeedingLocations, Long> {

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("delete TripSpeedingLocations t where t.tripId=:tripId")
	public void deleteTripSpeedingLocations(@Param("tripId") Long tripId);

}
