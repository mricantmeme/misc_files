package com.dicv.cwp.dto;

import java.sql.Timestamp;

public class AlertSettingDto {

	private Long vehicleId;

	private String userEmail;

	private String vehicleName;

	private Integer fromValue;

	private Integer toValue;

	private Integer battteryHealth;

	private Boolean isBatteryHealth;

	private Timestamp gpsTime;

	private Double gpsLatitude;

	private Double gpsLongitude;

	public AlertSettingDto() {
		super();
	}

	public AlertSettingDto(Long vehicleId, String userEmail, String vehicleName, Integer fromValue, Integer toValue,
			Boolean isBatteryHealth, Timestamp gpsTime) {
		super();
		this.vehicleId = vehicleId;
		this.userEmail = userEmail;
		this.vehicleName = vehicleName;
		this.fromValue = fromValue;
		this.toValue = toValue;
		this.isBatteryHealth = isBatteryHealth;
		this.gpsTime = gpsTime;
	}

	public AlertSettingDto(Long vehicleId, String vehicleName, Timestamp gpsTime, Integer battteryHealth) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
		this.gpsTime = gpsTime;
		this.battteryHealth = battteryHealth;
	}

	public AlertSettingDto(Long vehicleId, String userEmail, String vehicleName, Timestamp gpsTime) {
		super();
		this.vehicleId = vehicleId;
		this.userEmail = userEmail;
		this.vehicleName = vehicleName;
		this.gpsTime = gpsTime;
	}

	public AlertSettingDto(Long vehicleId, String userEmail, String vehicleName, Integer fromValue, Integer toValue,
			Integer battteryHealth, Boolean isBatteryHealth, Timestamp gpsTime, Double gpsLatitude,
			Double gpsLongitude) {
		super();
		this.vehicleId = vehicleId;
		this.userEmail = userEmail;
		this.vehicleName = vehicleName;
		this.fromValue = fromValue;
		this.toValue = toValue;
		this.battteryHealth = battteryHealth;
		this.isBatteryHealth = isBatteryHealth;
		this.gpsTime = gpsTime;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public AlertSettingDto(Long vehicleId, String userEmail, String vehicleName, Integer fromValue, Integer toValue,
			Boolean isBatteryHealth, Timestamp gpsTime, Double gpsLatitude, Double gpsLongitude) {
		super();
		this.vehicleId = vehicleId;
		this.userEmail = userEmail;
		this.vehicleName = vehicleName;
		this.fromValue = fromValue;
		this.toValue = toValue;
		this.isBatteryHealth = isBatteryHealth;
		this.gpsTime = gpsTime;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public Long getVehicleId() {
		return vehicleId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public Timestamp getGpsTime() {
		return gpsTime;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public void setGpsTime(Timestamp gpsTime) {
		this.gpsTime = gpsTime;
	}

	public Boolean getIsBatteryHealth() {
		return isBatteryHealth;
	}

	public void setIsBatteryHealth(Boolean isBatteryHealth) {
		this.isBatteryHealth = isBatteryHealth;
	}

	public Integer getFromValue() {
		return fromValue;
	}

	public void setFromValue(Integer fromValue) {
		this.fromValue = fromValue;
	}

	public Integer getToValue() {
		return toValue;
	}

	public void setToValue(Integer toValue) {
		this.toValue = toValue;
	}

	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	@Override
	public String toString() {
		return "AlertSettingDto [vehicleId=" + vehicleId + ", userEmail=" + userEmail + ", vehicleName=" + vehicleName
				+ ", fromValue=" + fromValue + ", toValue=" + toValue + ", isBatteryHealth=" + isBatteryHealth
				+ ", gpsTime=" + gpsTime + ", gpsLatitude=" + gpsLatitude + ", gpsLongitude=" + gpsLongitude + "]";
	}

	public Integer getBattteryHealth() {
		return battteryHealth;
	}

	public void setBattteryHealth(Integer battteryHealth) {
		this.battteryHealth = battteryHealth;
	}

}
