package com.dicv.cwp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.GeoFenceInfo;

@Repository
public interface GeoFenceInfoRepo extends CrudRepository<GeoFenceInfo,Integer>{

}
