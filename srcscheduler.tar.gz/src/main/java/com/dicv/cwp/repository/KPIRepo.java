package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dicv.cwp.dao.model.KPIScalingFactor;

public interface KPIRepo extends JpaRepository<KPIScalingFactor, Integer> {

}
