package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.AlertType;
import com.dicv.cwp.dao.model.GeoFenceInfo;
import com.dicv.cwp.dao.model.GeoFenceReport;
import com.dicv.cwp.dao.model.GpsLastProcessParam;
import com.dicv.cwp.dao.model.VehicleToGeoFence;
import com.dicv.cwp.dto.GeoFenceGpsDto;
import com.dicv.cwp.dto.GeogatePoint;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.AlertTypeRepo;
import com.dicv.cwp.repository.GeoFenceReportRepo;
import com.dicv.cwp.repository.GpsLastProcessRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.VehicleToGeoFenceRepo;
import com.dicv.cwp.utils.DicvUtil;

@Service
public class GeoFenceAlertService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GeoFenceAlertService.class);

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private AlertTypeRepo alertRepo;

	@Autowired
	private VehicleToGeoFenceRepo vehicleGeoRepo;

	@Autowired
	private GeoFenceReportRepo geoFenceReportRepo;

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Autowired
	private GpsLastProcessRepo gpsLastProcessRepo;

	@Value("${geo_fence_alert}")
	private String geoFenceAlert;

	@Scheduled(fixedDelay = 1000)
	public void sendGeoFence() {
		if (geoFenceAlert.equals("Yes")) {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			try {
				Map<Long, VehicleListDto> map = getVehicleMapWithGeoFence();
				if (map == null || map.keySet() == null || map.keySet().isEmpty())
					return;

				processGeoFence(map);

			} catch (Exception ex) {
				LOGGER.error("Geo Fence Alert Exception :: ", ex);
			}
			stopWatch.stop();
			LOGGER.info(
					"Geo Fence Alert  Vehicle Completed ::  TimeTaken in Seconds = " + stopWatch.getTotalTimeSeconds());
		}
	}

	@Transactional
	private void processGeoFence(Map<Long, VehicleListDto> map) {
		GpsLastProcessParam lastParam = gpsLastProcessRepo.findAll().get(0);
		List<GeoFenceGpsDto> geoList = gpsVehicleRepo.fetchGpsDataForGeoFenceAlert(lastParam.getLastProcessedFenceId(),
				new ArrayList<Long>(map.keySet()), new PageRequest(0, 1500));
		if (geoList != null && geoList.size() > 0) {
			Long paramId = geoList.get(0).getGpsVehicleParamId();
			for (GeoFenceGpsDto geo : geoList) {
				try {
					if (map.get(geo.getGpsImei()) != null) {
						List<VehicleToGeoFence> geoFenceList = vehicleGeoRepo.getVehicleGeoFenceInfoList(
								map.get(geo.getGpsImei()).getVehicleId(), DicvUtil.getEndTime(new Date()));
						if (geoFenceList != null && !geoFenceList.isEmpty())
							checkGeoFenceLocation(map.get(geo.getGpsImei()).getVehicleId(), geo.getGpsLatitude(),
									geo.getGpsLongitude(), geo.getGpsTime(),
									map.get(geo.getGpsImei()).getRegistrationId(), geoFenceList);
					}
					paramId = geo.getGpsVehicleParamId();
				} catch (Exception ex) {
					LOGGER.error("Geo Fence Alert Exception :: ", ex);
					continue;
				}
			}
			gpsLastProcessRepo.updateProcessStatus(paramId);
		}
	}

	private Map<Long, VehicleListDto> getVehicleMapWithGeoFence() {
		List<VehicleListDto> list = vehicleGeoRepo.getVehicleListGeoFence(DicvUtil.getEndTime(new Date()));
		if (list == null || list.isEmpty()) {
			LOGGER.info("Empty Geo Fence  ");
			return null;
		}
		Map<Long, VehicleListDto> map = new HashMap<Long, VehicleListDto>();
		for (VehicleListDto veh : list) {
			map.put(veh.getGpsImei(), veh);
		}
		return map;
	}

	private void checkGeoFenceLocation(Long vehicleId, Double gpsLatitude, Double gpsLongitude, Date gpsTime,
			String regId, List<VehicleToGeoFence> geoList) {
		try {

			Integer vehicleInsideNow = null;
			for (VehicleToGeoFence vehGeo : geoList) {
				try {
					vehicleInsideNow = null;
					if (vehGeo.getGeoFenceInfo().getGeoFenceShape().getGeoFenceShapeName().toUpperCase()
							.equalsIgnoreCase("CIRCLE")) {
						vehicleInsideNow = circleFence(gpsLatitude, gpsLongitude, vehGeo.getGeoFenceInfo());
					} else if (vehGeo.getGeoFenceInfo().getGeoFenceShape().getGeoFenceShapeName().toUpperCase()
							.equalsIgnoreCase("POLYGON")) {
						vehicleInsideNow = polygonFence(gpsLatitude, gpsLongitude, vehGeo.getGeoFenceInfo());
					}
					if (vehGeo.getIsVehicleInside() == 0 && vehicleInsideNow == 0) {
						continue;
					}
					if (vehGeo.getIsVehicleInside() == 1 && vehicleInsideNow == 0) {
						exitingTheFence(vehicleId, gpsTime, vehGeo, vehicleInsideNow, regId, gpsLatitude, gpsLongitude);
					} else if (vehGeo.getIsVehicleInside() == 0 && vehicleInsideNow == 1) {
						enteringTheFence(vehicleId, gpsTime, vehGeo, vehicleInsideNow, regId, gpsLatitude,
								gpsLongitude);
					}
				} catch (Exception ex) {
					LOGGER.error("Exception in Vehicle Check with Geo Fence :: " + vehicleId + " " + vehGeo, ex);
					return;
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Exception in Check Geo Fence :: " + vehicleId, ex);
			return;
		}
	}

	private void exitingTheFence(Long vehicleId, Date gpsTime, VehicleToGeoFence vehGeo, Integer vehicleInsideNow,
			String regId, Double gpsLatitude, Double gpsLongitude) {
		try {
			vehicleGeoRepo.updateVehicleToGeoFence(vehicleId, vehGeo.getVehGeoFenceId(), vehicleInsideNow,
					DicvUtil.getTimestamp());
			if (vehGeo.getGeoFenceInfo().getExitAlert()) {
				List<AlertType> typeList = alertRepo.getAlertTypeByType("GEOFENCE_OUT");
				if (typeList != null && typeList.size() > 0) {
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh:mm a");
					String msg = sdf.format(gpsTime) + " " + regId + " exiting Geofence "
							+ vehGeo.getGeoFenceInfo().getGeoFenceName();
					notificationService.sendGeoFenceAlert(vehicleId.intValue(),
							vehGeo.getGeoFenceInfo().getDicvUser().getUserId(), gpsTime, typeList, msg, gpsLatitude,
							gpsLongitude);
				}
			}
			List<GeoFenceReport> geoFenceReport = geoFenceReportRepo.getGeoFenceReport(vehicleId,
					vehGeo.getGeoFenceInfo().getDicvUser().getUserId(), vehGeo.getGeoFenceInfo().getGeoFenceId(),
					new PageRequest(0, 1));
			if (geoFenceReport == null || geoFenceReport.isEmpty()) {
				saveExitGeoFenceReport(vehicleId, gpsTime, vehGeo, 1);
			} else {
				geoFenceReport.get(0).setGeoFenceExitTime(new Timestamp(gpsTime.getTime()));
				if (geoFenceReport.get(0).getGeoFenceEntryTime() != null) {
					Long time = (geoFenceReport.get(0).getGeoFenceExitTime().getTime()
							- geoFenceReport.get(0).getGeoFenceEntryTime().getTime()) / 1000;
					geoFenceReport.get(0).setTime_spent(time.toString());
				}
				geoFenceReportRepo.save(geoFenceReport.get(0));
			}

		} catch (Exception ex) {
			LOGGER.error("Exception in Exiting Fence ", ex);
		}
	}

	private void enteringTheFence(Long vehicleId, Date gpsTime, VehicleToGeoFence vehGeo, Integer vehicleInsideNow,
			String regId, Double gpsLatitude, Double gpsLongitude) {
		try {
			vehicleGeoRepo.updateVehicleToGeoFence(vehicleId, vehGeo.getVehGeoFenceId(), vehicleInsideNow,
					DicvUtil.getTimestamp());
			if (vehGeo.getGeoFenceInfo().getEntryAlert()) {
				List<AlertType> typeList = alertRepo.getAlertTypeByType("GEOFENCE_IN");
				if (typeList != null && typeList.size() > 0) {
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh:mm a");
					String msg = sdf.format(gpsTime) + " " + regId + " entering Geofence "
							+ vehGeo.getGeoFenceInfo().getGeoFenceName();
					notificationService.sendGeoFenceAlert(vehicleId.intValue(),
							vehGeo.getGeoFenceInfo().getDicvUser().getUserId(), gpsTime, typeList, msg, gpsLatitude,
							gpsLongitude);
				}
			}
			saveEntryGeoFenceReport(vehicleId, gpsTime, vehGeo, 1);
		} catch (Exception ex) {
			LOGGER.error("Exception in Entering Fence ", ex);
		}
	}

	private void saveExitGeoFenceReport(Long vehicleId, Date gpsTime, VehicleToGeoFence vehGeo, Integer vehicleEntry) {
		GeoFenceReport report = new GeoFenceReport();
		report.setGeoFenceExitTime(new Timestamp(gpsTime.getTime()));
		report.setGeoFenceId(vehGeo.getGeoFenceInfo().getGeoFenceId());
		report.setGeoSystimestamp(DicvUtil.getTimestamp());
		report.setUserId(vehGeo.getGeoFenceInfo().getDicvUser().getUserId());
		report.setVehicleId(vehicleId);
		report.setVehicleEntry(vehicleEntry);
		geoFenceReportRepo.save(report);
	}

	private void saveEntryGeoFenceReport(Long vehicleId, Date gpsTime, VehicleToGeoFence vehGeo, Integer vehicleEntry) {
		GeoFenceReport report = new GeoFenceReport();
		report.setGeoFenceEntryTime(new Timestamp(gpsTime.getTime()));
		report.setGeoFenceId(vehGeo.getGeoFenceInfo().getGeoFenceId());
		report.setGeoSystimestamp(DicvUtil.getTimestamp());
		report.setUserId(vehGeo.getGeoFenceInfo().getDicvUser().getUserId());
		report.setVehicleId(vehicleId);
		report.setVehicleEntry(vehicleEntry);
		geoFenceReportRepo.save(report);
	}

	private Integer circleFence(Double gpsLatitude, Double gpsLongitude, GeoFenceInfo geo) {
		try {
			Integer fencePositionOut = 0;
			Double radius;
			Double vehicleDistance;
			vehicleDistance = distance(gpsLatitude, gpsLongitude, geo.getGeoFenceCircle().getGeoLatitude(),
					geo.getGeoFenceCircle().getGeoLongitude());

			radius = geo.getGeoFenceCircle().getGeoRadiusInMeters() / 1000d;
			radius = roundOff3Decimal(radius);

			if (vehicleDistance > radius) {
				fencePositionOut = 0;

			} else {
				fencePositionOut = 1;
			}
			return fencePositionOut;
		} catch (Exception ex) {
			LOGGER.info("Exception in Circle Calc");
		}
		return null;

	}

	private Integer polygonFence(Double gpsLatitude, Double gpsLongitude, GeoFenceInfo geo) {
		try {
			Integer fencePositionOut = 0;
			List<String> points = Arrays.asList(geo.getGeoFencePolygon().getGeoCordinates().split("\\s*!\\s*"));
			List<GeogatePoint> geogatePoints = new ArrayList<GeogatePoint>();
			for (String st : points) {
				String split[] = st.split("\\s*,\\s*");
				geogatePoints.add(new GeogatePoint(Double.valueOf(split[0]), Double.valueOf(split[1])));
			}
			if (geogatePoints.isEmpty())
				return fencePositionOut;
			if (contains(gpsLatitude, gpsLongitude, geogatePoints)) {
				fencePositionOut = 1;
			} else {
				fencePositionOut = 0;
			}
			return fencePositionOut;
		} catch (Exception ex) {
			LOGGER.info("Exception in Polygon Calc");
		}
		return null;
	}

	public boolean contains(double lat, double lon, List<GeogatePoint> geogatePoints) {
		boolean c = false;
		int i = 0;
		int j = geogatePoints.size() - 1;
		for (GeogatePoint point : geogatePoints) {
			double lat_i = point.getLatitude();
			double lon_i = point.getLongitude();
			double lat_j = geogatePoints.get(j).getLatitude();
			double lon_j = geogatePoints.get(j).getLongitude();
			if (((lat_i > lat != (lat_j > lat)) && (lon < (lon_j - lon_i) * (lat - lat_i) / (lat_j - lat_i) + lon_i)))
				c = !c;
			j = i++;
		}
		return c;
	}

	private Double roundOff3Decimal(Double driverScore) {
		if (driverScore > 0)
			driverScore = Math.round(driverScore * 1000D) / 1000D;
		return driverScore;
	}

	private double distance(double lat1, double lon1, double lat2, double lon2) {

		double theta = lon1 - lon2;

		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
				+ Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));

		dist = Math.acos(dist);

		dist = rad2deg(dist);

		dist = dist * 60 * 1.1515;

		dist = dist * 1.609344;
		double valueRounded = Math.round(dist * 1000000D) / 1000000D;
		return (valueRounded);

	}

	private double deg2rad(double deg) {

		return (deg * Math.PI / 180.0);

	}

	private double rad2deg(double rad) {

		return (rad * 180.0 / Math.PI);

	}

}
