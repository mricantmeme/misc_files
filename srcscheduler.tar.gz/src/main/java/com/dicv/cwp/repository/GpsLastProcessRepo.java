package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dicv.cwp.dao.model.GpsLastProcessParam;

@Repository
public interface GpsLastProcessRepo extends JpaRepository<GpsLastProcessParam, Long> {

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update GpsLastProcessParam g set g.lastProcessedFenceId =:lastProcessedFenceId")
	public void updateProcessStatus(@Param("lastProcessedFenceId") Long lastProcessedFenceId);

}
