
package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.GpsLastProcessParam;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dao.model.VehicleCanParam;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.repository.GpsLastProcessRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.VehicleCanParamRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvConstant;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class GpsEventPollar {

	private static final Logger LOGGER = LoggerFactory.getLogger(GpsEventPollar.class);

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private VehicleCanParamRepo canParamRepo;

	@Autowired
	private GpsLastProcessRepo gpsLastProcessRepo;

	@Value("${gps_event_pollar}")
	private String gpsEventPollar;

	@Value("${offline_vehicle_close}")
	private String closeVehicle;

	@Scheduled(fixedDelay = 10000)
	public void startVehiclePollar() {

		if (gpsEventPollar.equals("Yes")) {
			LOGGER.info("Gps Event Pollar Running ");
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			List<Vehicle> vehList = vehicleRepo.getAllVehicle();
			GpsLastProcessParam gpsProcess = gpsLastProcessRepo.findAll().get(0);
			Date now = new Date();
			Date timeDiff = new Date(now.getTime() - (gpsProcess.getOffLineWaitTime()));
			LOGGER.info("Offline Wait Time " + timeDiff + " Total Vehicle " + vehList.size());
			VehicleCanParam canParam = new VehicleCanParam();
			String runningStatus = null;
			Timestamp gpsTime = null;
			Timestamp vehicleLastUpdateON = null;
			Timestamp lastEngineOnTime = null;
			List<VehicleCanParam> paramList = null;
			Integer speed = null;
			GpsParameterDto gpsVehicleParam = new GpsParameterDto();
			for (Vehicle vehicle : vehList) {

				try {
					canParam = new VehicleCanParam();
					gpsVehicleParam = new GpsParameterDto();
					if (vehicle.getGpsImei().getGpsImei() != null) {
						paramList = canParamRepo.getvehicleCanParam(vehicle.getVehicleId());
						if (paramList == null || paramList.isEmpty()) {
							canParam = saveCanParam(canParam, vehicle);
							paramList = canParamRepo.getvehicleCanParam(vehicle.getVehicleId());
						}
						if (paramList == null || paramList.isEmpty()) {
							continue;
						}
						canParam = paramList.get(0);

						List<GpsParameterDto> gpsParamData = gpsVehicleRepo
								.fetchVehicleGpsParam(vehicle.getGpsImei().getGpsImei(), new PageRequest(0, 1));

						if (gpsParamData != null && gpsParamData.size() > 0) {
							gpsVehicleParam = gpsParamData.get(0);
							if (!checkNullValue(gpsVehicleParam))
								continue;
							gpsTime = new Timestamp(gpsVehicleParam.getGpsTime().getTime());
							runningStatus = checkRunningStatus(timeDiff, gpsTime, gpsVehicleParam);
							vehicleLastUpdateON = canParam.getVehicleLastUpdateON();
							lastEngineOnTime = canParam.getLastEngineOnTime();
							if (gpsVehicleParam.getVehicleLastUpdateON() != null)
								vehicleLastUpdateON = new Timestamp(gpsVehicleParam.getVehicleLastUpdateON().getTime());
							if (gpsVehicleParam.getEngineON() == 1)
								lastEngineOnTime = gpsTime;
							speed = null;
							if (gpsVehicleParam.getGpsSpkm() != null)
								speed = gpsVehicleParam.getGpsSpkm().intValue();
							updateVehicle(runningStatus, vehicle, gpsVehicleParam, speed);
							updateVehicleParam(vehicleLastUpdateON, lastEngineOnTime, vehicle, gpsVehicleParam);

						}
					}
				} catch (PersistenceException ex) {
					LOGGER.info("PersistenceException in Vehicle Pollar  ", ex);
				} catch (Exception e) {
					LOGGER.info("Exception in Vehicle Pollar  " + vehicle, e);
				}
			}
			stopWatch.stop();
			LOGGER.info("Gps Event Pollar Completed in :: " + stopWatch.getTotalTimeSeconds() + " sec");
		}

	}

	private VehicleCanParam saveCanParam(VehicleCanParam canParam, Vehicle vehicle) {
		canParam.setVehicleId(vehicle.getVehicleId());
		canParam.setUpdatedDateTime(DicvUtil.getTimestamp());
		canParam = saveCanParam(canParam);
		return canParam;
	}

	@Transactional
	private void updateVehicleParam(Timestamp vehicleLastUpdateON, Timestamp lastEngineOnTime, Vehicle vehicle,
			GpsParameterDto gpsVehicleParam) {
		canParamRepo.updateVehicleParam(gpsVehicleParam.getCanEngineSpeed(), gpsVehicleParam.getCanCoolantTemp(),
				gpsVehicleParam.getFuelTankLevel(), gpsVehicleParam.getBatteryHealth(), lastEngineOnTime,
				vehicleLastUpdateON, DicvUtil.getTimestamp(), gpsVehicleParam.getAdblueLevel(), vehicle.getVehicleId());
	}

	@Transactional
	private void updateVehicle(String runningStatus, Vehicle vehicle, GpsParameterDto gpsVehicleParam, Integer speed) {
		vehicleRepo.updateVehicleStatus(runningStatus, gpsVehicleParam.getLatitude(), gpsVehicleParam.getLongitude(),
				speed, gpsVehicleParam.getGpsCog(), gpsVehicleParam.getGpsHdop(),
				new Timestamp(gpsVehicleParam.getGpsTime().getTime()), vehicle.getVehicleId());
	}

	private boolean checkNullValue(GpsParameterDto gpsVehicleParam) {
		if (gpsVehicleParam.getGpsImei() == null || gpsVehicleParam.getLatitude() == null
				|| gpsVehicleParam.getLongitude() == null || gpsVehicleParam.getGpsSpkm() == null
				|| gpsVehicleParam.getGpsTime() == null || gpsVehicleParam.getEngineON() == null)
			return false;
		return true;
	}

	private String checkRunningStatus(Date timeDiff, Timestamp gpsTime, GpsParameterDto gpsVehicleParam) {
		String runningStatus;
		if (gpsTime.getTime() <= timeDiff.getTime()) {
			runningStatus = (DicvConstant.VEH_STATUS_OFFLINE);
		} else {
			if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParam.getGpsSpkm() > 0) {
				runningStatus = DicvConstant.VEH_STATUS_RUNNING;
			} else if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParam.getGpsSpkm() == 0) {
				runningStatus = DicvConstant.VEH_STATUS_IDLE;
			} else {
				runningStatus = DicvConstant.VEH_STATUS_OFFLINE;
			}
		}
		return runningStatus;
	}

	@Transactional
	private VehicleCanParam saveCanParam(VehicleCanParam canParam) {
		try {
			canParam = canParamRepo.save(canParam);
		} catch (Exception ex) {
			LOGGER.error("Vehicle Param Not Saved :: " + ex);
		}
		return canParam;
	}

}
