/*package com.dicv.cwp.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.AlertSettings;
import com.dicv.cwp.dao.model.VehicleAlertHistory;
import com.dicv.cwp.dto.AlertSettingDto;
import com.dicv.cwp.dto.GpsParameterDto;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.dto.VehicleListDto;
import com.dicv.cwp.repository.AlertSettingsRepo;
import com.dicv.cwp.repository.DicvUserRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.utils.DicvUtil;

@Component
public class BatteryDisconnectAlert {

	@Autowired
	private VehicleRepo vehicleRepo;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private DicvUserRepo userRepo;

	@Autowired
	private VehicleAlertService vehicleAlertService;

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	@Value("${batter_disconnect}")
	private String batteryConnect;

	private static final Logger LOGGER = Logger.getLogger(BatteryDisconnectAlert.class);

	@Scheduled(fixedDelay = 60000, initialDelay = 60000)
	public void schedulerProcess() {
		try {
			if (batteryConnect != null && batteryConnect.equals("Yes")) {

				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				List<VehicleListDto> allVehicleList = vehicleRepo.loadAllVehicles();
				if (allVehicleList != null && allVehicleList.size() > 0) {
					for (VehicleListDto veh : allVehicleList) {
						try {
							processVehicleBatteryAlert(veh);
						} catch (Exception ex) {
							LOGGER.error("Exception Main Battery Disconnect Vehicle :: " + veh.getRegistrationId(), ex);
							continue;
						}
					}
				}
				stopWatch.stop();
				LOGGER.info("Main Battery Disconnect Vehicle Completed ::  TimeTaken in Seconds = "
						+ stopWatch.getTotalTimeSeconds());
			}
		} catch (Exception ex) {
			LOGGER.error("Main Battery Disconnect " + ex);
		}

	}

	private void processVehicleBatteryAlert(VehicleListDto veh) {
		try {
			if (veh.getGpsImei() != null) {
				VehicleAlertHistory vehicleAlert = vehicleAlertService.getVehicleAlertHistory(veh.getVehicleId(),
						veh.getGpsImei());

				if (vehicleAlert.getMainBatteryDetected() == null) {
					vehicleAlertService.updateBatteryDisconnect(DicvUtil.getCurrentTimeStamp(), veh.getVehicleId());
				} else {

					Timestamp newTime = new Timestamp(vehicleAlert.getMainBatteryDetected().getTime() + 300000);

					List<GpsVehParameterDto> gpsParamData = gpsVehicleRepo.getBatteryDisconnect(veh.getGpsImei(),
							newTime, new PageRequest(0, 1));
					if (gpsParamData != null && !gpsParamData.isEmpty()) {
						vehicleAlertService.updateBatteryDisconnect(
								new Timestamp(gpsParamData.get(0).getGpsTime().getTime()), veh.getVehicleId());

						notificationService.saveBatteryDisconnect(
								new AlertSettingDto(veh.getVehicleId(), null, veh.getRegistrationId(), null, null, null,
										null, new Timestamp(gpsParamData.get(0).getGpsTime().getTime()),
										gpsParamData.get(0).getGpsLatitude(), gpsParamData.get(0).getGpsLongitude()));

						notificationService.sendBatteryDisconnectEmail(new AlertSettingDto(veh.getVehicleId(),
								userRepo.getUserEmailAddress(veh.getUserId()), veh.getRegistrationId(),
								new Timestamp(gpsParamData.get(0).getGpsTime().getTime())));
					} else {
						List<GpsParameterDto> list = gpsVehicleRepo.getMaxofGpsParameterForAlert(veh.getGpsImei(),
								new PageRequest(0, 1));
						if (list != null && !list.isEmpty()) {
							vehicleAlertService.updateBatteryDisconnect(
									new Timestamp(list.get(0).getGpsTime().getTime()), veh.getVehicleId());
						}
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception while Main Battery Disconnect processing Vehicle :: " + veh.getRegistrationId(),
					ex);
		}
	}

}
*/