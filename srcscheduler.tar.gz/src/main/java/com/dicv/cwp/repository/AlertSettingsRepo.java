package com.dicv.cwp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dicv.cwp.dao.model.AlertSettings;
@Repository
public interface AlertSettingsRepo extends JpaRepository<AlertSettings, Integer> {

	@Query("select g from AlertSettings g")
	public AlertSettings getAlertSetings();

}
