package com.dicv.cwp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.dicv.cwp.dao.model.DicvUser;
import com.dicv.cwp.dao.model.DriverAnalysisList;
import com.dicv.cwp.dao.model.KPIScalingFactor;
import com.dicv.cwp.dao.model.Vehicle;
import com.dicv.cwp.dto.GpsVehParameterDto;
import com.dicv.cwp.repository.DicvUserRepo;
import com.dicv.cwp.repository.DriverAnalysisRepo;
import com.dicv.cwp.repository.GpsParamRepo;
import com.dicv.cwp.repository.GpsVehicleRepo;
import com.dicv.cwp.repository.KPIRepo;
import com.dicv.cwp.repository.VehicleRepo;
import com.dicv.cwp.service.SendMailService;
import com.dicv.cwp.utils.DicvUtil;
import com.dicv.cwp.utils.DistanceCalculation;
import com.dicv.cwp.utils.EnumUserType;

@Service
public class DriverAnalysis {

	@Autowired
	private DriverAnalysisRepo driverRepo;

	@Autowired
	private GpsParamRepo gpsRepo;

	@Autowired
	private VehicleRepo vehicleRepo;;

	@Autowired
	private KPIRepo kpiRepo;

	@Autowired
	private DicvUserRepo userRepo;

	@Value("${server_name}")
	private String serverName;

	@Value("${driver_analysis}")
	private String driverProcess;

	@Autowired
	private SendMailService sendMailService;

	@Autowired
	private GpsVehicleRepo gpsVehicleRepo;

	private static final Logger LOGGER = LoggerFactory.getLogger(DriverAnalysis.class);

	@Scheduled(cron = "0 0 4 * * *")
	public void startTripAnalysis() {
		if (driverProcess.equals("Yes")) {
			try {
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
				Date fromDate = sdf1.parse(DicvUtil.getPreviousStartOfDay(new Date()));
				Date toDate = sdf1.parse(DicvUtil.getPreviousEndOfDay(new Date()));
				process(fromDate, toDate, null);
			} catch (ParseException e) {
			}

		}
	}

	@Async
	public void fromController(Date fromDate, Integer driverId) {
		try {
			driverId = driverId == 0 ? null : driverId;
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HHmmss");
			Date previousDayStartTime = sdf1.parse(DicvUtil.getStartTimeOfDate(fromDate));
			Date previousDayEndTime = sdf1.parse(DicvUtil.getEndTimeOfDate(fromDate));
			process(previousDayStartTime, previousDayEndTime, driverId);
		} catch (Exception e) {
			LOGGER.error("Exception :: " + e.getMessage());
		}
	}

	@Transactional
	public void process(Date fromDate, Date toDate, Integer driverId) {
		String subject = "Driver Analysis Report :: " + serverName;
		StopWatch watch = new StopWatch();
		watch.start();
		LOGGER.info("Driver Analysis Received From Date" + fromDate);
		List<Integer> driverList = new ArrayList<Integer>();

		if (driverId != null) {
			driverList.add(driverId);
		} else {
			driverList = userRepo.getAllDriverList(EnumUserType.DRIVER.getUserType());
		}
		if (driverList == null || driverList.isEmpty()) {
			return;
		}
		KPIScalingFactor kpi = kpiRepo.findAll().get(0);

		for (Integer id : driverList) {
			try {
				DicvUser user = userRepo.findOne(id);
				if (user == null)
					continue;
				performDriverAnalysis(fromDate, toDate, kpi, user);
			} catch (Exception ex) {
				LOGGER.error("Exception Performing Driver  {}" + id + ex.getMessage());
				continue;
			}
		}
		watch.stop();
		sendEmail(subject,
				"Total time taken for completing report process :: " + watch.getTotalTimeSeconds() + " Seconds ");
	}

	private List<GpsVehParameterDto> getGpsParamData(Date fromDate, Date toDate, Vehicle veh, Date gpsParamTime) {
		List<GpsVehParameterDto> gpsParamData = (gpsParamTime == null)
				? gpsVehicleRepo.collectGpsParamDataforUtilization(veh.getGpsImei().getGpsImei().longValue(), fromDate,
						toDate, new PageRequest(0, 1000))
				: gpsVehicleRepo.collectGpsParamDataforUtilization(veh.getGpsImei().getGpsImei().longValue(), fromDate,
						toDate, gpsParamTime, new PageRequest(0, 1000));
		return gpsParamData;
	}

	private Long countTotalGpsParamData(Date fromDate, Date toDate, final Long gpsImei) {
		return gpsVehicleRepo.countofGpsParamDataforUtilization(gpsImei, fromDate, toDate);
	}

	private void performDriverAnalysis(Date fromDate, Date toDate, KPIScalingFactor kpi, DicvUser user) {
		Long economicBandTime = 0l;
		Double greenBandDistance = 0d;
		Double maxSpeedLat = 0d;
		Double maxSpeedLong = 0d;
		Double maximumSpeed = 0d;
		Double engineNonIdleTimePercent = 0d;
		Double speedViolation = 0d;
		Long speedViolationTime = 0l;
		Long speedband0To20km = 0l;
		Long speedband21To40km = 0l;
		Long speedband41To60km = 0l;
		Long speedbandOver80km = 0l;
		Long speedbandTo80km = 0l;
		Long totalDriveTime = 0l;
		Double tripDistance = 0d;
		Long greenBandTime = 0l;
		Long yellowBandTime = 0l;
		Long redBandTime = 0l;
		Long engineRunTime = 0l;
		Long engineIdleTime = 0l;
		Double economicBand = 0d;
		Double avgSpeed = 0d;
		Double economyBandDistance = 0d;
		Integer harshAcceleration = 0;
		Integer harshBraking = 0;
		Integer harshCornering = 0;
		Double vehicleDistance = 0d;
		Double vehicleInvalidSpeed = 0d;
		Integer speedingCountFlag = 0;
		Integer speedingCount = 0;

		try {

			DriverAnalysisList driverAnalysis = getDriverAnalysis(fromDate, user);

			List<Vehicle> vehList = vehicleRepo.getVehicleListByDriver(user.getUserId());

			for (Vehicle vehicle : vehList) {
				Date gpsParamTime = null;
				if (vehicle == null || vehicle.getGpsImei() == null || vehicle.getGpsImei().getGpsImei() == null)
					continue;
				final Long gpsImei = vehicle.getGpsImei().getGpsImei().longValue();
				final Long totalCount = countTotalGpsParamData(fromDate, toDate, gpsImei);
				if (totalCount > 0) {
					Integer iterCount = totalCount.intValue() <= 1000 ? 0 : totalCount.intValue() / 1000;
					if ((totalCount.intValue() % 1000) > 0)
						iterCount = iterCount + 1;
					for (int i = 1; i <= iterCount; i++) {

						final List<GpsVehParameterDto> gpsParamData = getGpsParamData(fromDate, toDate, vehicle,
								gpsParamTime);
						if (gpsParamData != null && gpsParamData.size() > 1) {

							final Integer totalRecords = gpsParamData.size();
							Integer gpsRecordCount = 0;
							for (GpsVehParameterDto gpsVehicleParam : gpsParamData) {
								gpsRecordCount = gpsRecordCount + 1;
								gpsParamTime = new Date(gpsVehicleParam.getGpsTime().getTime());
								if (gpsRecordCount >= totalRecords) {
									break;
								}

								GpsVehParameterDto gpsVehicleParamNext = gpsParamData.get(gpsRecordCount);

								if (!checkGpsNullValue(gpsVehicleParam, gpsVehicleParamNext))
									continue;

								Long vehicleDiffInSeconds = (gpsVehicleParamNext.getGpsTime().getTime()
										- gpsVehicleParam.getGpsTime().getTime()) / 1000;
								if (vehicleDiffInSeconds < 0) {
									speedingCountFlag = 0;
									continue;
								}
								vehicleDistance = DistanceCalculation.distance(gpsVehicleParam.getGpsLatitude(),
										gpsVehicleParam.getGpsLongitude(), gpsVehicleParamNext.getGpsLatitude(),
										gpsVehicleParamNext.getGpsLongitude());
								vehicleInvalidSpeed = 0d;

								if (vehicleDistance > 0 && vehicleDiffInSeconds > 0) {
									vehicleInvalidSpeed = ((vehicleDistance / vehicleDiffInSeconds) * 3600);
								}

								if (vehicleInvalidSpeed > 9999 || vehicleDiffInSeconds > 900) {
									speedingCountFlag = 0;
									if (vehicleInvalidSpeed > 9999) {
										continue;
									}
								}
								// Distance
								tripDistance = tripDistance(tripDistance, vehicleDistance);
								// Engine Run Time
								if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParamNext.getEngineON() == 1) {
									engineRunTime = engineRunTime + vehicleDiffInSeconds;
								}
								// Total Driver Time
								if (gpsVehicleParam.getGpsSpkm() > 0 && gpsVehicleParamNext.getGpsSpkm() > 0) {
									totalDriveTime = totalDriveTime + vehicleDiffInSeconds;
								}
								// Engine Idle
								if (gpsVehicleParam.getEngineON() == 1 && gpsVehicleParamNext.getEngineON() == 1
										&& gpsVehicleParam.getGpsSpkm() == 0 && gpsVehicleParamNext.getGpsSpkm() == 0) {
									engineIdleTime = engineIdleTime + vehicleDiffInSeconds;
								}
								// Maximum Speed
								if (maximumSpeed < gpsVehicleParamNext.getGpsSpkm()) {
									maximumSpeed = gpsVehicleParamNext.getGpsSpkm();
									maxSpeedLat = gpsVehicleParamNext.getGpsLatitude();
									maxSpeedLong = gpsVehicleParamNext.getGpsLongitude();
								}
								// Violation
								if (vehicle.getVehicleMaxSpeed() != null
										&& (gpsVehicleParam.getGpsSpkm() > vehicle.getVehicleMaxSpeed())
										&& (gpsVehicleParamNext.getGpsSpkm() > vehicle.getVehicleMaxSpeed())) {
									speedViolationTime = speedViolationTime + vehicleDiffInSeconds;
									if (speedingCountFlag == 0) {
										speedingCount = speedingCount + 1;
										speedingCountFlag = 1;
									}
								} else {
									speedingCountFlag = 0;
								}

								// Speed Band
								if (gpsVehicleParam.getGpsSpkm() >= 0 && gpsVehicleParam.getGpsSpkm() <= 20) {
									speedband0To20km = speedband0To20km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 21 && gpsVehicleParam.getGpsSpkm() <= 40) {
									speedband21To40km = speedband21To40km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 41 && gpsVehicleParam.getGpsSpkm() <= 60) {
									speedband41To60km = speedband41To60km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 61 && gpsVehicleParam.getGpsSpkm() <= 80) {
									speedbandTo80km = speedbandTo80km + vehicleDiffInSeconds;
								}
								if (gpsVehicleParam.getGpsSpkm() >= 81) {
									speedbandOver80km = speedbandOver80km + vehicleDiffInSeconds;
								}

								// Economy Band
								if (vehicle.getVariant() != null && gpsVehicleParam.getCanEngineSpeed() != null) {
									if ("MDT".equals(vehicle.getVariant())) {
										if (gpsVehicleParam.getCanEngineSpeed() >= 1200
												&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
											greenBandDistance = greenBandDistance + vehicleDistance;
											greenBandTime = greenBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 2200
												&& gpsVehicleParam.getCanEngineSpeed() <= 3000) {
											yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 3001) {
											redBandTime = redBandTime + vehicleDiffInSeconds;
										}
										if (gpsVehicleParam.getCanEngineSpeed() >= 1200
												&& gpsVehicleParam.getCanEngineSpeed() <= 2200) {
											economyBandDistance = economyBandDistance + vehicleDistance;
											economicBandTime = economicBandTime + vehicleDiffInSeconds;
										}
									} else if ("HDT".equals(vehicle.getVariant())) {
										if (gpsVehicleParam.getCanEngineSpeed() >= 1200
												&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
											greenBandDistance = greenBandDistance + vehicleDistance;
											greenBandTime = greenBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 2100
												&& gpsVehicleParam.getCanEngineSpeed() <= 2700) {
											yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 2701) {
											redBandTime = redBandTime + vehicleDiffInSeconds;
										}
										if (gpsVehicleParam.getCanEngineSpeed() >= 1000
												&& gpsVehicleParam.getCanEngineSpeed() <= 2000) {
											economyBandDistance = economyBandDistance + vehicleDistance;
											economicBandTime = economicBandTime + vehicleDiffInSeconds;
										}
									} else if ("THUNDERBOLT".equals(vehicle.getVariant())) {
										if (gpsVehicleParam.getCanEngineSpeed() >= 900
												&& gpsVehicleParam.getCanEngineSpeed() <= 1600) {
											greenBandDistance = greenBandDistance + vehicleDistance;
											greenBandTime = greenBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 1700
												&& gpsVehicleParam.getCanEngineSpeed() <= 2500) {
											yellowBandTime = yellowBandTime + vehicleDiffInSeconds;
										} else if (gpsVehicleParam.getCanEngineSpeed() >= 2501) {
											redBandTime = redBandTime + vehicleDiffInSeconds;
										}
										if (gpsVehicleParam.getCanEngineSpeed() >= 900
												&& gpsVehicleParam.getCanEngineSpeed() <= 1700) {
											economyBandDistance = economyBandDistance + vehicleDistance;
											economicBandTime = economicBandTime + vehicleDiffInSeconds;
										}
									}
								}

							} // Gps For Loop Ending
						}

						harshAcceleration = harshAcceleration + gpsRepo.countofHarshEvents(
								DicvUtil.getTimeStampFromDate(fromDate), DicvUtil.getTimeStampFromDate(toDate),
								vehicle.getGpsImei().getGpsImei(), "harshAcceleration");
						harshBraking = harshBraking + gpsRepo.countofHarshEvents(
								DicvUtil.getTimeStampFromDate(fromDate), DicvUtil.getTimeStampFromDate(toDate),
								vehicle.getGpsImei().getGpsImei(), "harshBraking");
						harshCornering = harshCornering + gpsRepo.countofHarshEvents(
								DicvUtil.getTimeStampFromDate(fromDate), DicvUtil.getTimeStampFromDate(toDate),
								vehicle.getGpsImei().getGpsImei(), "harshCornering");

					}

					calculateAndUpdateDriverPerofrmance(fromDate, kpi, user, economicBandTime, greenBandDistance,
							maxSpeedLat, maxSpeedLong, maximumSpeed, engineNonIdleTimePercent, speedViolation,
							speedViolationTime, speedband0To20km, speedband21To40km, speedband41To60km,
							speedbandOver80km, speedbandTo80km, totalDriveTime, tripDistance, greenBandTime,
							engineRunTime, engineIdleTime, economicBand, avgSpeed, economyBandDistance,
							harshAcceleration, harshBraking, harshCornering, driverAnalysis, speedingCount);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Error in Driver Analysis " + ex.getMessage());
			return;
		}
	}

	private DriverAnalysisList getDriverAnalysis(Date fromDate, DicvUser user) {
		DriverAnalysisList driverAnalysis = driverRepo.getDriverAnalysis(user.getUserId(), fromDate);
		if (driverAnalysis == null) {
			driverAnalysis = addDriverAnalysis(fromDate, user);
		}
		return driverAnalysis;
	}

	private void calculateAndUpdateDriverPerofrmance(Date fromDate, KPIScalingFactor kpi, DicvUser user,
			Long economicBandTime, Double greenBandDistance, Double maxSpeedLat, Double maxSpeedLong,
			Double maximumSpeed, Double engineNonIdleTimePercent, Double speedViolation, Long speedViolationTime,
			Long speedband0To20km, Long speedband21To40km, Long speedband41To60km, Long speedbandOver80km,
			Long speedbandTo80km, Long totalDriveTime, Double tripDistance, Long greenBandTime, Long engineRunTime,
			Long engineIdleTime, Double economicBand, Double avgSpeed, Double economyBandDistance,
			Integer harshAcceleration, Integer harshBraking, Integer harshCornering, DriverAnalysisList driverAnalysis,
			Integer speedingCount) {
		Double driverScore;
		Double speeding;
		Double starCount;
		Double idling;
		Double harshBrakingDbl;
		Double harshAccelerationDbl;
		Double harshCorneringDbl;
		Double economicDriving;
		harshAccelerationDbl = calculateHarshEvents(kpi.getHarshAcceleration(), totalDriveTime, harshAcceleration);
		harshBrakingDbl = calculateHarshEvents(kpi.getHarshBraking(), totalDriveTime, harshBraking);
		harshCorneringDbl = calculateHarshEvents(kpi.getHarshCornering(), totalDriveTime, harshCornering);

		if (engineRunTime > 0) {

			economicDriving = economicDrivingCalculation(harshBrakingDbl, harshAccelerationDbl, harshCorneringDbl);

			speedViolation = speedViolationCalc(speedViolationTime, totalDriveTime);

			speeding = speedingCalculation(kpi.getSpeeding(), speedViolationTime, totalDriveTime);

			idling = idlingCalculation(kpi.getIdling(), engineRunTime, engineIdleTime);

			economicBand = economicBandCalc(economicBandTime, totalDriveTime);

			if (totalDriveTime == 0 || tripDistance == 0) {
				avgSpeed = 0d;
			} else {
				avgSpeed = (tripDistance.doubleValue() / (totalDriveTime.doubleValue() / 3600d));
				avgSpeed = roundOffDecimal(avgSpeed);
			}

			driverScore = (economicDriving + speeding + idling) / 3;
			driverScore = roundOffDecimal(driverScore);
			starCount = (driverScore / 20);
			starCount = roundOffDecimal(starCount);
		} else {
			idling = null;
			economicDriving = null;
			speeding = null;
			driverScore = null;
			starCount = null;
			tripDistance = null;
			engineRunTime = null;
		}
		updateDriverAnalysis(fromDate, user, driverScore, greenBandDistance, maxSpeedLat, maxSpeedLong, maximumSpeed,
				engineNonIdleTimePercent, speeding, speedViolation, speedViolationTime, speedband0To20km,
				speedband21To40km, speedband41To60km, speedbandOver80km, speedbandTo80km, starCount, totalDriveTime,
				tripDistance, greenBandTime, engineRunTime, engineIdleTime, idling, avgSpeed, economyBandDistance,
				economicDriving, harshAcceleration, harshBraking, harshCornering, economicBand, driverAnalysis,
				speedingCount);
	}

	private Double roundOffDecimal(Double driverScore) {
		if (driverScore > 0)
			driverScore = Math.round(driverScore * 100D) / 100D;
		return driverScore;
	}

	private Double tripDistance(Double tripDistance, Double vehicleDistance) {
		tripDistance = tripDistance + vehicleDistance;
		tripDistance = roundOffDecimal(tripDistance);
		return tripDistance;
	}

	private Double economicBandCalc(Long economicBandTime, Long totalDriveTime) {
		Double economicBand = 0d;
		if (totalDriveTime > 0 && economicBandTime > 0) {
			economicBand = 100d - (1 - (economicBandTime.doubleValue() / totalDriveTime.doubleValue()) * 100);
			economicBand = roundOffDecimal(economicBand);
		}
		return economicBand;
	}

	private Double speedViolationCalc(Long speedViolationTime, Long totalDriveTime) {
		Double speedViolation = 0d;
		if (speedViolationTime > 0 && totalDriveTime > 0) {
			speedViolation = (double) ((speedViolationTime.doubleValue() / totalDriveTime.doubleValue()) * 100);
			speedViolation = roundOffDecimal(speedViolation);
			checkZeroOrMoreThan100(speedViolation);
		}
		return speedViolation;
	}

	private Double economicDrivingCalculation(Double harshBrakingDbl, Double harshAccelerationDbl,
			Double harshCorneringDbl) {
		Double economicDriving = roundOffDecimal((harshAccelerationDbl + harshBrakingDbl + harshCorneringDbl) / 3);
		checkZeroOrMoreThan100(economicDriving);
		return economicDriving;
	}

	private Double idlingCalculation(Integer kpi, Long engineRunTime, Long engineIdleTime) {
		Double idling = 100d;
		if (engineIdleTime != null && engineRunTime != null && engineRunTime != 0) {
			idling = (double) (100 - ((engineIdleTime.doubleValue() / engineRunTime.doubleValue()) * kpi * 100));
			idling = roundOffDecimal(idling);
			checkZeroOrMoreThan100(idling);
		}
		return idling;
	}

	private Double speedingCalculation(Integer kpi, Long speedViolationTime, Long totalDriveTime) {
		Double speeding = 100d;
		if (speedViolationTime > 0 && totalDriveTime > 0) {
			speeding = (double) (100 - ((speedViolationTime.doubleValue() / totalDriveTime.doubleValue()) * kpi * 100));
			speeding = roundOffDecimal(speeding);
			checkZeroOrMoreThan100(speeding);

		}
		return speeding;
	}

	private void updateDriverAnalysis(Date fromDate, DicvUser user, Double driverScore, Double greenBandDistance,
			Double maxSpeedLat, Double maxSpeedLong, Double maximumSpeed, Double engineNonIdleTimePercent,
			Double speeding, Double speedViolation, Long speedViolationTime, Long speedband0To20km,
			Long speedband21To40km, Long speedband41To60km, Long speedbandOver80km, Long speedbandTo80km,
			Double starCount, Long totalDriveTime, Double tripDistance, Long greenBandTime, Long engineRunTime,
			Long engineIdleTime, Double idling, Double avgSpeed, Double economyBandDistance, Double economicDriving,
			Integer harshAcceleration, Integer harshBraking, Integer harshCornering, Double economicBand,
			DriverAnalysisList driverAnalysis, Integer speedingCount) {
		driverAnalysis.setHarshAcceleration(harshAcceleration);
		driverAnalysis.setHarshBraking(harshBraking);
		driverAnalysis.setHarshCornering(harshCornering);
		driverAnalysis.setAverageVehicleSpeed(avgSpeed);
		driverAnalysis.setDriverScore(driverScore);
		driverAnalysis.setEconomicBand(economicBand);
		driverAnalysis.setEconomyBandDistance(economyBandDistance);
		driverAnalysis.setEngineIdleTime(engineIdleTime);
		driverAnalysis.setEconomyDriving(economicDriving);
		driverAnalysis.setEngineIdleTime(engineIdleTime);
		driverAnalysis.setEngineIdleTimePercent(idling);
		driverAnalysis.setEngineNonIdleTimePercent(engineNonIdleTimePercent);
		driverAnalysis.setEngineRunTime(engineRunTime);
		driverAnalysis.setSpeedingCount(speedingCount);
		driverAnalysis.setSpeedAdherence(speeding);
		driverAnalysis.setSpeedband0To20km(speedband0To20km);
		driverAnalysis.setSpeedband21To40km(speedband21To40km);
		driverAnalysis.setSpeedband41To60km(speedband41To60km);
		driverAnalysis.setSpeedbandOver80km(speedbandOver80km);
		driverAnalysis.setSpeedbandTo80km(speedbandTo80km);
		driverAnalysis.setMaxSpeedLat(maxSpeedLat);
		driverAnalysis.setMaxSpeedLong(maxSpeedLong);
		driverAnalysis.setMaximumSpeed(maximumSpeed);
		driverAnalysis.setRecordTimestamp(DicvUtil.getTimestamp());
		driverAnalysis.setReportDate(fromDate);
		driverAnalysis.setTotalDriveTime(totalDriveTime);
		driverAnalysis.setTripDistance(tripDistance);
		driverAnalysis.setSpeedViolationTime(speedViolationTime);
		driverAnalysis.setGreenBandDistance(greenBandDistance);
		if (economyBandDistance > 0 || speedband0To20km > 0) {
			driverAnalysis.setIsCanParameter(1);
		}
		driverAnalysis.setGreenBandTime(greenBandTime);
		driverAnalysis.setSpeedViolation(speedViolation);
		if (user.getManagerId() != null)
			driverAnalysis.setOwnerId(user.getManagerId());

		if (user.getDicvGroup() != null && user.getDicvGroup().getGroupId() != null)
			driverAnalysis.setGroupId(user.getDicvGroup().getGroupId());
		driverAnalysis.setDriverScore(driverScore);
		driverAnalysis.setStarCount(starCount);
		driverRepo.save(driverAnalysis);
	}

	private Double calculateHarshEvents(Integer kpi, Long totalDriveTime, Integer harshTotal) {
		Double harshEvent = 100d;
		if (totalDriveTime > 0 && harshTotal > 0) {
			Long calcinHr = totalDriveTime / 3600;
			if (calcinHr > 0) {
				harshEvent = roundOffDecimal(100d - (double) ((harshTotal * kpi) / calcinHr));
				if (harshEvent < 0d)
					harshEvent = 0d;
			}
		}

		return harshEvent;
	}

	private DriverAnalysisList addDriverAnalysis(Date fromDate, DicvUser user) {
		DriverAnalysisList driverAnalysis = new DriverAnalysisList();
		driverAnalysis.setDriverId(user.getUserId());
		driverAnalysis.setReportDate(fromDate);
		driverAnalysis.setLastUpdTs(DicvUtil.getTimestamp());
		driverAnalysis.setStarCount(null);
		driverAnalysis.setDriverScore(null);
		driverAnalysis = driverRepo.save(driverAnalysis);
		return driverAnalysis;
	}

	private boolean checkGpsNullValue(GpsVehParameterDto gpsVehicleParam, GpsVehParameterDto gpsVehicleParamNext) {
		if (gpsVehicleParam.getGpsLatitude() == null || gpsVehicleParam.getGpsLongitude() == null
				|| gpsVehicleParam.getGpsSpkm() == null || gpsVehicleParam.getGpsTime() == null
				|| gpsVehicleParam.getEngineON() == null || gpsVehicleParamNext.getGpsLatitude() == null
				|| gpsVehicleParamNext.getGpsLongitude() == null || gpsVehicleParamNext.getGpsSpkm() == null
				|| gpsVehicleParamNext.getGpsTime() == null || gpsVehicleParamNext.getEngineON() == null) {
			return false;
		}
		return true;
	}

	private void sendEmail(String subject, String msg) {
		sendMailService.sendMail("paras.dicv@gmail.com", "harikrishnan.d@contus.in", subject,
				msg + " For  " + new Date());
	}

	private void checkZeroOrMoreThan100(Double value) {
		if (value > 100)
			value = 100d;
		if (value < 0)
			value = 0d;
	}

}
