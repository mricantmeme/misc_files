package com.dicv.cwp.dto;

import java.util.Date;

public class GpsVehParamDto {

	public GpsVehParamDto() {
		super();
	}

	private Long gpsVehicleParamId;

	private Date createdOn;

	private Double gpsSpkm;

	private Date gpsTime;

	private Integer fuelTankLevel;

	private Date vehicleLastUpdateON;

	private Integer engineON;

	private Integer batteryHealth;

	private Double gpsVolt;

	private Long gpsImei;

	private Double deviceBattery;

	private Integer signalStrength;

	private Double gpsLatitude;

	private Double gpsLongitude;

	public GpsVehParamDto(GpsVehParamDto gpsVehParamDto) {
		super();
		this.gpsVehicleParamId = gpsVehParamDto.getGpsVehicleParamId();
		this.fuelTankLevel = gpsVehParamDto.getFuelTankLevel();
		this.batteryHealth = gpsVehParamDto.getBatteryHealth();
		this.vehicleLastUpdateON = gpsVehParamDto.getVehicleLastUpdateON();
		this.engineON = gpsVehParamDto.getEngineON();
		this.gpsSpkm = gpsVehParamDto.getGpsSpkm();
		this.gpsTime = gpsVehParamDto.getGpsTime();
		this.gpsLatitude = gpsVehParamDto.getGpsLatitude();
		this.gpsLongitude = gpsVehParamDto.getGpsLongitude();
	}

	public GpsVehParamDto(Long gpsVehicleParamId, Date gpsTime, Integer fuelTankLevel, Double gpsLatitude,
			Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsTime = gpsTime;
		this.fuelTankLevel = fuelTankLevel;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParamDto(Long gpsVehicleParamId, Date gpsTime, Integer fuelTankLevel) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsTime = gpsTime;
		this.fuelTankLevel = fuelTankLevel;
	}

	public GpsVehParamDto(Long gpsVehicleParamId, Date gpsTime, Integer batteryHealth, Integer engineON) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsTime = gpsTime;
		this.batteryHealth = batteryHealth;
		this.engineON = engineON;
	}

	public GpsVehParamDto(Long gpsVehicleParamId, Date gpsTime, Integer batteryHealth, Integer engineON,
			Double gpsLatitude, Double gpsLongitude) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsTime = gpsTime;
		this.batteryHealth = batteryHealth;
		this.engineON = engineON;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
	}

	public GpsVehParamDto(Long gpsVehicleParamId, Long gpsImei, Date gpsTime, Date vehicleLastUpdateON,
			Double deviceBattery, Integer signalStrength, Double gpsVolt) {
		super();
		this.gpsVehicleParamId = gpsVehicleParamId;
		this.gpsImei = gpsImei;
		this.gpsTime = gpsTime;
		this.vehicleLastUpdateON = vehicleLastUpdateON;
		this.gpsVolt = gpsVolt;
		this.signalStrength = signalStrength;
		this.deviceBattery = deviceBattery;
	}

	public Long getGpsVehicleParamId() {
		return gpsVehicleParamId;
	}

	public void setGpsVehicleParamId(Long gpsVehicleParamId) {
		this.gpsVehicleParamId = gpsVehicleParamId;
	}

	public Integer getFuelTankLevel() {
		return fuelTankLevel;
	}

	public void setFuelTankLevel(Integer fuelTankLevel) {
		this.fuelTankLevel = fuelTankLevel;
	}

	public Integer getBatteryHealth() {
		return batteryHealth;
	}

	public void setBatteryHealth(Integer batteryHealth) {
		this.batteryHealth = batteryHealth;
	}

	public Integer getEngineON() {
		return engineON;
	}

	public void setEngineON(Integer engineON) {
		this.engineON = engineON;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(Date gpsTime) {
		this.gpsTime = gpsTime;
	}

	public Date getVehicleLastUpdateON() {
		return vehicleLastUpdateON;
	}

	public void setVehicleLastUpdateON(Date vehicleLastUpdateON) {
		this.vehicleLastUpdateON = vehicleLastUpdateON;
	}

	@Override
	public String toString() {
		return "GpsVehParamDto [gpsVehicleParamId=" + gpsVehicleParamId + "," + ", createdOn=" + createdOn
				+ ", gpsSpkm=" + gpsSpkm + ", gpsTime=" + gpsTime + ", fuelTankLevel=" + fuelTankLevel
				+ ", vehicleLastUpdateON=" + vehicleLastUpdateON + ", engineON=" + engineON + ", batteryHealth="
				+ batteryHealth + "]";
	}

	public Double getGpsVolt() {
		return gpsVolt;
	}

	public void setGpsVolt(Double gpsVolt) {
		this.gpsVolt = gpsVolt;
	}

	public Long getGpsImei() {
		return gpsImei;
	}

	public void setGpsImei(Long gpsImei) {
		this.gpsImei = gpsImei;
	}

	public Double getDeviceBattery() {
		return deviceBattery;
	}

	public void setDeviceBattery(Double deviceBattery) {
		this.deviceBattery = deviceBattery;
	}

	public Integer getSignalStrength() {
		return signalStrength;
	}

	public void setSignalStrength(Integer signalStrength) {
		this.signalStrength = signalStrength;
	}

	public Double getGpsSpkm() {
		return gpsSpkm;
	}

	public void setGpsSpkm(Double gpsSpkm) {
		this.gpsSpkm = gpsSpkm;
	}

	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

}
